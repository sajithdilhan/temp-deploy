-- Migration: 20260922032111_AddWorkRequestScalability
-- Adds the Scalability intake metric, which multiplies the project score.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20260922004914_AddPainPointDescription;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20260922004914_AddPainPointDescription. Roll back with
-- 20260922032111_AddWorkRequestScalability.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20260922032111_AddWorkRequestScalability.up.sql
--
-- Additive and non-destructive. The score ceiling doubles to 20,000 because the highest
-- weight is 2, but NO EXISTING SCORE IS REWRITTEN: every scored request is backfilled to
-- "Not applicable", whose weight is 1, so its stored total stays exactly as it was and the
-- portfolio's ranking does not move. Drafts are left NULL — they are unscored now and stay
-- unscored, which is the honest answer: nobody has told us whether that work is reusable.
--
-- The backfill is not optional. A score is the product of four metrics AND the Scalability
-- weight, so a scored request left NULL here becomes unscored the moment the new API reads
-- it. Do not run the ALTERs without the UPDATE.
--
-- Deploy order matters: run this BEFORE starting an API build that selects the column, and
-- it is safe to run while the previous build is still serving — an older API simply never
-- selects it.

START TRANSACTION;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_project_score_check;

ALTER TABLE work_requests ADD scalability smallint;

ALTER TABLE work_requests ADD CONSTRAINT work_requests_project_score_check CHECK (project_score IS NULL OR project_score BETWEEN 1 AND 20000);

ALTER TABLE work_requests ADD CONSTRAINT work_requests_scalability_check CHECK (scalability IS NULL OR scalability BETWEEN 1 AND 6);

UPDATE work_requests SET scalability = 1 WHERE project_score IS NOT NULL;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20260922032111_AddWorkRequestScalability', '10.0.8');

COMMIT;
