-- Migration: 20260922062447_WidenPainPointDescriptionTo300
-- Widens the pain point description from 100 to 300 characters.
--
-- Applies on top of 20260922032111_AddWorkRequestScalability. Roll back with
-- 20260922062447_WidenPainPointDescriptionTo300.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20260922062447_WidenPainPointDescriptionTo300.up.sql
--
-- Safe to run while the API is serving. Widening a varchar in PostgreSQL is a catalogue
-- change only: no table rewrite, and every stored value stays valid. An older API build
-- simply never writes more than 100 characters.

START TRANSACTION;

ALTER TABLE pain_point_tags ALTER COLUMN description TYPE character varying(300);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20260922062447_WidenPainPointDescriptionTo300', '10.0.8');

COMMIT;
