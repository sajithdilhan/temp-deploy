-- Migration: 20260922004914_AddPainPointDescription
-- Adds the optional pain point description (max 100 characters).
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20260910013414_AddHodInitiationAssignment;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Roll back with 20260922004914_AddPainPointDescription.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20260922004914_AddPainPointDescription.up.sql
--
-- The column is nullable and has no default, so this does not rewrite the table and
-- existing rows are unaffected. Safe to run while the API is serving: an older build
-- simply never selects the column.

START TRANSACTION;

ALTER TABLE pain_point_tags ADD description character varying(100);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20260922004914_AddPainPointDescription', '10.0.8');

COMMIT;
