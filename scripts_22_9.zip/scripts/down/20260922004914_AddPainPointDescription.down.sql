-- Rollback: 20260922004914_AddPainPointDescription
-- Reverts the database to 20260910013414_AddHodInitiationAssignment.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20260922004914_AddPainPointDescription.down.sql
--
-- DESTRUCTIVE. Dropping the column discards every description a curator has written;
-- there is no backup of them anywhere else. Take a dump of pain_point_tags first if the
-- data matters:
--
--   pg_dump -h <host> -U <user> -d <database> -t pain_point_tags > pain_point_tags.sql
--
-- Deploy order matters: roll the API back to a build without the Description property
-- BEFORE running this. A running API that still selects the column will error on every
-- pain point read the moment it is dropped.

START TRANSACTION;

ALTER TABLE pain_point_tags DROP COLUMN description;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20260922004914_AddPainPointDescription';

COMMIT;
