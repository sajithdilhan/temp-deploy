-- Rollback: 20260922062447_WidenPainPointDescriptionTo300
-- Narrows the pain point description back to 100 characters.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20260922062447_WidenPainPointDescriptionTo300.down.sql
--
-- WILL FAIL if any description is longer than 100 characters. PostgreSQL refuses the type
-- change rather than truncating silently, so the transaction aborts and nothing is lost.
-- Check first:
--
--   SELECT id, length(description) FROM pain_point_tags WHERE length(description) > 100;
--
-- If rows come back, decide deliberately what to do with them — truncate:
--
--   UPDATE pain_point_tags SET description = left(description, 100) WHERE length(description) > 100;
--
-- Either way that text is gone afterwards, so take a dump of the table first if it matters:
--
--   pg_dump -h <host> -U <user> -d <database> -t pain_point_tags > pain_point_tags.sql
--
-- Deploy order matters: roll the API back to a build whose validator caps descriptions at
-- 100 BEFORE running this, or the next long description written will be rejected by the
-- database rather than by the API.

START TRANSACTION;

ALTER TABLE pain_point_tags ALTER COLUMN description TYPE character varying(100);

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20260922062447_WidenPainPointDescriptionTo300';

COMMIT;
