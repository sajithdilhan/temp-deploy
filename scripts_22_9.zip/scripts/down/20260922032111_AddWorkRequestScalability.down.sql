-- Rollback: 20260922032111_AddWorkRequestScalability
-- Reverts the database to 20260922004914_AddPainPointDescription.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20260922032111_AddWorkRequestScalability.down.sql
--
-- MAY FAIL, and the reason is worth understanding before you run it. Restoring the
-- 1-10,000 ceiling is safe only while no score has ever used a weight above 1. That holds
-- immediately after the up script — the backfill deliberately chose "Not applicable" — but
-- it STOPS holding as soon as a requester selects any other option, because those weigh 2
-- and their scores can reach 20,000. PostgreSQL then refuses the constraint. Check first:
--
--   SELECT id, project_score FROM work_requests WHERE project_score > 10000;
--
-- If rows come back, this script is the wrong tool: the scores are real and narrowing the
-- bound cannot keep them. Prefer a forward fix, or restore from backup.
--
-- DESTRUCTIVE even when it succeeds. Dropping the column discards every Scalability
-- selection; there is no backup of them anywhere else. Take a dump first if it matters:
--
--   pg_dump -h <host> -U <user> -d <database> -t work_requests > work_requests.sql
--
-- Note what this does NOT do: project_score is left exactly as stored. Any request scored
-- with a weight-2 option keeps its doubled total, which the rolled-back API cannot
-- reproduce and will only correct when that request is next edited. Until then those
-- requests rank higher than they should.
--
-- Deploy order matters: roll the API back to a build without the Scalability property
-- BEFORE running this. A running API that still selects the column will error on every
-- work request read the moment it is dropped.

START TRANSACTION;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_project_score_check;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_scalability_check;

ALTER TABLE work_requests DROP COLUMN scalability;

ALTER TABLE work_requests ADD CONSTRAINT work_requests_project_score_check CHECK (project_score IS NULL OR project_score BETWEEN 1 AND 10000);

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20260922032111_AddWorkRequestScalability';

COMMIT;
