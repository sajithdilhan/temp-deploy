function n(){let e=typeof document<"u"&&document.baseURI?document.baseURI:"/";try{return new URL("api",e).pathname.replace(/\/$/,"")}catch{return"/api"}}var t={apiUrl:n()};export{t as a};
