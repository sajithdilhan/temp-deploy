# UAT cut-over: role and scope access (October 2026)

Runbook for moving UAT from the 2026-10-10 build to the role and scope access release
([PLN-022](../plans/PLN-022-rbac-role-scope-revamp.md), [RFC-011](../rfcs/RFC-011-role-and-scope-access-assignments.md)).
The general procedure is in [production.md](production.md), including the IIS section. This file covers only what
is specific to this release.

**Status:** READY TO START (2026-10-14). The business feedback on the role-scope demo is in `role-scope-revamp` (the
backfill strip on Projects hidden behind the `projectBackfillEntry` flag; red sidebar badges for waiting work). It
adds no migration and no configuration. The release candidate is the `dev-reduced` merge of that branch. If anything
else lands before Step 6, re-run Steps 1–3 on the new commit.

## What changes

| | On UAT now | After the cut-over |
| --- | --- | --- |
| Commit | `130d9db9` (PR #105, 2FA), deployed 2026-10-10 | `dev-reduced` after merging the business feedback (record it in Step 1) |
| Last migration | `20261010073248_AddLoginOtp` | `20261013074201_GrantProjectExecuterToExistingProjectLeads` |
| Access | role ladder (`users.role`) | role assignments with a scope (`user_role_assignments`) |
| Approval flow | HOD → GM | HOD → GM → Steering Committee → GM routes → HOD initialises |
| Configuration | — | **no new keys**: `appsettings*.json`, `.env.example` and `deploy/` are unchanged since `130d9db9` |

Size of UAT: 150+ projects and 250+ users.

### What users notice

- The old role maps to assignments as-is (RFC-011 § "Mapping table"): USER → Contributor; MANAGER → Contributor +
  Approver; MODERATOR → **Pain Point Moderator only**; ADMIN → System Administrator; SUPER_ADMIN → Super Administrator.
- **Active EXTERNAL_USER accounts become pending.** They cannot sign in until someone grants them a role.
- **Deactivated users get no assignments.** If reactivated, they join the pending list.
- **Nobody is mapped to** User Administrator, Organisation Moderator, Finance Moderator, Self-Approver, the dashboard
  roles or Steering Committee Member. These are granted by hand after release (Step 6.7).
- **Until a Steering Committee Member is granted, every project request that passes the GM waits at the committee.**
- Approved project requests with no project yet go back to "Awaiting Steering Committee Approval" (D58). Their
  requesters and HODs will see them reopen.
- Project leads of live projects are granted Project Executer at the delivery unit, so they keep managing their projects.

## The six migrations

Apply in this order with `psql -v ON_ERROR_STOP=1 -f`, from `apps/api-dotnet/scripts/sql/`. Roll back in the
reverse order with the matching `.down.sql`.

| # | Migration | Kind | Notes |
| --- | --- | --- | --- |
| 1 | `20261011000000_AddUserRoleAssignments` | schema + backfill | **Refuses to run** if an active USER, MANAGER or MODERATOR has no unit or an inactive unit (pre-check query 2). |
| 2 | `20261012072349_AddExternalBusinessUnitsAndCommitteeRoles` | schema | |
| 3 | `20261012121756_AddSteeringCommitteeStage` | schema | |
| 4 | `20261013041113_RenameCoordinationStageAddGmRouting` | schema | |
| 5 | `20261013074119_MoveApprovedRequestsWithoutProjectToCommittee` | **data** | Selection = pre-check query 14. |
| 6 | `20261013074201_GrantProjectExecuterToExistingProjectLeads` | **data** | Selection = pre-check query 18; query 19 lists the projects left without an Executer. |

The two SQL assets that go with them, both read-only:

- [`uat-access-precheck.sql`](../rfcs/RFC-011-assets/uat-access-precheck.sql): queries 1–16 read only the legacy
  schema. Queries 17–19 need migrations 1–4 applied, so on a database without them the file stops at query 17 under
  `ON_ERROR_STOP`.
- [`uat-access-diff-report.sql`](../rfcs/RFC-011-assets/uat-access-diff-report.sql) compares each user's legacy role
  with the assignments they hold. It needs migration 1.

## Step 1 — Freeze the release candidate

- [ ] Confirm what UAT is at: `SELECT "MigrationId" FROM "__EFMigrationsHistory" ORDER BY 1 DESC LIMIT 3;` returns
      `20261010073248_AddLoginOtp` first.
- [ ] Tag the build UAT runs now, as the application rollback target:
      `git tag uat-2026-10-10 130d9db9`. Keep that build's publish output (or rebuild it from the tag).
- [ ] Record the release candidate commit here: `________`.
- [ ] Validate that exact commit: `dotnet build` and `dotnet test` (unit tests), `pnpm nx run web:lint`,
      `pnpm nx run web:test`, `pnpm nx run web:build:production`, and the Playwright suite. The last full run was on
      `role-scope-revamp` before its merge into `dev-reduced`.

## Step 2 — Copy UAT and run the pre-check

- [ ] `pg_dump` UAT (custom format, `-Fc`) and restore it locally as `uat_copy`. Never point the demo seeder or the
      e2e suite at it: real accounts and data.
- [ ] Run pre-check queries 1–16 on `uat_copy`. Export each result to CSV for the business pack (Step 4).
- [ ] Resolve every row of **query 2** (fix the user's unit, or deactivate the account). Make the same fix on live
      UAT now, through the current app, so Step 6 does not stop on it.
- [ ] Review with the business, and fix in the current UAT app before cut-over where possible:
  - queries **5, 6 and 15**: in-flight project requests whose named HOD or GM will not be eligible, self-approval,
    or no approval stage. These need re-routing (RFC-011 § cut-over step 4). Change requests keep their flow (D45).
  - query **4**: moderators and what they administer today (they keep Pain Point Moderator only);
  - query **11**: live projects and who can manage them;
  - query **12**: users at Group or Business Area units, who become subtree-wide Contributors;
  - query **13**: Super Admins. After cut-over only they can grant tier-1 roles, and they cannot revoke each other.

## Step 3 — Rehearse on the copy

Time each part, because those times set the maintenance window.

- [ ] Apply migrations 1–4 to `uat_copy`.
- [ ] Run the whole pre-check file. Queries 14, 18 and 19 now show exactly what migrations 5 and 6 will do;
      **query 17** must be empty (no external units yet).
- [ ] Apply migrations 5 and 6. Check that the counts match queries 14 and 18.
- [ ] Run the diff report and export it. Every `LOST` / `LOST_AND_GAINED` row needs a decision in Step 4.
- [ ] Point a local API at `uat_copy` and smoke-test it: one real account per mapped role signs in and sees the right
      menus; one request returned to the committee shows the system-actor history entry; a project lead still
      manages their project; an EXTERNAL_USER account is refused sign-in.
- [ ] Rehearse rollback: the down scripts 6 → 1, then confirm `__EFMigrationsHistory` ends at
      `20261010073248_AddLoginOtp`. Then re-apply 1 → 6 to prove the round trip.
- [ ] Record: migration time `____`, rollback time `____`, issues found `____`.

## Step 4 — Business sign-off pack

Send the CSVs from Steps 2–3, then collect decisions **before** the deployment date:

- [ ] Diff report signed off (RFC-011 D2).
- [ ] The list of approved requests returning to the committee (query 14), so requesters can be told.
- [ ] In-flight requests from queries 5, 6 and 15 re-routed, or the plan for each agreed.
- [ ] **Grant worksheet** agreed: one row per person, role and unit, with who approved it. Sources:

  | Role to grant | Scope | Where the names come from |
  | --- | --- | --- |
  | Steering Committee Member | unscoped | query 16 (a starting list; the business picks) |
  | User Administrator | unit | business decision; query 4 shows who administers users today |
  | Organisation Moderator | unit | business decision; query 4 |
  | Finance Moderator | unit | business decision |
  | Project Executer | delivery unit | query 19 (projects the migration leaves without an Executer) |
  | Approver | unit | query 4, for moderators who are named HOD or GM on open requests |
  | Role for each pending account | unit | query 3, only the accounts that should keep access |

- [ ] External business units (SA, AIA, CI, IT) and the HOD of each. The HOD must hold an assignment at or beneath
      the unit, so they may need a grant first.

Grants are made by hand in People & access after release (Step 6.7). There is no bulk grant. With the worksheet
agreed in advance, Step 6.7 is data entry, not decision-making.

## Step 5 — Prepare

- [ ] Build from the release candidate tag: `pnpm nx run web:build:production`, then `dotnet publish` with the web
      bundle in `wwwroot` (one IIS application, see [production.md § IIS](production.md#if-you-are-hosting-on-iis)).
- The internal and internet EC2 sites **share one UAT database** (confirmed 2026-10-14). The migrations therefore run
  once, from one place, and both sites are stopped in Step 6 and get the new build before either restarts. An old
  build left running on one site would write to the migrated database.
- [ ] Copy to each EC2: the publish output, the six `.up.sql` and `.down.sql` scripts, the two RFC-011 SQL assets,
      and the previous publish output (rollback).
- [ ] Check `psql` is available where the scripts will run, and that it reaches the UAT database.
- [ ] Brief the UAT testers: maintenance window; pending accounts; moderators lose administration until re-granted;
      requests reopening at the committee; the new committee, GM routing and initialisation steps; per-role retest
      script.
- [ ] Confirm the people who make the grants (at least one Super Admin) are available during the window.

## Step 6 — Deployment day

1. [ ] Announce the start. Stop the IIS application pool on **both** EC2s. Nothing may write during the migration.
2. [ ] Backup: `pg_dump -Fc` of UAT. **This is the real rollback.** Check the file is not empty, and keep it.
3. [ ] Re-run pre-check **query 2** on live UAT, because data may have changed since the copy. It must be empty.
4. [ ] Apply migrations 1 → 6 in order, **once**, from one machine (the database is shared by both sites). Stop at the
      first error and go to Rollback.
5. [ ] Check: `__EFMigrationsHistory` ends at `20261013074201_GrantProjectExecuterToExistingProjectLeads`; the counts
      from queries 14 and 18 match the rehearsal (allowing for data changed since).
6. [ ] Deploy the new publish output to both sites. Keep `appsettings.Production.json` and the log directory. Start
      the pools. `/captain/api/health/ready` returns 200. A dated `api-*.log` appears. Load a deep link and refresh.
7. [ ] A Super Admin works through the grant worksheet: Steering Committee Members first (requests are waiting),
      then external units with their HODs, then User Administrators, Organisation and Finance Moderators, Project
      Executers, Approvers and pending accounts. Tick each row.
8. [ ] Re-run the diff report. Every row is `SAME`, `GAINED` or an agreed `LOST`.
9. [ ] Smoke test with one UAT tester per role, plus: a committee member approving; a GM routing a request (internal
      and external); an HOD initialising it into a project.
10. [ ] Go / no-go. **Go:** announce the end. **No-go:** Rollback.

## Rollback

**Decide by the agreed cut-off time.** After testers start writing, a restore loses their work.

- **Before Step 6.6 (the old build is still deployed):** run the down scripts 6 → 1, or restore the Step 6.2 backup;
  start the pools.
- **After Step 6.6:** stop the pools; redeploy the `uat-2026-10-10` build; restore the Step 6.2 backup (preferred), or
  run the down scripts 6 → 1; start the pools.
- **Redeploying the old build on its own is not enough.** It cannot read the new approval stages.

## Step 7 — Afterwards

- [ ] Watch the logs for the first days, especially `LogWarning` authorization refusals (missing grants).
- [ ] Tag the deployed commit `uat-2026-10-<dd>`.
- [ ] Update PLN-022 ("After the build — UAT cut-over"), [CURRENT.md](../roadmap/CURRENT.md) and this file's status.
- [ ] Archive the final diff report output. It cannot be run once the legacy columns are dropped (follow-up release).
