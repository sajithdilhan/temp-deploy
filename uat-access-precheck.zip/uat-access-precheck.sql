-- RFC-009 — UAT access pre-check (READ-ONLY)
--
-- Run against a COPY of the UAT database before the role + scope migration is designed in
-- detail, and again before cut-over. Every statement is a SELECT inside a read-only
-- transaction; nothing is changed. Export each result set for the business review (RFC-009 §
-- "Migration and UAT cut-over").
--
--   psql "$CONNECTION" -f docs/rfcs/RFC-009-assets/uat-access-precheck.sql
--
-- The approval checks mirror today's rule (ADR-016): an approver must be active, MANAGER or
-- above, and sit in the request's requesting unit or one of its ancestors.

BEGIN TRANSACTION READ ONLY;

-- 1. Population: active users per legacy role and the type of unit they sit in.
SELECT u.role,
       coalesce(ou.type::text, '(no unit)') AS unit_type,
       count(*) FILTER (WHERE u.is_active)     AS active_users,
       count(*) FILTER (WHERE NOT u.is_active) AS inactive_users,
       count(*) FILTER (WHERE u.is_active AND u.team_id IS NOT NULL) AS active_with_team
FROM users u
LEFT JOIN organisation_units ou ON ou.id = u.organisation_unit_id
GROUP BY u.role, ou.type
ORDER BY u.role, unit_type;

-- 2. Users the automatic mapping cannot place: active, above EXTERNAL_USER, and either no unit
--    or an inactive unit. Each needs a decision before the migration can run.
SELECT u.id, u.email, u.role, u.organisation_unit_id, ou.is_active AS unit_active
FROM users u
LEFT JOIN organisation_units ou ON ou.id = u.organisation_unit_id
WHERE u.is_active
  AND u.role <> 'EXTERNAL_USER'
  AND (u.organisation_unit_id IS NULL OR ou.is_active = false)
ORDER BY u.role, u.email;

-- 3. Pending accounts (D8): active EXTERNAL_USER accounts that become the first
--    "pending accounts" list.
SELECT u.id, u.email, u.created_at
FROM users u
WHERE u.is_active AND u.role = 'EXTERNAL_USER'
ORDER BY u.created_at;

-- 4. Moderators (Q3): each moderator's unit, the size of the subtree they administer today and
--    how many users and open work sit in it. Input for the per-person mapping decision.
WITH RECURSIVE subtree AS (
    SELECT u.id AS moderator_id, ou.id AS unit_id
    FROM users u JOIN organisation_units ou ON ou.id = u.organisation_unit_id
    WHERE u.is_active AND u.role = 'MODERATOR'
    UNION ALL
    SELECT s.moderator_id, child.id
    FROM subtree s JOIN organisation_units child ON child.parent_id = s.unit_id
)
SELECT m.id, m.email, ou.type AS unit_type, ou.name AS unit_name,
       count(DISTINCT s.unit_id) AS units_in_subtree,
       (SELECT count(*) FROM users x WHERE x.is_active AND x.organisation_unit_id IN
            (SELECT unit_id FROM subtree s2 WHERE s2.moderator_id = m.id)) AS users_in_subtree,
       (SELECT count(*) FROM work_requests w
         WHERE w.request_status IN ('SUBMITTED', 'UNDER_REVIEW')
           AND w.requesting_organisation_unit_id IN
               (SELECT unit_id FROM subtree s3 WHERE s3.moderator_id = m.id)) AS open_requests_in_subtree
FROM users m
JOIN organisation_units ou ON ou.id = m.organisation_unit_id
JOIN subtree s ON s.moderator_id = m.id
GROUP BY m.id, m.email, ou.type, ou.name
ORDER BY m.email;

-- 5. In-flight approvals: every request waiting at HOD or GM, the approver named for the
--    current stage, and whether that approver is eligible TODAY. Any row with
--    eligible_today = false is already stuck; after migration every row must stay eligible
--    under the new Approver-assignment rule.
WITH RECURSIVE ancestors AS (
    SELECT w.id AS request_id, w.requesting_organisation_unit_id AS unit_id
    FROM work_requests w
    WHERE w.request_status IN ('SUBMITTED', 'UNDER_REVIEW') AND w.approval_stage IN ('HOD', 'GM')
    UNION ALL
    SELECT a.request_id, ou.parent_id
    FROM ancestors a JOIN organisation_units ou ON ou.id = a.unit_id
    WHERE ou.parent_id IS NOT NULL
)
SELECT w.request_no, w.project_name, w.request_status, w.approval_stage,
       req.email AS requester, req.role AS requester_role,
       appr.email AS current_approver, appr.role AS approver_role, appr.is_active AS approver_active,
       (appr.is_active
        AND appr.role IN ('MANAGER', 'MODERATOR', 'ADMIN', 'SUPER_ADMIN')
        AND (rou.type = 'GROUP'
             OR appr.organisation_unit_id IN (SELECT a.unit_id FROM ancestors a WHERE a.request_id = w.id)))
           AS eligible_today,
       (w.requester_user_id = appr.id) AS requester_is_current_approver
FROM work_requests w
LEFT JOIN users req ON req.id = w.requester_user_id
LEFT JOIN organisation_units rou ON rou.id = w.requesting_organisation_unit_id
LEFT JOIN users appr ON appr.id = CASE w.approval_stage
                                      WHEN 'HOD' THEN w.hod_approver_user_id
                                      WHEN 'GM'  THEN w.gm_approver_user_id END
WHERE w.request_status IN ('SUBMITTED', 'UNDER_REVIEW') AND w.approval_stage IN ('HOD', 'GM')
ORDER BY eligible_today, w.approval_stage, w.request_no;

-- 6. Self-approval exposure (D4): open requests (not yet approved) where the requester is also
--    a named approver, or is ADMIN/SUPER_ADMIN and could approve at any stage today. Each row
--    must be re-routed to another approver before strict self-approval is switched on.
SELECT w.request_no, w.project_name, w.request_status, w.approval_stage,
       req.email AS requester, req.role AS requester_role,
       (w.hod_approver_user_id = w.requester_user_id) AS requester_is_hod,
       (w.gm_approver_user_id  = w.requester_user_id) AS requester_is_gm,
       (req.role IN ('ADMIN', 'SUPER_ADMIN'))          AS requester_is_admin,
       -- true = the stage still to be decided belongs to the requester: must be re-routed.
       -- Rows at GM with requester_is_hod only show a self-endorsement that already happened.
       ((w.approval_stage = 'HOD' AND w.hod_approver_user_id = w.requester_user_id)
        OR (w.approval_stage = 'GM' AND w.gm_approver_user_id = w.requester_user_id)
        OR w.request_status IN ('DRAFT', 'CHANGES_REQUESTED'))  AS needs_rerouting
FROM work_requests w
JOIN users req ON req.id = w.requester_user_id
WHERE w.request_status IN ('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'CHANGES_REQUESTED')
  AND (w.hod_approver_user_id = w.requester_user_id
       OR w.gm_approver_user_id = w.requester_user_id
       OR req.role IN ('ADMIN', 'SUPER_ADMIN'))
ORDER BY w.request_status, w.request_no;

-- 7. Project visibility exposure (Q1, Q3, Q5): per active user, how many projects they reach
--    through a direct relationship (requester, team lead, active member) versus only through
--    their organisation position. The "position only" projects are what a user would lose if
--    delivery and read rights end up relationship-based or narrower than today.
WITH RECURSIVE user_subtree AS (
    SELECT u.id AS user_id, u.organisation_unit_id AS unit_id
    FROM users u WHERE u.is_active AND u.organisation_unit_id IS NOT NULL
    UNION ALL
    SELECT s.user_id, child.id
    FROM user_subtree s JOIN organisation_units child ON child.parent_id = s.unit_id
),
related AS (
    SELECT p.id AS project_id, u.id AS user_id
    FROM projects p JOIN users u ON u.id IN (p.requester_user_id, p.team_lead_id)
    UNION
    SELECT pm.project_id, pm.user_id FROM project_members pm WHERE pm.left_at IS NULL
),
positional AS (
    SELECT p.id AS project_id, s.user_id
    FROM projects p
    JOIN user_subtree s ON s.unit_id IN (p.owning_organisation_unit_id,
                                         p.delivery_organisation_unit_id,
                                         p.requesting_organisation_unit_id)
    WHERE p.status NOT IN ('COMPLETED', 'ARCHIVED')
)
SELECT u.role, u.email,
       (SELECT count(*) FROM related r WHERE r.user_id = u.id) AS related_projects,
       (SELECT count(*) FROM positional po WHERE po.user_id = u.id
          AND NOT EXISTS (SELECT 1 FROM related r WHERE r.user_id = u.id AND r.project_id = po.project_id))
           AS position_only_projects_in_subtree
FROM users u
WHERE u.is_active AND u.role <> 'EXTERNAL_USER'
ORDER BY u.role, position_only_projects_in_subtree DESC, u.email;

-- 8. Pain point tags by unit type and the role of whoever created them (Q-gap: Pain Point
--    Moderator scope levels).
SELECT ou.type AS unit_type, coalesce(cu.role::text, '(unknown)') AS creator_role,
       count(*) FILTER (WHERE t.is_active) AS active_tags, count(*) AS all_tags
FROM pain_point_tags t
JOIN organisation_units ou ON ou.id = t.organisation_unit_id
LEFT JOIN users cu ON cu.id = t.created_by_user_id
GROUP BY ou.type, cu.role
ORDER BY ou.type, creator_role;

-- 9. Open incidents by the role of the assignee (Q1: incident administration).
SELECT coalesce(a.role::text, '(unassigned)') AS assignee_role, i.status, count(*)
FROM incident_support_logs i
LEFT JOIN users a ON a.id = i.assigned_to_user_id
WHERE i.status::text NOT IN ('RESOLVED', 'CLOSED', 'CANCELLED')
GROUP BY a.role, i.status
ORDER BY assignee_role, i.status;

ROLLBACK;
