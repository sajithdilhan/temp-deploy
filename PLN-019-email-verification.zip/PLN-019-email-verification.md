# PLN-019 — Email verification on self-registration

**Status:** PLANNED — blocked by [PLN-018](./PLN-018-feature-flags.md)
**Created:** 2026-09-24
**Last updated:** 2026-09-25
**Backlog:** relates to [CAP-026](../roadmap/BACKLOG.md#cap-026--no-rate-limiting-on-authentication-endpoints), [CAP-031](../roadmap/BACKLOG.md#cap-031--authentication-logs-record-raw-email-addresses)
**RFCs:** RFC-009 (to be written — see Follow-ups)
**ADRs:** ADR-026 (to be written once RFC-009 is accepted)

## Objective

Prove that a self-registering person owns the mailbox before their account can be used. A SUPER_ADMIN switches this on
through the `registration.email-verification` platform setting.

## Problem

`AuthenticationService.RegisterAsync` (`apps/api-dotnet/src/ProjectRepository.Infrastructure/Authentication/AuthenticationService.cs:43`)
does four things:
- checks the domain allow-list (`CorporateEmailPolicy`, [WF-019](../wayfinder/tickets/WF-019-restrict-registration-to-corporate-domains.md));
- creates an active `EXTERNAL_USER`;
- **issues a session on the spot**;
- answers a duplicate email or employee ID with a **409**, which tells an anonymous caller whether an address is registered.

Anyone who can type an unclaimed address on an approved domain gets an account. The API has no email-sending
code at all.

## Decisions

Carried over from the 2026-09-24 draft:
- **Amazon SES**, with a **clickable link**.
- The **account exists but cannot sign in until verified**.
- **Existing and admin-created users count as already verified.**

Made on 2026-09-25:

| Question | Decision |
|---|---|
| After Confirm | Go to **sign-in** with a "verified" banner. The link never grants a session. |
| Sending | **Inline**, after `SaveChanges`. An outbox is a Follow-up. |
| Password reset | **Separate later plan.** The token table and email plumbing are built generically so reset reuses them. |
| Admin support | **Resend** and **Mark as verified**, **SUPER_ADMIN only**. |
| Hosting | **UAT and production are both Windows EC2 + IIS**, in the same AWS account. |
| Lifetimes | **24h link.** Never-verified accounts are **purged after 7 days**. Both configurable. |
| Approval | **Verification alone** grants `EXTERNAL_USER`. There is no admin-approval step. |
| Recipients | **Only allowed-domain addresses ever receive an email.** Any other address gets the same 202, with nothing created or sent. |

## Scope

**Included:**
- the flag and its prerequisite;
- user verification columns and the token table;
- the register, verify, resend, login and refresh behaviour;
- the email abstraction with SES, pickup-directory and disabled senders;
- three email templates;
- rate limiting of the new anonymous endpoints;
- the unverified-account cleanup worker;
- SUPER_ADMIN resend and mark-verified;
- the Angular register, verify-email, login and admin changes;
- ops documentation for SES.

**Not included:** forgot/reset password, an email outbox, admin approval of new users, throttling of login
and refresh (stays under CAP-026), and fixing CAP-031's existing email-bearing log lines.

## Current architecture

- **`AuthController`** (`Api/Controllers/AuthController.cs`) is `[AllowAnonymous]` at `api/auth`.
  - `register` and `login` both return `AuthResponse(User, AccessToken)` and set the HttpOnly refresh cookie.
  - `refresh` rotates the cookie. `logout` revokes it.
- **`AuthenticationExceptionFilter`** returns `{ statusCode, message, error, traceId }`. There is **no `code` field.**
- **`LoginAsync`** (:24): unknown email → 401, `EnsureActive` → 401, bad password → 401, then a session.
  **`RefreshAsync`** (:103) rejects inactive users.
- **`User`** (`Domain/Users/User.cs`) has `IsActive`, which means *deactivated by an administrator*. It must not be
  reused to mean *unverified*.
- **User rows are created by:**
  - `RegisterAsync`;
  - `UserAdministrationMutationService` create (audited `USER_CREATED`);
  - `AdminBootstrapper`;
  - `DemoDataSeeder`;
  - `apps/web-e2e/src/global-setup.ts` (raw SQL `INSERT INTO users`).
- **Rate limiting:** `AddClientLogRateLimiting` (`Api/Observability/ObservabilityServiceExtensions.cs:32`) owns the
  single `AddRateLimiter` call. `app.UseRateLimiter()` is at `Program.cs:413`. `UseForwardedHeaders` is not
  called ([CAP-025](../roadmap/BACKLOG.md#cap-025--configuration-does-not-fail-fast-and-the-secure-cookie-degrades-behind-a-proxy)).
- **Hosted services:** only `ProjectBackfillWorker : BackgroundService`.
- **Configuration:** no public web URL setting exists. `PathBase` (e.g. `/captain`) carries no scheme or host.
- **Audit rules (AGENTS.md):** authentication events and system-driven writes are **not** audited. Registration and
  login are not audited today.
- **Angular:**
  - `AuthService.register` and `login` both `tap(setSession)`.
  - The register page navigates to `/dashboard` and maps 409 to "already exists".
  - The login page maps 401 to "Invalid email or password".
  - There is no query-param banner mechanism.
  - "Forgot Password?" (`login.component.html:42`) is a dead `href="#"` link.

## Proposed implementation

### The flag

- `FeatureFlagKeys.EmailVerification = "registration.email-verification"`:
  - default **off**;
  - `ClientVisible = true`;
  - confirmation text: *"New registrations will need to verify their email address."*
- **Prerequisite** (`IFeatureFlagPrerequisite`): `Email:Provider` is `Ses`, or `Pickup` only in Development;
  `Email:FromAddress` and `App:PublicWebBaseUrl` are set. Otherwise enabling returns 409 with the reason.
  This stops the flag being switched on in a way that locks out every new registrant.
- **Read at request time** by register, login, refresh and resend. It is never cached per user. Verify is **not** gated,
  so a link issued while the flag was on still works after it is switched off.
- **Flag off** means today's behaviour: 200 + session, and 409 on duplicates. New users are stamped `NotRequired`, so
  switching the flag on later never locks anyone out. Switching it off lets pending users sign in. That is the escape
  hatch if SES breaks.

### Data — migration `AddEmailVerification`

- **`users` columns:**
  - `email_verified_at timestamp(6) with time zone NULL`;
  - `email_verification_source text NULL`;
  - a check constraint that both are null or both are set.
- **Enum `EmailVerificationSource`:**
  - `Link`
  - `NotRequired` (registered while the flag was off)
  - `AdminCreated`
  - `AdminVerified`
  - `Backfill`
  - `System` (bootstrap and demo seed)
- **Backfill:** existing rows get `now()` / `Backfill`.
- **Stamping on every creation path:**
  - `UserAdministrationMutationService` create → `AdminCreated`;
  - `AdminBootstrapper` → `System`;
  - `DemoDataSeeder` → `System`;
  - `apps/web-e2e/src/global-setup.ts` sets both columns in its INSERT.
- **New table `user_email_tokens`:**
  - Columns: `id uuid PK`, `user_id uuid FK → users ON DELETE CASCADE`, `purpose text`, `token_hash text UNIQUE`,
    `expires_at`, `consumed_at NULL`, `created_at`. Index on `(user_id, purpose, created_at)`.
  - `purpose` is `EMAIL_VERIFICATION` for now; the password-reset plan adds `PASSWORD_RESET`.
  - **Token format:** the same as refresh tokens, 32 random bytes as 64 lowercase hex characters. Only the
    SHA-256 is stored. Reuse `AuthenticationService.HashToken` and the `IsValidRawToken` shape.
  - Issuing a token deletes earlier unconsumed tokens for the same user and purpose.
- **Options `Authentication:EmailVerification`:** `TokenLifetimeHours = 24`, `UnverifiedRetentionDays = 7`,
  `ResendCooldownSeconds = 60`, `DailySendCap = 5`.

### Flows (flag on)

1. **`POST /api/auth/register`**. The allow-list check (`CorporateEmailPolicy`) still runs first, before any lookup,
   but **while the flag is on a refused domain no longer gets a 400**. It gets the same 202 as every other case
   (decision 2026-09-25; see *Allowed domains only* below). Then:

   | Situation | Action |
   |---|---|
   | Domain not on the allow-list | **Nothing is looked up, written or sent.** `LogWarning("Registration rejected for domain {EmailDomain}: domain not allowed")`. Only the domain is logged, not the address |
   | Email new, employee ID free | Create the user unverified, create the token, `SaveChanges`, send **"Verify your email"** |
   | Email exists, unverified | Resend (cooldown and cap apply). **The submitted details are ignored; nothing is overwritten** |
   | Email exists, verified | Send **"You already have an account"** (cooldown and cap apply) |
   | Email new, employee ID taken | Send **"We couldn't complete your registration — contact your administrator"**; `LogWarning` |

   **Every case returns the same `202 { status: "verification_pending" }`**, with no cookie and no access token.
   This replaces the 409 and closes account enumeration. It also replaces the WF-019 400 for refused domains, so the
   response does not say whether an address was accepted. Every allowed-domain branch sends inline, which keeps their
   timing comparable. The refused-domain branch does no work, so it answers faster (see Risks).
2. **`POST /api/auth/verify-email { token }`**:
   - Malformed or unknown token: 400 `code: verification_link_invalid`.
   - Token consumed: 400 `verification_link_invalid`. Expired: 400 `verification_link_expired`.
   - User already verified (for example an admin marked them): 204, idempotent.
   - Otherwise: set `EmailVerifiedAt = now`, `Source = Link`, consume the token, delete the user's other verification
     tokens, return 204.
   - Log `LogInformation("Email verified for user {UserId}")`. **No audit row**: verification is an authentication
     event, which the AGENTS.md Audit Rules exclude.
   - Verifying uses POST rather than GET so corporate link scanners (e.g. Defender Safe Links) don't use up the token.
3. **`POST /api/auth/resend-verification { email }`**. Always returns 202. It sends only if the address is on the
   allow-list, the user exists and is active and unverified, and the request is within limits. The **cooldown and daily cap are derived from token `created_at`**, so
   there is no in-memory state and they survive app-pool recycles. When the flag is off it does nothing.
4. **Login** (`LoginAsync`): after `EnsureActive` **and a successful password check**, if the flag is on and
   `EmailVerifiedAt` is null, return **403 `code: email_not_verified`**. This happens only after the password is proven,
   so it tells an attacker nothing.
5. **Refresh** (`RefreshAsync`): if the flag is on and the user is unverified, return 401. This covers a pending user
   who signed in while the flag was off.
6. **Cleanup:** `UnverifiedAccountCleanupWorker : BackgroundService`, daily, modelled on `ProjectBackfillWorker`.
   - It deletes users that meet all of these, together with their tokens:
     - unverified;
     - `EXTERNAL_USER`;
     - `created_at` older than the retention period;
     - **never held a refresh token**, so they own nothing.
   - It logs the count and user ids.
   - **No audit row:** this is a system-driven write, which AGENTS.md excludes. RFC-009 states this exception to the
     "every hard delete" rule explicitly.
   - Purging matters because an unverified row holds both the email and the employee ID. A typo or a squatter would
     otherwise block the real person.
7. **Admin (SUPER_ADMIN only).**
   - The admin user DTO gains `emailVerifiedAt` and `emailVerificationSource`.
   - `POST /api/admin/users/{id}/verification-email`: resend. The daily cap applies, the cooldown doesn't.
     Audited `USER_VERIFICATION_EMAIL_RESENT`. If the user's domain is no longer on the allow-list, it returns
     **409 `code: email_domain_not_allowed`** and sends nothing. The administrator is authenticated, so being told is
     correct here. *Mark as verified* stays available for that case.
   - `POST /api/admin/users/{id}/mark-email-verified`: sets `AdminVerified`. Audited
     `USER_EMAIL_MARKED_VERIFIED` with old and new values.
   - Both log `LogInformation("… for user {UserId} by {ActorId}")`, carry `[Authorize(Roles = "SUPER_ADMIN")]` next to
     the profile PATCH at `AdministrationReadsController.cs:72`, and re-check the role in the service.
8. **Error codes.** `AuthenticationException` gains an optional `Code`. `AuthenticationExceptionFilter` emits it as
   `code`, and maps 403 → "Forbidden" and 429 → "Too Many Requests".

### Allowed domains only (decision 2026-09-25)

Account emails (verify, already registered, could not complete) are sent **only to addresses on
`Authentication:Registration:AllowedEmailDomains`**. To anyone else, nothing is sent and the caller cannot tell.
This limits two kinds of abuse: using the register or resend endpoint to send mail to arbitrary third parties (spam
relay, harm to the SES sender reputation), and probing which addresses or domains are accepted.

- **One guard, at the point of sending.** The component that builds and sends account emails (e.g.
  `AccountEmailService`) calls `CorporateEmailPolicy.IsAllowed` immediately before every `IEmailSender.SendAsync`,
  whatever the caller. If the address is refused, it skips the send and logs
  `LogWarning("Account email suppressed for {EmailDomain}: domain not allowed")`.
  The register check (Flow 1) is the first line; this guard is defence in depth. It also covers a domain **removed**
  from the list after an unverified account was created. That account then simply gets no more emails and is purged
  by the cleanup worker.
- **Anonymous callers never learn the outcome.** Register and resend return the same 202 whether the email was sent,
  suppressed, rate-limited or failed.
- **The allow-list is enforced whether the flag is on or off** (confirmed 2026-09-25). No outside domain can ever
  register. With the flag off, registration still refuses a non-allowed domain with the WF-019 400 and the generic
  `CorporateEmailPolicy.RejectionMessage`, which names no domain. That 400 gains `code: email_domain_not_allowed` so
  the form can attach it to the email field.
- **The server's configuration is the only copy of the list** (decision 2026-09-25). `Authentication:Registration:AllowedEmailDomains`
  in `appsettings.json` is read by the backend alone. **No UI, bundle, endpoint or response may reveal an allowed
  domain.** In particular, the list must not be added to `/api/features` or any other anonymous endpoint.
  See *Remove the domain list from the frontend* below.
- **Admin resend** to an address whose domain has since been removed from the list returns 409
  `email_domain_not_allowed` and sends nothing. **Mark as verified** stays available for that account (confirmed 2026-09-25).

### Remove the domain list from the frontend (decision 2026-09-25)

The Angular bundle currently ships the list, so anyone can read it by inspecting the page. Remove every copy and every
hint:

| Where | Change |
|---|---|
| `features/auth/pages/register/register.component.ts:33-51` | Delete the domain array and `corporateEmailDomainValidator`, and drop it from the email control's validators (~:101). Keep `Validators.required` and `Validators.email`. |
| `register.component.spec.ts` | Remove the domain-list cases (:37-97). Add: a server 400 `email_domain_not_allowed` shows *"Please use your company email address."* on the email field. |
| `register.component.ts` `emailError()` / submit error handling | The domain message now comes only from the server's 400 (flag off). With the flag on, the user sees "check your inbox" whatever they typed. |
| `features/auth/pages/login/login.component.html:24` | Placeholder `name@stengg.com` → `name@company.com`. |
| `features/admin/pages/admin-people.component.html:341` | Placeholder `name@stengg.com` → `name@company.com`. |
| `shared/ui/form-field/form-field.component.ts:20`, `shared/ui/README.md:171` | Example placeholder → `name@company.com` (not shipped, but keeps the real domain out of UI examples). |

### A domain change is purely an `appsettings` change (decision 2026-09-25)

`Authentication:Registration:AllowedEmailDomains` is the **single source**. Adding, removing or renaming a domain
must need no code change, no frontend rebuild, no test edit and no restart. Today two things break that:

1. **The value is read once at startup.** `AuthenticationService` takes `IOptions<RegistrationOptions>` and copies
   `.Value` in its constructor (`AuthenticationService.cs:17,22`). `DependencyInjection.cs:115-133` binds it with a
   `Configure` delegate, which does not track configuration changes. An edit to `appsettings.json` therefore waits for
   an app-pool recycle.
   - **Change:** register a `ConfigurationChangeTokenSource<RegistrationOptions>` for the
     `Authentication:Registration` section next to the existing `Configure` delegate.
   - Every reader (`AuthenticationService` register, `AccountEmailService` send guard, resend, admin resend) takes
     `IOptionsMonitor<RegistrationOptions>` and reads `.CurrentValue` **per call**, never in a constructor.
   - `WebApplication.CreateBuilder` already loads `appsettings*.json` with `reloadOnChange: true`, so an edited file
     is applied to the next request.
   - An `OnChange` handler logs `LogInformation("Registration allow-list reloaded: {DomainCount} domains")`.
     It logs the count only, and warns if the count is 0, since that refuses everyone.
   - The fail-closed rule is kept: an empty or unreadable section refuses all registrations.
   - Environment-variable overrides (`Authentication__Registration__AllowedEmailDomains__0`) are read at process start,
     so changing one still needs a recycle. The plan and ADR-026 say so; `appsettings.json` is the documented place to change domains.
2. **A test pins the shipped list.** `LocalPostgreSqlRegistrationDomainTests.cs:44` asserts the six-plus-two literal
   domains. Rewrite it to read the expected list from the API project's `appsettings.json` at test time and assert that
   binding matches it and is non-empty. Then a domain change never needs a test edit. `CorporateEmailPolicyTests` keeps
   its literal fixtures, because they test the matching rules against a list passed in, not the shipped configuration.

**No code in either app may name an allowed domain.** A test (or the build check below) greps `apps/web/src`
and `apps/api-dotnet/src` (excluding `appsettings*.json`) for each configured domain and fails on a hit. Test
projects are excluded.

Acceptance for this part: a production build (`dist/apps/web`) contains **none** of the configured domains. Check this
with a grep of the output for each configured domain, and add it to Validation.

This part does **not** depend on the flag or on PLN-018. It can ship as the first slice of this plan (Phase 0).

### Email sending

- **Application:** `IEmailSender.SendAsync(EmailMessage message, CancellationToken)`, where
  `EmailMessage(To, Subject, TextBody, HtmlBody)` carries no AWS types.
- **Infrastructure/Email:**
  - `SesEmailSender` uses `AWSSDK.SimpleEmailV2` and `AWSSDK.Extensions.NETCore.Setup` (`AddAWSService<IAmazonSimpleEmailServiceV2>()`),
    with the **SDK default credential chain**. See the AWS section; the code never reads keys.
  - `PickupDirectoryEmailSender` writes `.eml` files for local development and Playwright.
  - `DisabledEmailSender` is the default; it logs that a send was skipped and never logs the link.
- **`EmailOptions`**, section `Email`:
  - `Provider` (`Disabled` | `Pickup` | `Ses`);
  - `FromAddress`, `FromName`;
  - `PickupDirectory`;
  - `Ses:Region`, `Ses:ConfigurationSet`.
- **`App:PublicWebBaseUrl`** (e.g. `https://<host>/captain`) builds `…/verify-email?token=…`. It is **never taken from
  the request Host header.**
- The startup configuration line in `Program.cs` reports the email provider and whether the base URL is configured.
  No secrets are logged.
- **Templates:** embedded `.txt` + `.html` for each message (verify, already registered, could not complete), with
  HTML-encoded placeholders.
- **Failures:** send after `SaveChanges`. On failure, `LogError(ex, "Verification email send failed for user {UserId}")`,
  and the response is still 202. The user can press Resend.
- **Logging:** new log lines use `{UserId}`, never an email address. The CAP-031 debt is not copied. Tokens and links
  are never logged.

### Abuse controls

- A new rate-limit policy, `auth-anonymous`, on register, verify-email and resend-verification:
  - fixed window, partitioned by remote IP, 429 on rejection;
  - added **inside the same `AddRateLimiter` call** as the client-logs policy, or through
    `services.Configure<RateLimiterOptions>`, so `RejectionStatusCode` is not set twice.
- Without `UseForwardedHeaders` (CAP-025), an IP partition behind a load balancer is per proxy. The **per-address
  cooldown and daily cap in the database are the primary control.**
- Tokens are single-use, expire, are compared by hash, and are invalidated when a new one is issued.

### Frontend (`apps/web/src/app/features/auth/`)

- **`AuthService.register`** returns a discriminated result: `session` (200, flag off, same as today) or `pending`
  (202, no session set).
- **Register page:** on `pending`, show a **"Check your inbox"** state naming the address, with a Resend button and
  cooldown messaging. The 409 handling stays for flag-off.
- **New `verify-email` page**, route `verify-email`, with no guard:
  - It reads `token` and strips it from the address bar with `history.replaceState`.
  - It shows a **Confirm** button that calls the verify endpoint.
  - Success navigates to `/login?verified=1`.
  - An invalid or expired link shows a resend form (email input).
- **Login page:**
  - `?verified=1` shows the banner *"Email verified — please sign in."* This is a new mechanism; none exists today.
  - `403 email_not_verified` shows a message with a **Resend verification email** action.
- **Admin user panel:** an *Email not verified* badge, plus **Resend** and **Mark as verified** actions shown to
  SUPER_ADMIN only.
- The register page may read `registration.email-verification` from `FeatureFlagService` for its copy. The server's
  200 or 202 response is what actually decides.

## AWS credentials — how the app authenticates to SES

Rule: **no long-lived AWS keys in `appsettings*.json`, `web.config`, source control or the build artifact.**
`AddAWSService<IAmazonSimpleEmailServiceV2>()` uses the SDK's **default credential chain**, so each environment
puts credentials where the chain looks. Only `Email:Ses:Region` (and optionally `AWS:Profile`) go in configuration.

| Environment | Credential source | Notes |
|---|---|---|
| **UAT and production — Windows EC2 + IIS** | **EC2 instance profile (IAM role)** | Temporary credentials served by IMDSv2 that rotate automatically. Nothing is stored on disk. The role gets only `ses:SendEmail` / `ses:SendRawEmail` on the one SES identity, with a `ses:FromAddress` condition. |
| Local development | `aws configure sso` / named profile in `%USERPROFILE%\.aws` | Each developer uses their own credentials; set `AWS:Profile` in user-secrets. Most developers never need them, because the default dev sender is the pickup directory. |
| CI / tests | None | Tests use the pickup or disabled sender. |
| Fallback if an instance role is not allowed | IAM user access key stored in **AWS Secrets Manager** or **SSM Parameter Store (SecureString)** and loaded at startup, *or* set as environment variables on the IIS app pool (`<environmentVariables>` in applicationHost.config, readable only by admins) | Rotate the key every 90 days or less, limit it to the same SES-only policy, and alarm on key age. Never use SES **SMTP** credentials, which are long-lived keys derived from an IAM user. |

- **IIS:** the SDK reaches IMDS whatever account the app pool runs as. Require **IMDSv2**; a hop limit of 1 is fine
  because IIS runs on the host. Check that the Windows firewall does not block `169.254.169.254`.
- **Least privilege:** use a dedicated role or policy for this app. If the EC2 role is already broad, split it rather
  than adding SES to an admin-like role.
- **Detection:** CloudTrail records SES API calls, and SES sending quotas cap the damage from misuse.
- **Other secrets on the box** (DB connection string, JWT signing key) could move to Secrets Manager or SSM through the
  same instance role. That is out of scope here; see CAP-024.

## AWS / SES setup checklist (ops)

1. Pick a sender identity, ideally a **subdomain** (e.g. `noreply@projrepo.<corp-domain>`). IT adds the **DKIM CNAMEs,
   SPF include and DMARC** records. Sending as the bare corporate domain without DKIM is likely to be quarantined.
2. Verify the domain identity in SES in the chosen region. **Request production access** to leave the sandbox;
   the sandbox only delivers to verified recipients, which may be enough for early UAT.
3. Grant the EC2 instance role `ses:SendEmail` limited to that identity, with a `ses:FromAddress` condition.
4. Network: outbound HTTPS to `email.<region>.amazonaws.com`, or an **SES VPC interface endpoint** if the subnet has no
   internet egress.
5. Optional: a configuration set with SNS or EventBridge for bounces and complaints, and a CloudWatch alarm on bounce rate.
6. Set `Email__Provider=Ses`, `Email__FromAddress`, `Email__Ses__Region` and `App__PublicWebBaseUrl` on the IIS app
   pool. Then a SUPER_ADMIN enables **Registration email verification** in Administration → Platform settings.

If SES is blocked, the alternatives are the corporate M365 relay, Microsoft Graph `sendMail`, or SendGrid.
`IEmailSender` makes swapping providers a one-class change.

## Impact

**Frontend:** hard-coded domain list and validator removed, and domain placeholders genericised; register "check your inbox" state, new verify-email page and route, login banner and 403 handling,
admin user panel badge and actions.
**Backend:** `AuthenticationService` register, login and refresh; new verify and resend; `Infrastructure/Email/*`;
cleanup worker; admin actions; rate-limit policy; `AuthenticationException.Code`.
**Database:** two `users` columns with backfill; the `user_email_tokens` table.
**API:**
- `POST /api/auth/register` returns **202 with no session when the flag is on**. This is a contract change;
  flag off is unchanged.
- New: `POST /api/auth/verify-email`, `POST /api/auth/resend-verification`,
  `POST /api/admin/users/{id}/verification-email`, `POST /api/admin/users/{id}/mark-email-verified`.
- Error bodies gain `code`.

**Permissions/security:**
- closes registration enumeration;
- proves mailbox ownership;
- SUPER_ADMIN-only admin actions;
- anonymous endpoints rate-limited;
- no stored AWS keys.

**Migration considerations:** additive. Every existing user is backfilled as verified, so nobody is locked out.
Nothing changes until the flag is enabled.

## Implementation phases

### Phase 0 — Take the domain list out of the frontend (independent; can ship first)

Status: TODO

- [ ] Remove the domain array and `corporateEmailDomainValidator` from `register.component.ts`, and update its spec
- [ ] Show the server's 400 `email_domain_not_allowed` on the email field. The backend adds `code` to that 400; the
  filter change is the `AuthenticationException.Code` item in Phase C, pulled forward
- [ ] Replace the `name@stengg.com` placeholders (login, admin people, form-field example, shared UI README) with `name@company.com`
- [ ] Verify the production build output contains none of the configured domains
- [ ] Backend reads the list live: `ConfigurationChangeTokenSource<RegistrationOptions>` + `IOptionsMonitor` with
  `.CurrentValue` per call in `AuthenticationService`; reload log line with the count only
- [ ] Rewrite `LocalPostgreSqlRegistrationDomainTests` to take its expected list from `appsettings.json`, not literals
- [ ] Add the "no allowed domain named in source" check

### Phase A — Email infrastructure

Status: TODO

- [ ] `IEmailSender`, `EmailMessage`, `EmailOptions`, `App:PublicWebBaseUrl`
- [ ] `SesEmailSender`, `PickupDirectoryEmailSender`, `DisabledEmailSender`, DI selection by provider
- [ ] Embedded templates (three messages); startup configuration log line

### Phase B — Schema and stamping

Status: TODO

- [ ] `User` columns, `EmailVerificationSource`, `UserEmailToken` entity and configuration, migration `AddEmailVerification` with backfill
- [ ] Stamp in admin create, `AdminBootstrapper`, `DemoDataSeeder`, and the `web-e2e` global setup

### Phase C — Authentication flows

Status: TODO

- [ ] Flag `registration.email-verification` and its prerequisite (depends on PLN-018)
- [ ] Register (202 in every case), verify-email, resend-verification, login 403, refresh 401
- [ ] `AuthenticationException.Code` and filter mapping; `auth-anonymous` rate-limit policy

### Phase D — Cleanup worker

Status: TODO

- [ ] `UnverifiedAccountCleanupWorker` with eligibility rules and logging

### Phase E — Admin actions

Status: TODO

- [ ] DTO fields, resend and mark-verified endpoints and service methods, audit and log

### Phase F — Frontend

Status: TODO

- [ ] `AuthService` discriminated register result; register pending state
- [ ] `verify-email` page and route; login banner and `email_not_verified` handling
- [ ] Admin user panel badge and SUPER_ADMIN actions

### Phase G — Ops and docs

Status: TODO

- [ ] "Outbound email (SES)" section in `docs/deployment/production.md`
- [ ] ADR-026; CURRENT / COMPLETED / ROADMAP on completion

## Risks

- **SES deliverability.** Without DKIM, SPF and DMARC on the sender domain, mail may be quarantined. Enabling
  the flag depends on IT DNS work and SES production access.
- **Corporate link scanners.** Mitigated by confirming with a POST button rather than on GET.
- **Inline send.** An SES outage or app-pool recycle mid-send loses the email. Mitigations: Resend, admin Resend
  and Mark as verified, and switching the flag off. An outbox is a Follow-up.
- **Timing side channel.** A refused-domain register does no database work and sends nothing, so it would answer
  faster than an accepted one (which hashes a password with Argon2id and calls SES). Once the list is out of the
  bundle, that difference would be the only way to probe for allowed domains while the flag is on.
  - **Mitigation:** with the flag on, register and resend-verification give every 202 the same **minimum response
    time** (`Authentication:EmailVerification:MinimumResponseMilliseconds`, default 1500). The response waits until the
    floor is reached, whichever branch ran.
  - This also evens out the timing between address-level branches.
  - RFC-009 records it.
- **With the flag off, a 400 answers per guess.** Someone can still test one domain at a time, because the refusal is
  what enforces the list. They cannot read the list, and the `auth-anonymous` rate limit bounds guessing. Accepted:
  the requirement is that no outside domain can register.
- **A genuine user whose domain is missing from configuration** can't register. With the flag on they see "check your
  inbox" and nothing arrives; with the flag off they see "Please use your company email address." Either way the fix
  is adding the domain to `AllowedEmailDomains`, which needs no deployment.
- **Register contract change.** Flag on returns 202 and no session. The frontend must handle both 200 and 202, and
  the 409 disappears while the flag is on.
- **Per-IP limits behind a proxy** are coarse until CAP-025 adds forwarded headers. The database-derived per-address
  limits are the main control.

## Validation

- [ ] **Flag off:** registration unchanged (200 + session, 409 on duplicates); the user is stamped `NotRequired`;
  a pending user can sign in.
- [ ] **Domain list not exposed:** `pnpm nx run web:build:production`, then grep `dist/apps/web` for every configured
  domain; there should be zero hits. No API response contains an allowed domain (`/api/features`, register errors,
  admin responses). The flag-off 400 message names no domain.
- [ ] **Change without restart:** in an integration test, edit the bound configuration (reloadable in-memory or temp
  JSON provider): add a domain, and the next register from it is accepted; remove it, and the next is refused. No
  restart and no code change in between. Manual UAT check: edit `appsettings.json` on the IIS box, and the next
  registration reflects it without an app-pool recycle.
- [ ] **Allow-list enforced with the flag off:** a non-allowed domain returns 400 `email_domain_not_allowed`, with no
  user row, cookie or token (the WF-019 integration tests still pass). The register form shows the message on the email field.
- [ ] **Minimum response time (flag on):** register and resend 202s for refused-domain, new, existing and
  employee-ID-taken cases all take at least the configured floor.
- [ ] **Allowed domains only:**
  - Flag on: register with a non-allowed domain, including the lookalikes `stengg.com.attacker.net` and
    `sub.stengg.com` → **202 with the same body**, no user row, no token, **no file in the pickup directory**, and a
    warning that names only the domain.
  - Resend for a non-allowed address → 202, nothing sent.
  - A domain removed from configuration after registration → register-again and resend send nothing; admin resend
    returns 409 `email_domain_not_allowed`.
  - Flag off: a non-allowed domain still returns WF-019's 400.
- [ ] **Flag on:**
  - register returns **202 with no `Set-Cookie` and no access token**, identical for new, existing-unverified,
    existing-verified and employee-ID-taken cases;
  - the right email appears in the pickup directory each time.
- [ ] Login while unverified: 403 `email_not_verified` **only with the correct password**; a wrong password still returns 401.
- [ ] Refresh while unverified with the flag on: 401.
- [ ] Verify: valid → 204 and stamped `Link`; expired → 400 `verification_link_expired`; reused or unknown → 400
  `verification_link_invalid`; already verified → 204.
- [ ] Resend: cooldown and daily cap enforced; unknown address still 202; `auth-anonymous` returns 429 when exceeded.
- [ ] Admin: ADMIN and MODERATOR get 403; both actions write the expected `AuditLog` rows and log lines.
- [ ] Cleanup deletes only eligible users and keeps anyone who ever held a refresh token.
- [ ] Prerequisite: enabling the flag with provider `Disabled` returns 409 with the reason.
- [ ] Migration backfills existing users (`Backfill`) and rolls back cleanly.
- [ ] Angular specs for the pending, verify, banner, 403 and admin states.
- [ ] Playwright: register → read the link from the pickup `.eml` → Confirm → sign in.
- [ ] `dotnet build` / `dotnet test`, `pnpm nx run web:lint`, `web:test`, `web:build:production`.
- [ ] **UAT:** SES sandbox send to a verified inbox, then production access; DKIM=pass in the received headers.
- [ ] **Review:** code-reviewer, security-review (authentication change), architect, design-reviewer; verifier
  against this list.

## Follow-ups (not created yet)

- **RFC-009** "Email verification on self-registration". Changes schema, API contract and authentication.
  - Alternatives: a code instead of a link, automatic sign-in after verifying, an outbox, admin approval,
    SMTP / M365 relay / SendGrid.
  - It states the audit exceptions: a verify link is an authentication event, and the purge is a system-driven write.
- **ADR-026** once RFC-009 is accepted: "Outbound email goes through `IEmailSender` backed by SES; AWS access uses the
  EC2 instance role; no stored keys".
- **Terminology:** *verified account* / *email verification*.
- **Annotate [WF-019](../wayfinder/tickets/WF-019-restrict-registration-to-corporate-domains.md)** when Phase 0
  ships. Its "Frontend, UX only" section (a duplicated browser list) is reversed: the list now lives only in server
  configuration.
- **CAP items** (the backlog's *Next free ID* is stale because CAP-032 is taken, so start at CAP-033):
  - an email outbox with retries;
  - forgot / reset password, reusing `user_email_tokens` with `PASSWORD_RESET`. The login page's
    "Forgot Password?" link (`login.component.html:42`) is currently dead;
  - `docs/deployment/production.md` presents Linux + nginx as the main hosting path, but UAT and production run on
    Windows EC2 + IIS;
  - annotate CAP-026: the anonymous register, verify and resend endpoints are covered here; login and refresh are not.

## Deviations from original plan

## Completion notes
