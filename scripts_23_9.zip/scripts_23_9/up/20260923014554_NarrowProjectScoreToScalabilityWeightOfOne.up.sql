-- Migration: 20260923014554_NarrowProjectScoreToScalabilityWeightOfOne
-- Every Scalability option now weighs 1, so the metric no longer changes a score and the
-- project score ceiling returns to 10,000.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20260922032111_AddWorkRequestScalability;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20260922032111_AddWorkRequestScalability (and any migration between).
-- Roll back with 20260923014554_NarrowProjectScoreToScalabilityWeightOfOne.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20260923014554_NarrowProjectScoreToScalabilityWeightOfOne.up.sql
--
-- THE UPDATE IS NOT OPTIONAL, AND IT MUST RUN BEFORE THE NARROWED CONSTRAINT IS ADDED.
-- While the five "Yes" options weighed 2, any request answered with one of them stored a
-- total that is twice what the new weights produce — up to 20,000. Adding the 1..10,000
-- constraint without first re-scoring those rows fails on exactly the data this change is
-- about.
--
-- The re-score recomputes from the four metric columns rather than halving, so it is
-- idempotent: a row already on the new formula is rewritten to the same value, and a row
-- that was never doubled is left alone. Drafts missing any metric stay unscored.
--
-- Deploy order matters: run this BEFORE starting an API build that applies the new weights.
-- Running it while the previous build is still serving leaves that build briefly showing a
-- halved score for reusable requests, which is the correct new number, not a fault.

START TRANSACTION;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_project_score_check;

UPDATE work_requests
SET project_score = complexity_score
                  * annual_cost_saving_score
                  * capex_required_score
                  * pain_point_frequency_score
WHERE project_score IS NOT NULL
  AND complexity_score IS NOT NULL
  AND annual_cost_saving_score IS NOT NULL
  AND capex_required_score IS NOT NULL
  AND pain_point_frequency_score IS NOT NULL
  AND scalability IS NOT NULL;

ALTER TABLE work_requests ADD CONSTRAINT work_requests_project_score_check CHECK (project_score IS NULL OR project_score BETWEEN 1 AND 10000);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20260923014554_NarrowProjectScoreToScalabilityWeightOfOne', '10.0.8');

COMMIT;
