-- Rollback: 20260923014554_NarrowProjectScoreToScalabilityWeightOfOne
-- Reverts the database to 20260922032111_AddWorkRequestScalability.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20260923014554_NarrowProjectScoreToScalabilityWeightOfOne.down.sql
--
-- Restores the 20,000 ceiling and the doubling that went with it: every request answered
-- with a "Yes" option (codes 2-6) has its score multiplied by 2 again, because under the
-- previous weight table only "Not applicable" weighed 1.
--
-- This does NOT fail the way the 20260922032111 rollback can — it widens the bound rather
-- than narrowing it, so no existing row can violate the result.
--
-- IT IS NOT IDEMPOTENT. Unlike the up script, this one multiplies rather than recomputes,
-- so running it twice doubles twice and leaves scores at four times the correct value,
-- possibly above the restored ceiling. Run it exactly once. To check afterwards:
--
--   SELECT id, scalability, project_score,
--          complexity_score * annual_cost_saving_score
--        * capex_required_score * pain_point_frequency_score
--        * CASE WHEN scalability = 1 THEN 1 ELSE 2 END AS expected
--   FROM work_requests WHERE project_score IS NOT NULL;
--
-- Only roll back alongside the API build that expects the old weights. Leaving a doubled
-- score in front of a build that weighs everything 1 shows every reusable request at twice
-- its score until the next edit re-scores it.

START TRANSACTION;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_project_score_check;

ALTER TABLE work_requests ADD CONSTRAINT work_requests_project_score_check CHECK (project_score IS NULL OR project_score BETWEEN 1 AND 20000);

UPDATE work_requests
SET project_score = project_score * 2
WHERE project_score IS NOT NULL
  AND scalability IS NOT NULL
  AND scalability <> 1;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20260923014554_NarrowProjectScoreToScalabilityWeightOfOne';

COMMIT;
