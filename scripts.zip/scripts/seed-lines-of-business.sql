-- Reference data: lines of business, their business-unit membership, and the business-unit renames.
-- RFC-012 D1 / PLN-023 / ADR-033. SQL equivalent of the line-of-business and rename steps of
-- `ProjectRepository.Api --seed-reference` (PrioritisationReferenceSeeder), for environments where the seed cannot be run (UAT).
--
-- Run AFTER 20261014105755_AddLinesOfBusiness.up.sql has been applied:
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f seed-lines-of-business.sql
--
-- Same rules as the seeder, so it is safe to run more than once and never overwrites an administrator's change:
--   * Renames apply only while a row still carries its originally seeded name, and are skipped if a sibling already has the new name.
--   * A line is created only if no line with that code (case-insensitive) exists in the business area, and is skipped if a line
--     with that name exists. An existing line is not touched: a renamed, retired or re-membered line stays as it was left.
--   * A member unit that is not an existing business unit of the area is skipped with a NOTICE.
--
-- Unlike the seeder it does NOT create the group, the business area, the business units or the scoring model. It stops with an
-- error if the "Commercial Aerospace" business area (code STE-BU) is missing. A business unit missing from the database is
-- skipped with a NOTICE (read the output). Nothing is written to the audit log, as with the seeder.
--
-- TODO (RFC-012 open question 3): "CIES" under Freighter Conversion is not seeded; see PrioritisationReferenceSeeder.LinesOfBusiness.
--
-- Check afterwards (expect 12 lines and 21 membership rows over 20 units; second query returns no rows):
--   SELECT count(*) FROM lines_of_business;
--   SELECT u.code FROM organisation_units u
--   WHERE u.type = 'BUSINESS_UNIT' AND u.code LIKE 'STE-%'
--     AND NOT EXISTS (SELECT 1 FROM line_of_business_units m WHERE m.organisation_unit_id = u.id);
--
-- Undo (only before requests are tagged with a line; work_requests.line_of_business_id is RESTRICT):
--   DELETE FROM lines_of_business WHERE normalized_code LIKE 'LOB-%';   -- membership rows cascade

START TRANSACTION;

DO $$
DECLARE
    area_id uuid;
    line_id uuid;
    unit_id uuid;
    rec record;
    unit_code text;
    now_ts timestamptz := CURRENT_TIMESTAMP;
BEGIN
    SELECT id INTO area_id
    FROM organisation_units
    WHERE normalized_code = 'STE-BU' AND type = 'BUSINESS_AREA' AND parent_id IS NOT NULL;
    IF area_id IS NULL THEN
        RAISE EXCEPTION 'Business area STE-BU (Commercial Aerospace) not found; the organisation reference data has not been seeded here.';
    END IF;

    -- 1. Renames: (code, original name, new name). Only while the row still has the original name.
    FOR rec IN
        SELECT * FROM (VALUES
            ('STE-BU',      'ST Engineering Business Units', 'Commercial Aerospace'),
            ('STE-GZ',      'ST Aerospace Guangzhou',        'ST Engineering Aerospace (Guangzhou)'),
            ('STE-HUBEI',   'ST Aerospace Hubei',            'ST Engineering Aerospace (Hubei)'),
            ('STE-SAA',     'San Antonio Aerospace',         'San Antonio'),
            ('STE-PNS',     'Pensacola Aerospace',           'Pensacola'),
            ('STE-ECO',     'Ecoservices',                   'EcoServices'),
            ('STE-PRECMFG', 'Precision Manufacturing',       'Precision Products Services'),
            ('STE-UAS',     'UAS',                           'Unmanned Air Systems')
        ) AS r(code, original_name, new_name)
    LOOP
        UPDATE organisation_units u
        SET name = rec.new_name, updated_at = now_ts
        WHERE u.normalized_code = rec.code
          AND u.parent_id IS NOT NULL
          AND (u.id = area_id OR u.parent_id = area_id)
          AND u.name = rec.original_name
          AND NOT EXISTS (SELECT 1 FROM organisation_units o
                          WHERE o.parent_id = u.parent_id AND o.id <> u.id AND o.name = rec.new_name);
        IF FOUND THEN
            RAISE NOTICE 'Renamed % from "%" to "%"', rec.code, rec.original_name, rec.new_name;
        END IF;
    END LOOP;

    -- 2. Lines of business and their members.
    FOR rec IN
        SELECT * FROM (VALUES
            ('LOB-AFS',  'Airframe Services',                      ARRAY['STE-SVCCO','STE-GZ','STE-HUBEI','STE-SAA','STE-PNS']),
            ('LOB-AAM',  'Aviation Asset Management',              ARRAY['STE-AAM']),
            ('LOB-CIES', 'Cabin Interiors & Engineering Solutions', ARRAY['STE-CIES']),
            ('LOB-CS',   'Component Services',                     ARRAY['STE-SYS','STE-VSTEA']),
            ('LOB-CP',   'Composite Panels',                       ARRAY['STE-EFW']),
            ('LOB-ES',   'Engine Services',                        ARRAY['STE-ENG','STE-ECO','STE-STATCO']),
            ('LOB-FC',   'Freighter Conversion',                   ARRAY['STE-EFW']),
            ('LOB-NAC',  'Nacelles',                               ARRAY['STE-MRAS']),
            ('LOB-NS',   'Nacelle Services',                       ARRAY['STE-SOL']),
            ('LOB-PPS',  'Precision Products Services',            ARRAY['STE-PRECMFG']),
            ('LOB-UAS',  'Unmanned Air Systems',                   ARRAY['STE-UAS']),
            ('LOB-CAC',  'CA Corporate & Others',                  ARRAY['STE-AIRX','STE-CACORP','STE-OTHERS'])
        ) AS l(code, name, unit_codes)
    LOOP
        IF EXISTS (SELECT 1 FROM lines_of_business WHERE business_area_id = area_id AND normalized_code = upper(rec.code)) THEN
            CONTINUE;
        END IF;
        IF EXISTS (SELECT 1 FROM lines_of_business WHERE business_area_id = area_id AND name = rec.name) THEN
            RAISE NOTICE 'Skipped line % : a line named "%" already exists in the business area', rec.code, rec.name;
            CONTINUE;
        END IF;

        INSERT INTO lines_of_business (id, business_area_id, code, name, is_active, created_at, updated_at)
        VALUES (gen_random_uuid(), area_id, rec.code, rec.name, TRUE, now_ts, now_ts)
        RETURNING id INTO line_id;

        FOREACH unit_code IN ARRAY rec.unit_codes
        LOOP
            SELECT id INTO unit_id
            FROM organisation_units
            WHERE parent_id = area_id AND type = 'BUSINESS_UNIT' AND normalized_code = unit_code;
            IF unit_id IS NULL THEN
                RAISE NOTICE 'Skipped business unit % for line %: it is not a business unit of the area', unit_code, rec.code;
            ELSE
                INSERT INTO line_of_business_units (line_of_business_id, organisation_unit_id) VALUES (line_id, unit_id);
            END IF;
        END LOOP;
        RAISE NOTICE 'Created line % (%)', rec.code, rec.name;
    END LOOP;
END
$$;

COMMIT;
