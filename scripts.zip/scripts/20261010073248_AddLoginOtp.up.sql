-- Migration: 20261010073248_AddLoginOtp
-- PLN-021 / ADR-031: email OTP two-factor login. Adds user_email_tokens.code_hash (SHA-256 of
-- challengeRaw + ':' + code, null once consumed or superseded), user_email_tokens.failed_attempts
-- (integer, default 0) and user_email_tokens.remember_me (boolean, default false) for the new
-- LOGIN_OTP token purpose, and ENDS EVERY LIVE SESSION: each refresh token that is not yet revoked
-- is revoked with revoked_at = now() - interval '1 day', which is outside the API's
-- RotationGraceSeconds window, so none of them can be accepted as a graced rotation. Everyone signs
-- in again, with a code.
--
-- Generated from the EF Core migration of the same name, plus the refresh-token UPDATE. Applying this
-- script is equivalent to `dotnet ef database update` from 20261002064116_AddEmailVerification;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Roll back with 20261010073248_AddLoginOtp.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261010073248_AddLoginOtp.up.sql
--
-- Operational notes: three columns are added to user_email_tokens (a small table; the two NOT NULL
-- columns carry constant defaults, so PostgreSQL adds them without rewriting the table) and one
-- UPDATE touches every unrevoked row of refresh_tokens, taking row locks for the length of that
-- statement; run it in a quiet period. It cannot fail on existing data. NOT safe to run while an
-- old API build serves sign-ins you want to keep: every signed-in user is signed out at this point.
-- Deploy the new API build, which needs a working SMTP relay or it will not start outside
-- Development, together with this script.

START TRANSACTION;
ALTER TABLE user_email_tokens ADD code_hash text;

ALTER TABLE user_email_tokens ADD failed_attempts integer NOT NULL DEFAULT 0;

ALTER TABLE user_email_tokens ADD remember_me boolean NOT NULL DEFAULT FALSE;

UPDATE refresh_tokens SET revoked_at = now() - interval '1 day' WHERE revoked_at IS NULL;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261010073248_AddLoginOtp', '10.0.8');

COMMIT;

