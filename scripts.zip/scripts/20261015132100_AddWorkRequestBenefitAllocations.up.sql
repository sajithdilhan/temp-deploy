-- Migration: 20261015132100_AddWorkRequestBenefitAllocations
-- PLN-024: adds work_request_benefit_allocations, the per-category split of a request's
-- Estimated Cost Savings (COST_SAVINGS) and Estimated Cost Avoidance (COST_AVOIDANCE). Each row
-- holds the requester's percentage and the server-computed amount; the rows of one type total
-- 100% and add back to the base exactly.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261014105818_AddProjectCompletionAndBaselineDates;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Renumbered from 20261014105151, which sorted before RFC-012's three migrations. A database that
-- already applied it under the old id only needs its history row renamed, not this script:
--   UPDATE "__EFMigrationsHistory" SET "MigrationId" = '20261015132100_AddWorkRequestBenefitAllocations'
--   WHERE "MigrationId" = '20261014105151_AddWorkRequestBenefitAllocations';
--
-- Roll back with 20261015132100_AddWorkRequestBenefitAllocations.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261015132100_AddWorkRequestBenefitAllocations.up.sql
--
-- Additive only: a new, empty table. No existing table or row changes, and nothing is
-- back-filled - legacy requests keep their AI/CI amounts. The new SUSTAINABILITY and SAFETY
-- categories need no schema change (project_categories is text[]). Safe to run while an older
-- API build is serving: that build never reads the table.

START TRANSACTION;
CREATE TABLE work_request_benefit_allocations (
    id uuid NOT NULL DEFAULT (gen_random_uuid()),
    work_request_id uuid NOT NULL,
    allocation_type character varying(20) NOT NULL,
    category character varying(40) NOT NULL,
    percentage numeric(5,2) NOT NULL,
    amount numeric(14,2) NOT NULL,
    created_at timestamp(6) with time zone NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    CONSTRAINT work_request_benefit_allocations_pkey PRIMARY KEY (id),
    CONSTRAINT work_request_benefit_allocations_allocation_type_check CHECK (allocation_type IN ('COST_SAVINGS', 'COST_AVOIDANCE')),
    CONSTRAINT work_request_benefit_allocations_amount_check CHECK (amount >= 0),
    CONSTRAINT work_request_benefit_allocations_percentage_check CHECK (percentage >= 0 AND percentage <= 100),
    CONSTRAINT work_request_benefit_allocations_work_request_id_fkey FOREIGN KEY (work_request_id) REFERENCES work_requests (id) ON DELETE CASCADE
);

CREATE UNIQUE INDEX work_request_benefit_allocations_request_type_category_key ON work_request_benefit_allocations (work_request_id, allocation_type, category);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261015132100_AddWorkRequestBenefitAllocations', '10.0.8');

COMMIT;

