-- Rollback: 20260928072534_ScopeOrganisationAndTeamCodesToParent
-- Reverts the database to 20260923014554_NarrowProjectScoreToScalabilityWeightOfOne.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 --     -f 20260928072534_ScopeOrganisationAndTeamCodesToParent.down.sql
--
-- Restores the system-wide unique indexes on organisation_units.code and teams.code and drops
-- normalized_code. No other value changes.
--
-- IT FAILS ONCE A CODE HAS BEEN REUSED. After the up script, BU1 and BU2 may each have FIN;
-- the old system-wide index cannot hold that, so the DO block raises an error and the whole
-- transaction rolls back. Make every code unique first. To find the offenders:
--
--   SELECT code, count(*) FROM organisation_units GROUP BY code HAVING count(*) > 1;
--   SELECT code, count(*) FROM teams GROUP BY code HAVING count(*) > 1;
--
-- Only roll back alongside the API build that does not map normalized_code; the newer build
-- fails to query units and teams once the column is gone.

START TRANSACTION;

DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM organisation_units GROUP BY code HAVING count(*) > 1)
       OR EXISTS (SELECT 1 FROM teams GROUP BY code HAVING count(*) > 1) THEN
        RAISE EXCEPTION 'Cannot roll back: an organisation unit or team code is now used more than once. Make every code unique first.';
    END IF;
END $$;

DROP INDEX teams_organisation_unit_id_normalized_code_key;

DROP INDEX organisation_units_parent_id_normalized_code_key;

DROP INDEX organisation_units_root_normalized_code_key;

ALTER TABLE teams DROP COLUMN normalized_code;

ALTER TABLE organisation_units DROP COLUMN normalized_code;

CREATE UNIQUE INDEX teams_code_key ON teams (code);

CREATE UNIQUE INDEX organisation_units_code_key ON organisation_units (code);

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20260928072534_ScopeOrganisationAndTeamCodesToParent';

COMMIT;

