-- Migration: 20261015132132_AlignCategoryAllocationsWithBenefitAllocations
-- PLN-024 / ADR-035, reconciling PLN-024 with RFC-012 D4: the typed cost savings / cost avoidance allocations
-- (work_request_benefit_allocations) are the source, and the combined category allocation (work_request_category_allocations)
-- is derived from them. Widens work_request_category_allocations_category_check to SUSTAINABILITY and SAFETY and
-- work_request_category_allocations_percentage_check from "> 0" to ">= 0", then brings the stored rows in line.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261015132100_AddWorkRequestBenefitAllocations;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261015132100_AddWorkRequestBenefitAllocations; with psql, run its .up.sql before this one.
-- Roll back with 20261015132132_AlignCategoryAllocationsWithBenefitAllocations.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261015132132_AlignCategoryAllocationsWithBenefitAllocations.up.sql
--
-- REWRITES DERIVED ROWS ONLY:
--   1. Requests with typed allocations: their work_request_category_allocations rows are replaced by the split derived from the
--      typed rows (each category's cost savings + cost avoidance over the total; with no amounts, the cost savings percentages,
--      else the cost avoidance ones, else even). Same rule as CategoryAllocationRules.FromBenefitAllocations; a 0% share is kept.
--   2. Requests ticking SUSTAINABILITY or SAFETY without typed allocations: replaced by the RFC-012 D8 split over all their
--      categories (the earlier backfill skipped those two categories, leaving a split that did not cover the request).
--   3. Requests with a typed cost savings allocation whose AI/CI amounts are both NULL (PLN-024 stored NULL before ADR-035):
--      the amounts become that allocation's AI and CI / Kaizen amounts. A stored amount is never overwritten.
-- Nothing user-entered changes: work_request_benefit_allocations is only read. Safe while the previous API build serves (it
-- writes a subset of what the new checks allow), but deploy the new API with it so new saves derive the split.
-- Check before running, if you wish:
--   SELECT count(DISTINCT work_request_id) FROM work_request_benefit_allocations;
--   SELECT count(*) FROM work_requests WHERE project_categories && ARRAY['SUSTAINABILITY','SAFETY']::text[];

START TRANSACTION;
ALTER TABLE work_request_category_allocations DROP CONSTRAINT work_request_category_allocations_category_check;

ALTER TABLE work_request_category_allocations DROP CONSTRAINT work_request_category_allocations_percentage_check;

ALTER TABLE work_request_category_allocations ADD CONSTRAINT work_request_category_allocations_category_check CHECK (category IN ('AI', 'CI_KAIZEN', 'DIGITALISATION', 'AUTOMATION', 'SUSTAINABILITY', 'SAFETY', 'OTHERS'));

ALTER TABLE work_request_category_allocations ADD CONSTRAINT work_request_category_allocations_percentage_check CHECK (percentage >= 0 AND percentage <= 100);

DELETE FROM work_request_category_allocations
WHERE work_request_id IN (SELECT DISTINCT work_request_id FROM work_request_benefit_allocations);
WITH ticked AS (
    SELECT w.id AS work_request_id, c.category, c.ord
    FROM work_requests w
    CROSS JOIN LATERAL (
        SELECT DISTINCT cat AS category, CASE cat WHEN 'AI' THEN 1 WHEN 'CI_KAIZEN' THEN 2 WHEN 'DIGITALISATION' THEN 3 WHEN 'AUTOMATION' THEN 4 WHEN 'SUSTAINABILITY' THEN 5 WHEN 'SAFETY' THEN 6 ELSE 7 END AS ord
        FROM unnest(w.project_categories) AS cat
        WHERE cat IN ('AI', 'CI_KAIZEN', 'DIGITALISATION', 'AUTOMATION', 'SUSTAINABILITY', 'SAFETY', 'OTHERS')
    ) c
    WHERE w.project_categories IS NOT NULL
      AND EXISTS (SELECT 1 FROM work_request_benefit_allocations a WHERE a.work_request_id = w.id)
),
weighed AS (
    SELECT k.*,
           COALESCE((SELECT sum(a.amount) FROM work_request_benefit_allocations a
                     WHERE a.work_request_id = k.work_request_id AND a.category = k.category), 0) AS amount,
           COALESCE((SELECT sum(a.percentage) FROM work_request_benefit_allocations a
                     WHERE a.work_request_id = k.work_request_id AND a.category = k.category
                       AND a.allocation_type = CASE WHEN EXISTS (SELECT 1 FROM work_request_benefit_allocations s
                                                                 WHERE s.work_request_id = k.work_request_id
                                                                   AND s.allocation_type = 'COST_SAVINGS')
                                                    THEN 'COST_SAVINGS' ELSE 'COST_AVOIDANCE' END), 0) AS pct
    FROM ticked k
),
totals AS (
    SELECT w.*, sum(w.amount) OVER (PARTITION BY w.work_request_id) AS benefit,
           sum(w.pct) OVER (PARTITION BY w.work_request_id) AS pct_total,
           count(*) OVER (PARTITION BY w.work_request_id) AS n
    FROM weighed w
),
shares AS (
    SELECT t.work_request_id, t.category, t.ord,
           round(CASE WHEN t.benefit > 0 THEN 10000 * t.amount / t.benefit
                      WHEN t.pct_total > 0 THEN 10000 * t.pct / t.pct_total
                      ELSE 10000.0 / t.n END, 6) AS raw
    FROM totals t
),
floored AS (
    SELECT s.*, floor(s.raw) AS whole, s.raw - floor(s.raw) AS remainder,
           10000 - sum(floor(s.raw)) OVER (PARTITION BY s.work_request_id) AS leftover
    FROM shares s
),
ranked AS (
    SELECT f.*, row_number() OVER (PARTITION BY f.work_request_id ORDER BY f.remainder DESC, f.ord) AS remainder_rank
    FROM floored f
)
INSERT INTO work_request_category_allocations (work_request_id, category, percentage)
SELECT r.work_request_id, r.category,
       (r.whole + CASE WHEN r.leftover >= 0 THEN (r.remainder_rank <= r.leftover)::int
                       ELSE -((r.remainder_rank <= -r.leftover)::int) END) / 100.0
FROM ranked r;

DELETE FROM work_request_category_allocations
WHERE work_request_id IN (
    SELECT w.id FROM work_requests w
    WHERE w.project_categories && ARRAY['SUSTAINABILITY', 'SAFETY']::text[]
      AND NOT EXISTS (SELECT 1 FROM work_request_benefit_allocations a WHERE a.work_request_id = w.id));
WITH ticked AS (
    SELECT w.id AS work_request_id, c.category, c.ord, w.ai_realised_savings_amount AS ai, w.ci_realised_savings_amount AS ci
    FROM work_requests w
    CROSS JOIN LATERAL (
        SELECT DISTINCT cat AS category, CASE cat WHEN 'AI' THEN 1 WHEN 'CI_KAIZEN' THEN 2 WHEN 'DIGITALISATION' THEN 3 WHEN 'AUTOMATION' THEN 4 WHEN 'SUSTAINABILITY' THEN 5 WHEN 'SAFETY' THEN 6 ELSE 7 END AS ord
        FROM unnest(w.project_categories) AS cat
        WHERE cat IN ('AI', 'CI_KAIZEN', 'DIGITALISATION', 'AUTOMATION', 'SUSTAINABILITY', 'SAFETY', 'OTHERS')
    ) c
    WHERE w.project_categories && ARRAY['SUSTAINABILITY', 'SAFETY']::text[]
      AND NOT EXISTS (SELECT 1 FROM work_request_benefit_allocations a WHERE a.work_request_id = w.id)
),
sized AS (
    SELECT t.*, count(*) OVER (PARTITION BY t.work_request_id) AS n,
           bool_or(t.category = 'AI') OVER (PARTITION BY t.work_request_id) AS has_ai,
           bool_or(t.category = 'CI_KAIZEN') OVER (PARTITION BY t.work_request_id) AS has_ci
    FROM ticked t
),
shares AS (
    SELECT s.work_request_id, s.category, s.ord,
           round(CASE
               WHEN s.has_ai AND s.has_ci AND s.category IN ('AI', 'CI_KAIZEN')
                    AND COALESCE(s.ai, 0) >= 0 AND COALESCE(s.ci, 0) >= 0 AND COALESCE(s.ai, 0) + COALESCE(s.ci, 0) > 0
               THEN 2 * 10000 * (CASE s.category WHEN 'AI' THEN COALESCE(s.ai, 0) ELSE COALESCE(s.ci, 0) END)
                    / (s.n * (COALESCE(s.ai, 0) + COALESCE(s.ci, 0)))
               ELSE 10000.0 / s.n
           END, 6) AS raw
    FROM sized s
),
floored AS (
    SELECT h.*, floor(h.raw) AS whole, h.raw - floor(h.raw) AS remainder,
           10000 - sum(floor(h.raw)) OVER (PARTITION BY h.work_request_id) AS leftover
    FROM shares h
),
ranked AS (
    SELECT f.*, row_number() OVER (PARTITION BY f.work_request_id ORDER BY f.remainder DESC, f.ord) AS remainder_rank
    FROM floored f
),
distributed AS (
    SELECT r.work_request_id, r.category, r.ord,
           r.whole + CASE WHEN r.leftover >= 0 THEN (r.remainder_rank <= r.leftover)::int ELSE -((r.remainder_rank <= -r.leftover)::int) END AS units
    FROM ranked r
),
raised AS (
    SELECT d.*, GREATEST(d.units, 1) AS raised_units,
           sum(GREATEST(1 - d.units, 0)) OVER (PARTITION BY d.work_request_id) AS deficit
    FROM distributed d
),
largest AS (
    SELECT a.*, row_number() OVER (PARTITION BY a.work_request_id ORDER BY a.raised_units DESC, a.ord) AS size_rank
    FROM raised a
)
INSERT INTO work_request_category_allocations (work_request_id, category, percentage)
SELECT l.work_request_id, l.category, (l.raised_units - CASE WHEN l.size_rank = 1 THEN l.deficit ELSE 0 END) / 100.0
FROM largest l;

UPDATE work_requests w
SET ai_realised_savings_amount = COALESCE(s.ai, 0), ci_realised_savings_amount = COALESCE(s.ci, 0)
FROM (
    SELECT work_request_id,
           sum(amount) FILTER (WHERE category = 'AI') AS ai,
           sum(amount) FILTER (WHERE category = 'CI_KAIZEN') AS ci
    FROM work_request_benefit_allocations
    WHERE allocation_type = 'COST_SAVINGS'
    GROUP BY work_request_id
) s
WHERE s.work_request_id = w.id
  AND w.ai_realised_savings_amount IS NULL AND w.ci_realised_savings_amount IS NULL
  AND COALESCE(s.ai, 0) + COALESCE(s.ci, 0) <= COALESCE(w.total_annual_saving, 0);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261015132132_AlignCategoryAllocationsWithBenefitAllocations', '10.0.8');

COMMIT;

