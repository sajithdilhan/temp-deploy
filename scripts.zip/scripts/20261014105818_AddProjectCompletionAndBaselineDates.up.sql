-- Migration: 20261014105818_AddProjectCompletionAndBaselineDates
-- PLN-023 phase A / RFC-012 D5 and D8: adds projects.completed_at (timestamptz) and projects.baseline_planned_end (date), the check
-- projects_completed_at_status_check (completed_at IS NULL OR status IN ('COMPLETED','ARCHIVED')), and BACKFILLS both dates.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261014105808_AddWorkRequestCategoryAllocations;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261014105808_AddWorkRequestCategoryAllocations (and any migration between).
-- Roll back with 20261014105818_AddProjectCompletionAndBaselineDates.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261014105818_AddProjectCompletionAndBaselineDates.up.sql
--
-- BACKFILL completed_at, for projects in COMPLETED or ARCHIVED only, using the first of: (1) the latest audit row PROJECT_STATUS_CHANGED
-- to COMPLETED; (2) actual_deployment (midnight UTC); (3) the historical project.actualDeployment date; (4) the latest REVIEW or DELIVERY
-- stage actual_end; otherwise it stays NULL (unknown, reported as a data-quality count and treated as an opening balance).
-- A project that is ARCHIVED but was never recorded as COMPLETED (no status audit row) only takes a deployment date, and only when it was
-- imported (origin HISTORICAL_BACKFILL); a completion is never invented for it from a stage date. This is the same policy the application
-- applies on save (ProjectLifecycleRules).
-- BACKFILL baseline_planned_end, for every project, using the first of: (1) the first planned end recorded in a PROJECT_DETAILS_UPDATED
-- audit row (its old value, or its new value when the old one was empty); (2) the historical project.plannedEnd date; (3) the current
-- planned_end. The placeholder 1970-01-01 counts as empty throughout.
--
-- Completion dates taken from (2) to (4) are an estimate, not a recorded event. No existing status or planned_end is changed. The audit
-- reads are index-assisted (audit_logs_entity_type_entity_id_idx). Adding nullable columns does not rewrite projects. Run it in the
-- cut-over window (stop the pools, migrate, deploy): the previous API build sets neither date, so a project completed or given a
-- planned end by it after the backfill has no completion date or baseline until the new build next saves it.

START TRANSACTION;
ALTER TABLE projects ADD baseline_planned_end date;

ALTER TABLE projects ADD completed_at timestamp(6) with time zone;

WITH completion AS (
    SELECT p.id,
           COALESCE(
               (SELECT max(a.created_at) FROM audit_logs a
                WHERE a.entity_type = 'Project' AND a.entity_id = p.id AND a.action = 'PROJECT_STATUS_CHANGED'
                  AND a.new_value ->> 'status' = 'COMPLETED'),
               CASE WHEN p.status = 'COMPLETED'::"ProjectStatus" OR p.origin = 'HISTORICAL_BACKFILL'
                    THEN NULLIF(p.actual_deployment, DATE '1970-01-01')::timestamp AT TIME ZONE 'UTC' END,
               CASE WHEN p.status = 'COMPLETED'::"ProjectStatus" OR p.origin = 'HISTORICAL_BACKFILL'
                    THEN (SELECT NULLIF(max(h.range_end), DATE '1970-01-01')::timestamp AT TIME ZONE 'UTC' FROM project_historical_dates h
                          WHERE h.project_id = p.id AND h.field_path = 'project.actualDeployment') END,
               CASE WHEN p.status = 'COMPLETED'::"ProjectStatus"
                    THEN (SELECT NULLIF(max(t.actual_end), DATE '1970-01-01')::timestamp AT TIME ZONE 'UTC' FROM project_timelines t
                          WHERE t.project_id = p.id AND t.stage_type IN ('REVIEW'::"TimelineStageType", 'DELIVERY'::"TimelineStageType")) END
           ) AS completed_at
    FROM projects p
    WHERE p.status IN ('COMPLETED'::"ProjectStatus", 'ARCHIVED'::"ProjectStatus")
)
UPDATE projects p
SET completed_at = c.completed_at
FROM completion c
WHERE c.id = p.id AND c.completed_at IS NOT NULL;

WITH first_recorded AS (
    SELECT DISTINCT ON (a.entity_id) a.entity_id AS project_id, v.planned_end
    FROM audit_logs a
    CROSS JOIN LATERAL (
        SELECT COALESCE(
            NULLIF(CASE WHEN a.old_value ->> 'plannedEnd' ~ '^\d{4}-\d{2}-\d{2}' THEN left(a.old_value ->> 'plannedEnd', 10)::date END, DATE '1970-01-01'),
            NULLIF(CASE WHEN a.new_value ->> 'plannedEnd' ~ '^\d{4}-\d{2}-\d{2}' THEN left(a.new_value ->> 'plannedEnd', 10)::date END, DATE '1970-01-01')
        ) AS planned_end
    ) v
    WHERE a.entity_type = 'Project' AND a.action = 'PROJECT_DETAILS_UPDATED' AND v.planned_end IS NOT NULL
    ORDER BY a.entity_id, a.created_at ASC
)
UPDATE projects p
SET baseline_planned_end = COALESCE(
    (SELECT fr.planned_end FROM first_recorded fr WHERE fr.project_id = p.id),
    (SELECT NULLIF(min(h.range_end), DATE '1970-01-01') FROM project_historical_dates h
     WHERE h.project_id = p.id AND h.field_path = 'project.plannedEnd'),
    NULLIF(p.planned_end, DATE '1970-01-01')
);

ALTER TABLE projects ADD CONSTRAINT projects_completed_at_status_check CHECK (completed_at IS NULL OR status IN ('COMPLETED', 'ARCHIVED'));

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261014105818_AddProjectCompletionAndBaselineDates', '10.0.8');

COMMIT;

