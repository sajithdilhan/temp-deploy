-- Rollback: 20261016072236_AddManagementDashboardReaderRole
-- Reverts the database to 20261015132132_AlignCategoryAllocationsWithBenefitAllocations.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261016072236_AddManagementDashboardReaderRole.down.sql
--
-- DATA LOSS: every Management Dashboard Reader assignment is DELETED (a NOTICE reports how many), because the previous
-- API build cannot read the label. Back them up first if you may need them again:
--   pg_dump -h <host> -U <user> -d <database> -t user_role_assignments -f user_role_assignments.backup.sql
-- PostgreSQL cannot drop an enum value, so the "AccessRole" label stays; it is unused and harmless, and the up script is
-- idempotent about it. Their audit_logs rows are kept.
--
-- Roll the API back first if the running build still grants the role.

START TRANSACTION;

DO $$
DECLARE removed integer;
BEGIN
    DELETE FROM user_role_assignments
    WHERE role = 'MANAGEMENT_DASHBOARD_READER'::"AccessRole";
    GET DIAGNOSTICS removed = ROW_COUNT;
    RAISE NOTICE 'Removed % Management Dashboard Reader role assignments', removed;
END $$;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261016072236_AddManagementDashboardReaderRole';

COMMIT;

