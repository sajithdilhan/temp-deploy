-- Migration: 20261002064116_AddEmailVerification
-- PLN-020: email verification on self-registration. Adds users.email_verified_at and
-- users.email_verification_source (both null, or both set: users_email_verification_both_or_neither),
-- and the user_email_tokens table (single-use emailed tokens; only the SHA-256 is stored).
-- The table's registration_* columns carry the password hash and profile details of the
-- registration attempt a verification token was issued for (decisions of 2026-10-02, security
-- review H1): verifying applies them, so the mailbox owner ends up with the password of the attempt
-- whose link they followed. They are nulled when the token is consumed or superseded.
-- Every existing user is backfilled as verified (email_verified_at = now(), source 'Backfill'),
-- so switching the registration.email-verification setting on later locks nobody out.
--
-- Generated from the EF Core migration of the same name, plus the backfill UPDATE. Applying this
-- script is equivalent to `dotnet ef database update` from 20261001073347_AddFeatureFlagStates;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Roll back with 20261002064116_AddEmailVerification.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261002064116_AddEmailVerification.up.sql
--
-- Operational notes: two nullable columns are added to users (no table rewrite) and one UPDATE
-- stamps every existing row, so it takes row locks on users for the length of that statement;
-- run it in a quiet period on a large table. It cannot fail on existing data: both columns are
-- written together, which satisfies the new check constraint. Safe while the previous API build
-- is serving: it ignores the new columns and table, and nothing changes until the setting is
-- enabled.

START TRANSACTION;
ALTER TABLE users ADD email_verification_source text;

ALTER TABLE users ADD email_verified_at timestamp(6) with time zone;

CREATE TABLE user_email_tokens (
    id uuid NOT NULL DEFAULT (gen_random_uuid()),
    user_id uuid NOT NULL,
    purpose text NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    consumed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    registration_password_hash text,
    registration_full_name character varying(255),
    registration_employee_id character varying(50),
    registration_designation character varying(255),
    registration_company character varying(255),
    registration_contact_number character varying(50),
    CONSTRAINT user_email_tokens_pkey PRIMARY KEY (id),
    CONSTRAINT user_email_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

UPDATE users SET email_verified_at = now(), email_verification_source = 'Backfill' WHERE email_verified_at IS NULL;

ALTER TABLE users ADD CONSTRAINT users_email_verification_both_or_neither CHECK ((email_verified_at IS NULL) = (email_verification_source IS NULL));

CREATE UNIQUE INDEX user_email_tokens_token_hash_key ON user_email_tokens (token_hash);

CREATE INDEX user_email_tokens_user_id_purpose_created_at_idx ON user_email_tokens (user_id, purpose, created_at);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261002064116_AddEmailVerification', '10.0.8');

COMMIT;

