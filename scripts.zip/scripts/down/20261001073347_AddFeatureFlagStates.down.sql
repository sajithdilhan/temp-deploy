-- Rollback: 20261001073347_AddFeatureFlagStates
-- Reverts the database to 20260928072534_ScopeOrganisationAndTeamCodesToParent.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20261001073347_AddFeatureFlagStates.down.sql
--
-- DESTRUCTIVE for platform settings: every value a SUPER_ADMIN has set is discarded, and each
-- setting returns to its code default. The audit_logs rows recording those changes are kept.
-- To keep the values, take a dump first:
--
--   pg_dump -h <host> -U <user> -d <database> -t feature_flag_states > feature_flag_states.sql
--
-- Deploy order matters: roll the API back to a build without platform settings BEFORE running
-- this. A running API that still reads the table will fail on every flag lookup once it is dropped.

START TRANSACTION;

DROP TABLE feature_flag_states;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261001073347_AddFeatureFlagStates';

COMMIT;
