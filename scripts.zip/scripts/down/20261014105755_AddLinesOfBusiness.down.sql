-- Rollback: 20261014105755_AddLinesOfBusiness
-- Reverts the database to 20261013074201_GrantProjectExecuterToExistingProjectLeads.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261014105755_AddLinesOfBusiness.down.sql
--
-- Drops work_requests.line_of_business_id (and its foreign key and index) and the line_of_business_units and lines_of_business tables.
--
-- DESTRUCTIVE: every line of business, its unit membership and every request's line choice are lost.
-- Keep them first: pg_dump -h <host> -U <user> -t lines_of_business -t line_of_business_units <database> > lines.sql
-- (the request attribution lives in work_requests.line_of_business_id and is only kept by a full backup).
-- Deploy order: roll the API back first if the running build still maps these tables.

START TRANSACTION;
ALTER TABLE work_requests DROP CONSTRAINT work_requests_line_of_business_id_fkey;

DROP TABLE line_of_business_units;

DROP TABLE lines_of_business;

DROP INDEX work_requests_line_of_business_id_idx;

ALTER TABLE work_requests DROP COLUMN line_of_business_id;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261014105755_AddLinesOfBusiness';

COMMIT;

