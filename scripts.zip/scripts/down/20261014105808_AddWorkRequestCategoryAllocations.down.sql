-- Rollback: 20261014105808_AddWorkRequestCategoryAllocations
-- Reverts the database to 20261014105755_AddLinesOfBusiness.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261014105808_AddWorkRequestCategoryAllocations.down.sql
--
-- Drops work_request_category_allocations and restores the original equality check on the AI/CI amounts.
--
-- DESTRUCTIVE: every category allocation is lost. Keep them first:
--   pg_dump -h <host> -U <user> -t work_request_category_allocations <database> > allocations.sql
-- BEFORE the equality check is restored, the AI/CI amounts of any request where ai + ci <> total_annual_saving (a request saved with an
-- allocation that leaves savings to other categories) are normalised: the AI amount is kept (capped at the savings) and CI becomes the
-- remainder, so the old check holds. This changes those requests' stored CI amount; it does not touch their categories.
-- It runs cleanly after new-style allocations exist, which is the point of putting it ahead of the check.
-- Deploy order: roll the API back first if the running build still writes allocations.

START TRANSACTION;
DROP TABLE work_request_category_allocations;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_ai_ci_savings_split_check;

UPDATE work_requests
SET ai_realised_savings_amount = LEAST(ai_realised_savings_amount, COALESCE(total_annual_saving, 0)),
    ci_realised_savings_amount = COALESCE(total_annual_saving, 0) - LEAST(ai_realised_savings_amount, COALESCE(total_annual_saving, 0))
WHERE ai_realised_savings_amount IS NOT NULL AND ci_realised_savings_amount IS NOT NULL
  AND ai_realised_savings_amount + ci_realised_savings_amount <> COALESCE(total_annual_saving, 0);

ALTER TABLE work_requests ADD CONSTRAINT work_requests_ai_ci_savings_split_check CHECK ((ai_realised_savings_amount IS NULL AND ci_realised_savings_amount IS NULL) OR (ai_realised_savings_amount IS NOT NULL AND ci_realised_savings_amount IS NOT NULL AND ai_realised_savings_amount + ci_realised_savings_amount = COALESCE(total_annual_saving, 0)));

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261014105808_AddWorkRequestCategoryAllocations';

COMMIT;

