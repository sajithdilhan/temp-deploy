-- Rollback: 20261014105818_AddProjectCompletionAndBaselineDates
-- Reverts the database to 20261014105808_AddWorkRequestCategoryAllocations.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261014105818_AddProjectCompletionAndBaselineDates.down.sql
--
-- Drops the projects_completed_at_status_check constraint and the completed_at and baseline_planned_end columns.
--
-- DESTRUCTIVE: the recorded completion dates and baselines are lost, and cannot be rebuilt exactly (a baseline is the planned end as it
-- stood at initialisation; once dropped, only the current planned_end remains). Keep them first:
--   psql -c "\copy (SELECT id, completed_at, baseline_planned_end FROM projects) TO 'project_dates.csv' CSV HEADER"
-- Deploy order: roll the API back first if the running build still maps these columns.

START TRANSACTION;
ALTER TABLE projects DROP CONSTRAINT projects_completed_at_status_check;

ALTER TABLE projects DROP COLUMN baseline_planned_end;

ALTER TABLE projects DROP COLUMN completed_at;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261014105818_AddProjectCompletionAndBaselineDates';

COMMIT;

