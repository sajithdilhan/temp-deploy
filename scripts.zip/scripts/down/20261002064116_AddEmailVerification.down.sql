-- Rollback: 20261002064116_AddEmailVerification
-- Reverts the database to 20261001073347_AddFeatureFlagStates.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261002064116_AddEmailVerification.down.sql
--
-- DESTRUCTIVE: drops user_email_tokens (every pending verification token, with the password hash
-- and details of the registration it carries) and the email_verified_at / email_verification_source
-- columns, so every user's verification stamp is lost. To keep them, take a dump first:
--
--   pg_dump -h <host> -U <user> -d <database> -t user_email_tokens > user_email_tokens.sql
--   psql -h <host> -U <user> -d <database> -c "\copy (SELECT id, email_verified_at, email_verification_source FROM users) TO 'user_email_verification.csv' CSV HEADER"
--
-- Deploy order matters: roll the API back to a build without email verification BEFORE running
-- this. A running API that still maps these columns fails on every query against users once they
-- are dropped.

START TRANSACTION;
DROP TABLE user_email_tokens;

ALTER TABLE users DROP CONSTRAINT users_email_verification_both_or_neither;

ALTER TABLE users DROP COLUMN email_verification_source;

ALTER TABLE users DROP COLUMN email_verified_at;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261002064116_AddEmailVerification';

COMMIT;

