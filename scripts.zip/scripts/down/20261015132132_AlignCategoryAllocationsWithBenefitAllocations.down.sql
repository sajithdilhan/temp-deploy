-- Rollback: 20261015132132_AlignCategoryAllocationsWithBenefitAllocations
-- Reverts the database to 20261014105818_AddProjectCompletionAndBaselineDates.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261015132132_AlignCategoryAllocationsWithBenefitAllocations.down.sql
--
-- Restores the RFC-012 checks (five categories, percentage > 0). DESTRUCTIVE for derived rows only: category allocation rows for
-- SUSTAINABILITY or SAFETY, and rows at 0%, are deleted first, so those requests are left with a split that does not cover all their
-- categories until they are saved again. They are derived from work_request_benefit_allocations, which is untouched. Keep them first:
--   pg_dump -h <host> -U <user> -t work_request_category_allocations <database> > category_allocations.sql
-- The AI/CI amounts filled on the way up are kept; the RFC-012 check allows them.
-- Deploy order: roll the API back first, or the running build will write rows the restored checks reject.

START TRANSACTION;
DELETE FROM work_request_category_allocations
WHERE category IN ('SUSTAINABILITY', 'SAFETY') OR percentage = 0;

ALTER TABLE work_request_category_allocations DROP CONSTRAINT work_request_category_allocations_category_check;

ALTER TABLE work_request_category_allocations DROP CONSTRAINT work_request_category_allocations_percentage_check;

ALTER TABLE work_request_category_allocations ADD CONSTRAINT work_request_category_allocations_category_check CHECK (category IN ('AI', 'CI_KAIZEN', 'DIGITALISATION', 'AUTOMATION', 'OTHERS'));

ALTER TABLE work_request_category_allocations ADD CONSTRAINT work_request_category_allocations_percentage_check CHECK (percentage > 0 AND percentage <= 100);

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261015132132_AlignCategoryAllocationsWithBenefitAllocations';

COMMIT;

