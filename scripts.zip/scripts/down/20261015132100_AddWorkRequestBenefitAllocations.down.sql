-- Rollback: 20261015132100_AddWorkRequestBenefitAllocations
-- Reverts the database to 20261014105818_AddProjectCompletionAndBaselineDates.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261015132100_AddWorkRequestBenefitAllocations.down.sql
--
-- DESTRUCTIVE for benefit allocations: every cost savings and cost avoidance split recorded
-- since PLN-024 is discarded. Requests saved with a savings allocation keep their derived AI/CI amounts.
-- To keep the rows, take a dump first:
--
--   pg_dump -h <host> -U <user> -d <database> -t work_request_benefit_allocations > work_request_benefit_allocations.sql
--
-- Deploy order matters: roll back 20261015132132_AlignCategoryAllocationsWithBenefitAllocations
-- first, and roll the API back to a build without benefit allocations BEFORE running this. A
-- running API that still reads the table will fail on every work request read once it is dropped.

START TRANSACTION;
DROP TABLE work_request_benefit_allocations;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261015132100_AddWorkRequestBenefitAllocations';

COMMIT;

