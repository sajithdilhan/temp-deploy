-- Rollback: 20261010073248_AddLoginOtp
-- Reverts the database to 20261002064116_AddEmailVerification.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261010073248_AddLoginOtp.down.sql
--
-- DESTRUCTIVE (small): drops user_email_tokens.code_hash, failed_attempts and remember_me, so every
-- pending sign-in challenge loses its code. The pending challenges are only worth minutes. To keep
-- them, take a dump first:
--
--   pg_dump -h <host> -U <user> -d <database> -t user_email_tokens > user_email_tokens.sql
--
-- It CANNOT restore the sessions that the up script revoked: those users have signed in again by
-- now, or will on their next visit.
--
-- Deploy order matters: roll the API back to a build without the sign-in code BEFORE running this.
-- A running API that still maps these columns fails on every query against user_email_tokens once
-- they are dropped.

START TRANSACTION;
ALTER TABLE user_email_tokens DROP COLUMN code_hash;

ALTER TABLE user_email_tokens DROP COLUMN failed_attempts;

ALTER TABLE user_email_tokens DROP COLUMN remember_me;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261010073248_AddLoginOtp';

COMMIT;

