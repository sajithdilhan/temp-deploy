-- Migration: 20261014105755_AddLinesOfBusiness
-- PLN-023 phase A / RFC-012 D1 and D3 / ADR-033: adds the lines_of_business table (a reporting grouping of business units inside
-- one business area; code and name unique per business area), the line_of_business_units membership table, and the nullable
-- work_requests.line_of_business_id column with its foreign key and index. Foreign keys: the business area RESTRICT; a line's
-- membership rows CASCADE with the line; the member unit RESTRICT; a request's line RESTRICT (lines are retired, never deleted).
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261013074201_GrantProjectExecuterToExistingProjectLeads;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261013074201_GrantProjectExecuterToExistingProjectLeads (and any migration between).
-- Roll back with 20261014105755_AddLinesOfBusiness.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261014105755_AddLinesOfBusiness.up.sql
--
-- SCHEMA ONLY, NO DATA CHANGE. Both new tables start empty and no existing request gets a line. The reference seed
-- (`--seed-reference`, run once with the new build) creates the 12 Commercial Aerospace lines and their mapping.
-- Adding a nullable column and new tables does not rewrite work_requests and is safe while the previous API build is serving.

START TRANSACTION;
ALTER TABLE work_requests ADD line_of_business_id uuid;

CREATE TABLE lines_of_business (
    id uuid NOT NULL DEFAULT (gen_random_uuid()),
    business_area_id uuid NOT NULL,
    code character varying(50) NOT NULL,
    normalized_code character varying(50) GENERATED ALWAYS AS (upper((code)::text)) STORED NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean NOT NULL DEFAULT TRUE,
    created_at timestamp(6) with time zone NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT lines_of_business_pkey PRIMARY KEY (id),
    CONSTRAINT lines_of_business_business_area_id_fkey FOREIGN KEY (business_area_id) REFERENCES organisation_units (id) ON DELETE RESTRICT
);

CREATE TABLE line_of_business_units (
    line_of_business_id uuid NOT NULL,
    organisation_unit_id uuid NOT NULL,
    CONSTRAINT line_of_business_units_pkey PRIMARY KEY (line_of_business_id, organisation_unit_id),
    CONSTRAINT line_of_business_units_line_of_business_id_fkey FOREIGN KEY (line_of_business_id) REFERENCES lines_of_business (id) ON DELETE CASCADE,
    CONSTRAINT line_of_business_units_organisation_unit_id_fkey FOREIGN KEY (organisation_unit_id) REFERENCES organisation_units (id) ON DELETE RESTRICT
);

CREATE INDEX work_requests_line_of_business_id_idx ON work_requests (line_of_business_id);

CREATE INDEX line_of_business_units_organisation_unit_id_idx ON line_of_business_units (organisation_unit_id);

CREATE UNIQUE INDEX lines_of_business_business_area_id_name_key ON lines_of_business (business_area_id, name);

CREATE UNIQUE INDEX lines_of_business_business_area_id_normalized_code_key ON lines_of_business (business_area_id, normalized_code);

ALTER TABLE work_requests ADD CONSTRAINT work_requests_line_of_business_id_fkey FOREIGN KEY (line_of_business_id) REFERENCES lines_of_business (id) ON DELETE RESTRICT;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261014105755_AddLinesOfBusiness', '10.0.8');

COMMIT;

