-- Migration: 20260928072534_ScopeOrganisationAndTeamCodesToParent
-- ADR-027 / RFC-008: organisation unit codes become unique among siblings (same parent), and
-- team codes unique within their organisation unit, both ignoring case. BU1 and BU2 can each
-- have a FIN department.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20260923014554_NarrowProjectScoreToScalabilityWeightOfOne;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20260923014554_NarrowProjectScoreToScalabilityWeightOfOne (and any migration between).
-- Roll back with 20260928072534_ScopeOrganisationAndTeamCodesToParent.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 --     -f 20260928072534_ScopeOrganisationAndTeamCodesToParent.up.sql
--
-- NO EXISTING VALUE CHANGES. `code`, ids, foreign keys and audit rows are untouched. The script
-- adds `normalized_code`, a stored generated column (upper(code)) that Postgres fills for every
-- existing row, and replaces the system-wide unique indexes with per-parent ones.
--
-- IT REFUSES TO RUN on data the new rule would reject: siblings whose codes differ only in case
-- (FIN and fin under one parent), or two such teams in one unit. The DO block raises an error
-- naming them and the whole transaction rolls back. Check first; both queries should return no rows:
--
--   SELECT parent_id, upper(code), array_agg(code) FROM organisation_units
--   GROUP BY parent_id, upper(code) HAVING count(*) > 1;
--   SELECT organisation_unit_id, upper(code), array_agg(code) FROM teams
--   GROUP BY organisation_unit_id, upper(code) HAVING count(*) > 1;
--
-- Top-level units (parent_id IS NULL) get a separate partial index, because PostgreSQL 14 has
-- no NULLS NOT DISTINCT.
--
-- Deploy order: run this BEFORE starting the API build that maps normalized_code. The previous
-- build keeps working against the new schema (it never reads the column).

START TRANSACTION;
DROP INDEX teams_code_key;

DROP INDEX organisation_units_code_key;

ALTER TABLE teams ADD normalized_code character varying(50) GENERATED ALWAYS AS (upper((code)::text)) STORED NOT NULL;

ALTER TABLE organisation_units ADD normalized_code character varying(50) GENERATED ALWAYS AS (upper((code)::text)) STORED NOT NULL;


DO $$
DECLARE conflicts text;
BEGIN
    SELECT string_agg(format('organisation unit codes %s under parent %s', codes, coalesce(parent_id::text, '(none)')), '; ')
    INTO conflicts
    FROM (SELECT parent_id, string_agg(code, ', ' ORDER BY code) AS codes
          FROM organisation_units GROUP BY parent_id, normalized_code HAVING count(*) > 1) duplicates;
    IF conflicts IS NOT NULL THEN
        RAISE EXCEPTION 'Codes must be unique per parent, ignoring case. Rename these before migrating: %', conflicts;
    END IF;
    SELECT string_agg(format('team codes %s in organisation unit %s', codes, organisation_unit_id), '; ')
    INTO conflicts
    FROM (SELECT organisation_unit_id, string_agg(code, ', ' ORDER BY code) AS codes
          FROM teams GROUP BY organisation_unit_id, normalized_code HAVING count(*) > 1) duplicates;
    IF conflicts IS NOT NULL THEN
        RAISE EXCEPTION 'Team codes must be unique per organisation unit, ignoring case. Rename these before migrating: %', conflicts;
    END IF;
END $$;

CREATE UNIQUE INDEX teams_organisation_unit_id_normalized_code_key ON teams (organisation_unit_id, normalized_code);

CREATE UNIQUE INDEX organisation_units_parent_id_normalized_code_key ON organisation_units (parent_id, normalized_code);

CREATE UNIQUE INDEX organisation_units_root_normalized_code_key ON organisation_units (normalized_code) WHERE parent_id IS NULL;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20260928072534_ScopeOrganisationAndTeamCodesToParent', '10.0.8');

COMMIT;

