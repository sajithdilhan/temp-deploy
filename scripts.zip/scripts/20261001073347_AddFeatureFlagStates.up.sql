-- Migration: 20261001073347_AddFeatureFlagStates
-- PLN-019: adds feature_flag_states, the stored values of the SUPER_ADMIN-managed platform
-- settings (feature flags). Settings are declared in code; a missing row means the code default.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20260928072534_ScopeOrganisationAndTeamCodesToParent;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Roll back with 20261001073347_AddFeatureFlagStates.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 \
--     -f 20261001073347_AddFeatureFlagStates.up.sql
--
-- Additive only: a new, empty table. No existing table or row changes. An empty table behaves
-- exactly as before (every setting at its code default), so it is safe to run while an older
-- API build is serving.

START TRANSACTION;

CREATE TABLE feature_flag_states (
    id uuid NOT NULL DEFAULT (gen_random_uuid()),
    key text NOT NULL,
    is_enabled boolean NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    updated_by_user_id uuid,
    CONSTRAINT feature_flag_states_pkey PRIMARY KEY (id),
    CONSTRAINT feature_flag_states_updated_by_user_id_fkey FOREIGN KEY (updated_by_user_id) REFERENCES users (id) ON DELETE SET NULL
);

CREATE UNIQUE INDEX feature_flag_states_key_key ON feature_flag_states (key);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261001073347_AddFeatureFlagStates', '10.0.8');

COMMIT;
