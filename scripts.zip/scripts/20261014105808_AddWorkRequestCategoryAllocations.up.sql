-- Migration: 20261014105808_AddWorkRequestCategoryAllocations
-- PLN-023 phase A / RFC-012 D4 and D8: adds work_request_category_allocations (work_request_id, category, percentage; primary key
-- (work_request_id, category); category stored as text with a check over the five ProjectCategoryOption values; percentage
-- numeric(5,2) greater than 0 and at most 100; rows cascade-delete with the request), BACKFILLS an allocation for every request
-- that ticks categories, and relaxes work_requests_ai_ci_savings_split_check from "ai + ci = total_annual_saving" to
-- "ai + ci <= total_annual_saving" so a request split, say, AI 40 / Digitalisation 60 can be saved.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261014105755_AddLinesOfBusiness;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261014105755_AddLinesOfBusiness (and any migration between).
-- Roll back with 20261014105808_AddWorkRequestCategoryAllocations.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261014105808_AddWorkRequestCategoryAllocations.up.sql
--
-- BACKFILL (the INSERT ... SELECT below): for ticked categories C, A = C in {AI, CI_KAIZEN}, O = the rest. A takes |A|/|C| of 100%
-- and, when both AI and CI_KAIZEN are ticked with usable stored amounts, splits it in proportion to ai_realised_savings_amount and
-- ci_realised_savings_amount; every other category (and everything when the amounts are missing or zero) is split evenly. Rounded to
-- 2dp by largest remainder, ties to the first category in enum order (33.34 / 33.33 / 33.33). A share that would be below 0.01% is raised
-- to 0.01% and taken from the largest share, because the table cannot store 0%. This is the same rule as
-- CategoryAllocationRules.FromLegacySplit, and an integration test holds the two to the same answers.
-- Existing AI/CI amounts are carried over as they are (RFC-012 open question 5: a default 50/50 cannot be told from a chosen one).
--
-- Nothing is deleted or rewritten in work_requests. Requests with no categories get no rows. The previous API build keeps working
-- (it writes the equality, which satisfies the relaxed check) but does not write allocations, so run this in the cut-over window
-- (stop the pools, migrate, deploy): a request saved by the old build after the backfill has no allocation until its next save.
-- Check before running, if you wish:
--   SELECT count(*) FROM work_requests WHERE project_categories IS NOT NULL AND cardinality(project_categories) > 0;

START TRANSACTION;
ALTER TABLE work_requests DROP CONSTRAINT work_requests_ai_ci_savings_split_check;

CREATE TABLE work_request_category_allocations (
    work_request_id uuid NOT NULL,
    category text NOT NULL,
    percentage numeric(5,2) NOT NULL,
    CONSTRAINT work_request_category_allocations_pkey PRIMARY KEY (work_request_id, category),
    CONSTRAINT work_request_category_allocations_category_check CHECK (category IN ('AI', 'CI_KAIZEN', 'DIGITALISATION', 'AUTOMATION', 'OTHERS')),
    CONSTRAINT work_request_category_allocations_percentage_check CHECK (percentage > 0 AND percentage <= 100),
    CONSTRAINT work_request_category_allocations_work_request_id_fkey FOREIGN KEY (work_request_id) REFERENCES work_requests (id) ON DELETE CASCADE
);

WITH ticked AS (
    SELECT w.id AS work_request_id, c.category, c.ord, w.ai_realised_savings_amount AS ai, w.ci_realised_savings_amount AS ci
    FROM work_requests w
    CROSS JOIN LATERAL (
        SELECT DISTINCT cat AS category,
               CASE cat WHEN 'AI' THEN 1 WHEN 'CI_KAIZEN' THEN 2 WHEN 'DIGITALISATION' THEN 3 WHEN 'AUTOMATION' THEN 4 ELSE 5 END AS ord
        FROM unnest(w.project_categories) AS cat
        WHERE cat IN ('AI', 'CI_KAIZEN', 'DIGITALISATION', 'AUTOMATION', 'OTHERS')
    ) c
    WHERE w.project_categories IS NOT NULL
),
sized AS (
    SELECT t.*, count(*) OVER (PARTITION BY t.work_request_id) AS n,
           bool_or(t.category = 'AI') OVER (PARTITION BY t.work_request_id) AS has_ai,
           bool_or(t.category = 'CI_KAIZEN') OVER (PARTITION BY t.work_request_id) AS has_ci
    FROM ticked t
),
shares AS (
    -- Each category's exact share in hundredths of a percent (10000 = 100%). AI and CI_KAIZEN split their joint |A|/|C| in
    -- proportion to the stored amounts when both are ticked and the amounts are usable; every other share is even.
    SELECT s.work_request_id, s.category, s.ord,
           round(CASE
               WHEN s.has_ai AND s.has_ci AND s.category IN ('AI', 'CI_KAIZEN')
                    AND COALESCE(s.ai, 0) >= 0 AND COALESCE(s.ci, 0) >= 0 AND COALESCE(s.ai, 0) + COALESCE(s.ci, 0) > 0
               THEN 2 * 10000 * (CASE s.category WHEN 'AI' THEN COALESCE(s.ai, 0) ELSE COALESCE(s.ci, 0) END)
                    / (s.n * (COALESCE(s.ai, 0) + COALESCE(s.ci, 0)))
               ELSE 10000.0 / s.n
           END, 6) AS raw
    FROM sized s
),
floored AS (
    SELECT h.*, floor(h.raw) AS whole, h.raw - floor(h.raw) AS remainder,
           10000 - sum(floor(h.raw)) OVER (PARTITION BY h.work_request_id) AS leftover
    FROM shares h
),
ranked AS (
    SELECT f.*, row_number() OVER (PARTITION BY f.work_request_id ORDER BY f.remainder DESC, f.ord) AS remainder_rank
    FROM floored f
),
distributed AS (
    -- Largest remainder: the leftover units go to the biggest remainders, ties to the first category in enum order
    -- (so a three-way even split is 33.34 / 33.33 / 33.33). A category cannot be stored at 0%, so a share under one unit is
    -- raised to one and the difference is taken from the largest share.
    SELECT r.work_request_id, r.category, r.ord,
           r.whole + CASE WHEN r.leftover >= 0 THEN (r.remainder_rank <= r.leftover)::int ELSE -((r.remainder_rank <= -r.leftover)::int) END AS units
    FROM ranked r
),
raised AS (
    SELECT d.*, GREATEST(d.units, 1) AS raised_units,
           sum(GREATEST(1 - d.units, 0)) OVER (PARTITION BY d.work_request_id) AS deficit
    FROM distributed d
),
largest AS (
    SELECT a.*, row_number() OVER (PARTITION BY a.work_request_id ORDER BY a.raised_units DESC, a.ord) AS size_rank
    FROM raised a
)
INSERT INTO work_request_category_allocations (work_request_id, category, percentage)
SELECT l.work_request_id, l.category, (l.raised_units - CASE WHEN l.size_rank = 1 THEN l.deficit ELSE 0 END) / 100.0
FROM largest l;

ALTER TABLE work_requests ADD CONSTRAINT work_requests_ai_ci_savings_split_check CHECK ((ai_realised_savings_amount IS NULL AND ci_realised_savings_amount IS NULL) OR (ai_realised_savings_amount IS NOT NULL AND ci_realised_savings_amount IS NOT NULL AND ai_realised_savings_amount + ci_realised_savings_amount <= COALESCE(total_annual_saving, 0)));

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261014105808_AddWorkRequestCategoryAllocations', '10.0.8');

COMMIT;

