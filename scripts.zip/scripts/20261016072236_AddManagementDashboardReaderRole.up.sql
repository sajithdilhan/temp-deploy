-- Migration: 20261016072236_AddManagementDashboardReaderRole
-- Management Dashboard Reader role (plan new-requirement-need-to-eventual-micali): adds MANAGEMENT_DASHBOARD_READER to the
-- "AccessRole" enum, right after MANAGEMENT_DASHBOARD_VIEWER. The role is scoped, so the unit check constraint on
-- user_role_assignments is unchanged. It grants Dashboard.Management only (no financial figures in the list).
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261015132132_AlignCategoryAllocationsWithBenefitAllocations;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261015132132_AlignCategoryAllocationsWithBenefitAllocations (and any migration between).
-- Roll back with 20261016072236_AddManagementDashboardReaderRole.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261016072236_AddManagementDashboardReaderRole.up.sql
--
-- NO EXISTING VALUE CHANGES. No table is rewritten and no role assignment changes. Safe while the old API build is serving
-- (it never reads the new label; reading a row that holds it would fail, but none exists until a user is granted the role).
--
-- The ALTER TYPE ... ADD VALUE statement runs OUTSIDE any transaction on purpose, as in EF's own migration. It is idempotent
-- (IF NOT EXISTS), so the script can be run again.

ALTER TYPE "AccessRole" ADD VALUE IF NOT EXISTS 'MANAGEMENT_DASHBOARD_READER' AFTER 'MANAGEMENT_DASHBOARD_VIEWER';

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261016072236_AddManagementDashboardReaderRole', '10.0.8');

