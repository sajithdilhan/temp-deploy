# RFC-013 — Forgot password: reset by emailed link

**Status:** PROPOSED
**Created:** 2026-10-15
**Plan:** PLN-024 (to be written once this RFC is accepted)
**Decision record:** ADR-034 (to be written once this RFC is accepted)
**Backlog:** [CAP-040](../roadmap/BACKLOG.md#cap-040--forgot--reset-password); relates to
[CAP-025](../roadmap/BACKLOG.md), [CAP-038](../roadmap/BACKLOG.md), [CAP-039](../roadmap/BACKLOG.md#cap-039--account-emails-are-sent-inline-with-no-outbox-or-retry)

> Numbering: RFC-012, PLN-023 and ADR-033 are taken on `feature/management-dashboard-overview`, which is not
> yet merged into `dev-reduced`. This work uses RFC-013, PLN-024 and ADR-034 so the numbers do not collide.

## Summary

A person who has forgotten their password asks for a reset link on a new **Forgot password** page. If the
account can use one, a single-use link valid for **15 minutes** is emailed. The answer on screen is the same
whether or not the account exists. Opening the link lets them set a new password. That signs them out
everywhere and emails them a "your password was changed" notice. It does **not** sign them in: they then sign
in as usual, with their password and the emailed sign-in code ([ADR-031](../decisions/ADR-031-password-login-requires-an-emailed-one-time-code.md)).

## Current behaviour

- The login page's **Forgot Password?** link (`login.component.html:103`) is a dead `href="#"`.
- A user who forgets their password has to ask an administrator. The administrator uses
  `POST /api/admin/users/{id}/reset-password` (`User.Maintain`, audited as `USER_PASSWORD_RESET`), and then
  knows the new password (CAP-036).
- The parts a reset needs already exist on purpose ([PLN-020](../plans/PLN-020-email-verification.md),
  [PLN-021](../plans/PLN-021-email-otp-two-factor-login.md)):
  - `user_email_tokens`: random 32-byte tokens, stored only as SHA-256, with purpose, expiry and consumption. Its `purpose` is free text with no CHECK constraint.
  - `IEmailSender` ([ADR-030](../decisions/ADR-030-outbound-email-goes-through-iemailsender.md)), the in-process account-email queue and its templates.
  - `AccountEmailThrottle`: a per-account cooldown and daily cap, counted from token rows, so it survives a recycle.
  - The `auth-anonymous` per-IP limiter (30 requests per 15 minutes).
  - One `IPasswordPolicy` for every path that sets a password ([ADR-028](../decisions/ADR-028-users-change-their-own-password.md)).
- Every password write takes the user-row lock, revokes every refresh token and consumes pending sign-in codes.
  Nothing consumes a reset token yet, because none exist.
- Outside Development the API refuses to start without SMTP (PLN-021), so email is always available.

## Problem

Forgetting a password is routine, and today it costs an administrator's time and leaves that administrator
knowing someone else's password. Email is the only channel we have to prove who the person is.

## Proposal

### Requesting a link — `POST /api/auth/forgot-password`

- Anonymous, behind the `auth-anonymous` limiter. Body `{ email }`.
- **Always answers `202 { "status": "password_reset_requested" }`.** The only other answers are a
  model-validation 400 on malformed input and a limiter 429. Every request is held to at least a minimum response
  time (`MinimumResponseMilliseconds`, default 1500), so the timing does not reveal which branch ran.
- A link is sent only when **all** of these hold:

  | Condition | If not met |
  |---|---|
  | The email domain is on `AllowedEmailDomains` | Nothing is looked up or sent. A warning logs the domain only |
  | An account exists for the address | Nothing is sent. Debug log, with no email |
  | The account is active (`IsActive`) | Nothing is sent. Warning with the user id |
  | The account has a password credential | Nothing is sent. Warning with the user id |
  | The email is verified, **or** `registration.email-verification` is off | Nothing is sent. Warning with the user id. The person uses "Resend verification email", as today |
  | The account's reset cooldown (60 s) and daily cap (5 per 24 h) allow another email | Nothing is sent, and the earlier link stays valid. Warning with the user id and the limit |

- An account **awaiting access** (no active role) does get a link. The login gate still refuses it after the
  password is proven (`ACCOUNT_AWAITING_ACCESS`), so the person learns the real state, and refusing would hide
  nothing because the answer is uniform.
- The check, the throttle and the issue all happen under the user-row lock in one transaction, so two concurrent
  requests cannot both pass the cooldown (PLN-020's M3 precedent). The email goes out after the response.
- Issuing a link supersedes the account's earlier unused links: they are marked consumed.

### The link

- `{App:PublicWebBaseUrl}/reset-password#token=<64 hex>`. The token is a **URL fragment**, not a query
  parameter. Browsers never send a fragment to the server or in a `Referer` header, so the token stays out of
  the IIS and nginx access logs. Verify-email puts its token in the query string and has that exposure; fixing it
  is a separate backlog item.
- The page also accepts `?token=` in case a mail link rewriter drops fragments. It removes the token from the
  address bar as soon as it loads (`history.replaceState`).
- Valid for **15 minutes**, usable **once**. Only its SHA-256 is stored. Opening the page does nothing; the token
  is spent only when the new password is submitted. A link scanner that follows the URL cannot use it up.

### Setting the new password — `POST /api/auth/reset-password`

- Anonymous, behind the same limiter. Body `{ token, newPassword }`. The page asks for the new password twice
  ("New password", "Confirm new password") and will not submit until they match. Only `newPassword` is sent.
- Answers:

  | Situation | Answer |
  |---|---|
  | Success | **204** |
  | Token malformed, unknown, used, superseded, or its account inactive or without a credential | 400 `reset_link_invalid` |
  | Token past its 15 minutes | 400 `reset_link_expired` |
  | New password fails `IPasswordPolicy` (email and name context) | 400 "Password does not meet requirements: …". **The token is not spent** |
  | Limiter | 429 |

  It never answers 401, so the browser's session handling does not react to it.
- Order: look up the token (cheap), check the policy, hash with Argon2id, then take the user-row lock. Under the
  lock, re-read the token by id. Consume it with a conditional update that must affect exactly one row: of two
  simultaneous submissions, exactly one succeeds. Then, in the same transaction:
  - set the new hash and `PasswordChangedAt`;
  - revoke **every** refresh token (ADR-028; a revoked token older than `PasswordChangedAt` is also refused inside the rotation grace window);
  - consume every pending sign-in code and every reset link of the account;
  - write an `AuditLog` row `PASSWORD_RESET` on `User`, with the user as the actor and timestamps only (`PasswordChangedAt` old → new), the same as `PASSWORD_CHANGED`. It is distinct from the administrator's `USER_PASSWORD_RESET`;
  - log `Password for user {UserId} reset by email link`.
- After commit, a **"your password was changed"** email goes to the account. It gives the time, says every
  session has been signed out, and says to contact an administrator if it wasn't them. It carries no link and no
  token.
- **There is no "must differ from the current password" rule on this path.** The token is not spent on a 400.
  That rule would let anyone holding a link test guesses at the current password with nothing but the per-IP
  limit in the way.
- **The reset does not sign the person in.** The page sends them to `/login?reset=1` ("Your password has been
  reset and you've been signed out everywhere"), where the password and the sign-in code both apply. A stolen
  link is therefore not enough to get in without the mailbox, and the two-factor rule of ADR-031 holds.

### Every other password write cancels reset links

The helper that consumes pending sign-in codes on a credential change also consumes `PASSWORD_RESET` rows. It is
already called by the self-change, the administrator's reset, deactivation, last-role revoke and completion of
registration. Without this, a link requested before an administrator's reset could later overwrite the password
the administrator set.

### Configuration

`Authentication:PasswordReset`, with `TokenLifetimeMinutes` 15, `ResendCooldownSeconds` 60, `DailySendCap` 5
and `MinimumResponseMilliseconds` 1500. This feature has **no platform setting**: it is always on, like the
sign-in code. Outside Development the API refuses to start without `App:PublicWebBaseUrl`, because without it
every reset email would silently fail.

### Interface

- Login: **Forgot password?** goes to `/forgot-password`.
- `/forgot-password` is for guests only. It has an email field and, after submitting, always shows: "If an account exists for {email},
  we've sent a password reset link. It is valid for 15 minutes." A short hint covers accounts whose email
  isn't verified yet. A resend is offered after a cooldown.
- `/reset-password` has no guard, like `/verify-email`, so it opens on any device. It shows "New password" (with the
  password-requirements checklist) and "Confirm new password", plus Show passwords. The invalid, expired
  and missing-link states each offer "Request a new link". If the browser happens to hold a session, it is ended
  before going to sign-in.
- Wording follows [terminology](../product/terminology.md): **Sign in**, **sign-in code**, **password reset link**.

## Alternatives considered

### Alternative A — Sign the person in after the reset

It is the fewest steps, but anyone with a stolen or forwarded link would get a session without the sign-in
code, and the second factor of ADR-031 would be bypassed. Rejected.

### Alternative B — Email a code instead of a link

This mirrors the sign-in code. A short code needs attempt counting and a lockout to resist guessing, while a
256-bit link token does not. A link is also what users expect for a reset. Rejected.

### Alternative C — A token-check endpoint called when the page opens

It would show "expired" before the person types a password. There is no security gain (the token can't be
guessed), it is one more anonymous endpoint, and JavaScript-rendering scanners would call it. Verify-email does
without one. Deferred: it can be added later without changing anything else.

### Alternative D — Token in the query string, as verify-email does

This is consistent with verify-email, but the token would land in web-server access logs and in same-origin
`Referer` headers for the page's lazy-loaded chunks. Rejected for this path. Verify-email is noted for the same
fix.

### Alternative E — Behind a platform setting

PLN-020's flag existed because SMTP might not be ready. SMTP is now mandatory outside Development (PLN-021). A
setting would only add a state to test. Rejected.

## Benefits

- Users recover access without an administrator, and administrators stop learning other people's passwords.
- The design reveals nothing about which accounts exist, and keeps reset links out of server logs.
- A reset always ends every session and still requires the sign-in code.

## Risks

- **No outbox (CAP-039).** A queued email is lost on an app-pool recycle or relay failure. The person sees the
  same message and asks again after the cooldown.
- **Per-IP limits are coarse behind the proxy (CAP-025).** The per-account throttle in the database is the real
  control. Forgot and reset share the 30-per-15-minute `auth-anonymous` bucket with register, verify and resend.
- **Anyone can spend an account's 5 reset emails for the day.** The same cap bounds inbox spam. The
  administrator's reset remains the fallback.
- **Access tokens on other devices live up to 15 minutes after a reset (CAP-038)**, as after a self-change.
- **Whoever controls the mailbox can reset the password.** That is inherent to email reset. It is why the reset
  does not skip the sign-in code, and why the notice email exists.
- **The response floor holds only while the sending path finishes inside it** (Argon2 isn't on this path; lock
  contention could exceed 1.5 s).
- **A corporate link rewriter may drop the fragment.** The query-string fallback covers it at the cost of the log
  exposure. Check in UAT.

## Impact

- **Frontend:**
  - two new anonymous pages (`/forgot-password`, `/reset-password`);
  - on the login page, the link, a `?reset=1` banner and stripping that flag;
  - two `AuthService` methods and two new error codes;
  - both endpoints added to the interceptor's session-endpoint list;
  - an admin audit label for `PASSWORD_RESET`.
- **Backend:**
  - two endpoints on `AuthController`;
  - a new `IPasswordResetService` / `PasswordResetService` (kept out of `AuthenticationService`);
  - the `PASSWORD_RESET` purpose and its throttle;
  - two email templates and their queue jobs;
  - the shared credential-change token helper;
  - pruning of `PASSWORD_RESET` rows older than 24 h.
- **Database / Migration:** none. `purpose` is free text, and the existing `(user_id, purpose, created_at)`
  index serves the throttle.
- **Security and permissions:**
  - two new anonymous endpoints;
  - a new audited action, `PASSWORD_RESET`;
  - no role or permission change.
- **Operational:**
  - the new `Authentication:PasswordReset` section;
  - `App__PublicWebBaseUrl` becomes required to start outside Development (confirm it is set on both UAT sites
    and production before deploying);
  - a relay outage stops resets as it does sign-in.

## Open questions

1. Is `App__PublicWebBaseUrl` set on both UAT sites and on production? If not, it is set before deploying, or the
   startup check becomes a warning instead of a refusal.
2. Does the corporate link rewriter (Safe Links) keep URL fragments? It is checked in UAT; the query-string
   fallback is the plan if it does not.

## Decision

Pending.
