var n={fullName:255,email:255,employeeId:50,designation:255,company:255,contactNumber:50};export{n as a};
