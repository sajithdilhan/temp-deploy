var t="Nothing to administer",o="Your organisation unit is inactive or not set, so there is nothing for you to administer here. Ask an administrator to check your assignment.";export{t as a,o as b};
