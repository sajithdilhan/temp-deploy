-- Migration: 20261012072349_AddExternalBusinessUnitsAndCommitteeRoles
-- RFC-011 / PLN-022 slice D1 (decisions D46, D51, D56): adds the Steering Committee Member and Project Coordinator
-- roles to the "AccessRole" enum (both unscoped, so the unscoped-role check constraint on user_role_assignments is
-- replaced to list them) and the external business unit classification on organisation_units: is_external
-- (default false) and hod_user_id (FK users), with the checks "only a business unit can be external" and
-- "an external unit has a HOD".
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261011000000_AddUserRoleAssignments;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261011000000_AddUserRoleAssignments (and any migration between).
-- Roll back with 20261012072349_AddExternalBusinessUnitsAndCommitteeRoles.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261012072349_AddExternalBusinessUnitsAndCommitteeRoles.up.sql
--
-- NO EXISTING VALUE CHANGES. Every unit starts internal (is_external = false, no HOD) and no role assignment changes.
--
-- The two ALTER TYPE ... ADD VALUE statements run OUTSIDE the transaction below on purpose: PostgreSQL cannot use a new
-- enum value (here, in the replacement check constraint) in the transaction that adds it. They are idempotent
-- (IF NOT EXISTS), so a script stopped half way can be run again. The history row is inside the transaction (moved
-- up from where EF scripts it, after COMMIT, so the schema change and its record commit together).
--
-- Deploy order: run this BEFORE starting the API build that maps the new columns and roles.

ALTER TYPE "AccessRole" ADD VALUE IF NOT EXISTS 'STEERING_COMMITTEE_MEMBER' AFTER 'SUPER_ADMINISTRATOR';

ALTER TYPE "AccessRole" ADD VALUE IF NOT EXISTS 'PROJECT_COORDINATOR' AFTER 'STEERING_COMMITTEE_MEMBER';

START TRANSACTION;
ALTER TABLE user_role_assignments DROP CONSTRAINT user_role_assignments_unit_matches_role_check;

ALTER TABLE organisation_units ADD hod_user_id uuid;

ALTER TABLE organisation_units ADD is_external boolean NOT NULL DEFAULT FALSE;

ALTER TABLE user_role_assignments ADD CONSTRAINT user_role_assignments_unit_matches_role_check CHECK ((organisation_unit_id IS NULL) = (role IN ('FINANCE_MODERATOR'::"AccessRole", 'SYSTEM_ADMINISTRATOR'::"AccessRole", 'SUPER_ADMINISTRATOR'::"AccessRole", 'STEERING_COMMITTEE_MEMBER'::"AccessRole", 'PROJECT_COORDINATOR'::"AccessRole")));

CREATE INDEX organisation_units_hod_user_id_idx ON organisation_units (hod_user_id);

ALTER TABLE organisation_units ADD CONSTRAINT organisation_units_external_has_hod_check CHECK (NOT is_external OR hod_user_id IS NOT NULL);

ALTER TABLE organisation_units ADD CONSTRAINT organisation_units_external_is_business_unit_check CHECK (NOT is_external OR type = 'BUSINESS_UNIT');

ALTER TABLE organisation_units ADD CONSTRAINT organisation_units_hod_user_id_fkey FOREIGN KEY (hod_user_id) REFERENCES users (id) ON DELETE RESTRICT;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012072349_AddExternalBusinessUnitsAndCommitteeRoles', '10.0.8');

COMMIT;
