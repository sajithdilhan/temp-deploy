-- Migration: 20261013074201_GrantProjectExecuterToExistingProjectLeads
-- RFC-011 / PLN-022 slice H1 (C2 decision): DATA ONLY, no schema change. The Executer of a project is its lead (team_lead_id)
-- only while they hold Project Executer covering the project's delivery unit, and the slice A mapping table gives nobody that
-- role. So every LIVE project's lead is granted PROJECT_EXECUTER at the project's delivery unit, or the project loses its
-- manager.
--
-- SELECTION (per distinct lead and delivery unit): project status not COMPLETED, ARCHIVED or CANCELLED (finished projects are
-- read-only for everyone but a Super Admin, so a lead gains nothing); team_lead_id set to an ACTIVE user; delivery unit set
-- and ACTIVE (an assignment at an inactive unit grants nothing, D42); the lead is not a Super Admin (legacy role SUPER_ADMIN or
-- an unrevoked Super Administrator assignment: a Super Admin is never a project lead, D16); and the lead does not already hold
-- an unrevoked PROJECT_EXECUTER assignment at the delivery unit or an active ancestor of it. Projects with no delivery unit,
-- an inactive one or an inactive lead get no grant: pre-check query 19 lists them.
--
-- Each grant is an assignment (reason 'Migrated: lead of an existing project delivered by this unit (RFC-011 cut-over)',
-- assigned_by_user_id NULL = the system) plus a USER_ROLE_ASSIGNMENT_GRANTED audit_logs row with no actor, the same shape as the
-- slice A backfill.
--
-- Generated from the EF Core migration of the same name (hand-filled: the model is unchanged). Applying this script is
-- equivalent to `dotnet ef database update` from 20261013074119_MoveApprovedRequestsWithoutProjectToCommittee;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261013074119_MoveApprovedRequestsWithoutProjectToCommittee (and any migration between).
-- Roll back with 20261013074201_GrantProjectExecuterToExistingProjectLeads.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261013074201_GrantProjectExecuterToExistingProjectLeads.up.sql
--
-- IDEMPOTENT: a lead already covered is skipped, so a second run grants nothing and audits nothing.

START TRANSACTION;
WITH RECURSIVE leads AS (
    SELECT DISTINCT p.team_lead_id AS user_id, p.delivery_organisation_unit_id AS unit_id
    FROM projects p
    JOIN users u ON u.id = p.team_lead_id AND u.is_active AND u.role <> 'SUPER_ADMIN'::"UserRole"
    JOIN organisation_units du ON du.id = p.delivery_organisation_unit_id AND du.is_active
    WHERE p.status NOT IN ('COMPLETED'::"ProjectStatus", 'ARCHIVED'::"ProjectStatus", 'CANCELLED'::"ProjectStatus")
      AND NOT EXISTS (SELECT 1 FROM user_role_assignments s
                      WHERE s.user_id = u.id AND s.role = 'SUPER_ADMINISTRATOR'::"AccessRole" AND s.revoked_at IS NULL)
),
line (user_id, unit_id, line_unit_id) AS (
    SELECT l.user_id, l.unit_id, l.unit_id FROM leads l
    UNION ALL
    SELECT li.user_id, li.unit_id, ou.parent_id
    FROM line li JOIN organisation_units ou ON ou.id = li.line_unit_id
    WHERE ou.parent_id IS NOT NULL
),
needed AS (
    SELECT l.user_id, l.unit_id
    FROM leads l
    WHERE NOT EXISTS (
        SELECT 1 FROM line li
        JOIN organisation_units lu ON lu.id = li.line_unit_id AND lu.is_active
        JOIN user_role_assignments a ON a.organisation_unit_id = li.line_unit_id
        WHERE li.user_id = l.user_id AND li.unit_id = l.unit_id
          AND a.user_id = l.user_id AND a.role = 'PROJECT_EXECUTER'::"AccessRole" AND a.revoked_at IS NULL)
),
inserted AS (
    INSERT INTO user_role_assignments (id, user_id, role, organisation_unit_id, reason, assigned_by_user_id, assigned_at)
    SELECT gen_random_uuid(), n.user_id, 'PROJECT_EXECUTER'::"AccessRole", n.unit_id,
           'Migrated: lead of an existing project delivered by this unit (RFC-011 cut-over)', NULL, now()
    FROM needed n
    RETURNING id, user_id, role, organisation_unit_id, reason, assigned_at
)
INSERT INTO audit_logs (id, actor_user_id, entity_type, entity_id, action, old_value, new_value, created_at)
SELECT gen_random_uuid(), NULL, 'UserRoleAssignment', i.id, 'USER_ROLE_ASSIGNMENT_GRANTED', NULL,
       jsonb_build_object('userId', i.user_id, 'role', i.role::text, 'organisationUnitId', i.organisation_unit_id, 'reason', i.reason),
       i.assigned_at
FROM inserted i;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261013074201_GrantProjectExecuterToExistingProjectLeads', '10.0.8');

COMMIT;
