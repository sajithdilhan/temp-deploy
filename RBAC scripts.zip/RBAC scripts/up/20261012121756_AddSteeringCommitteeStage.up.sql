-- Migration: 20261012121756_AddSteeringCommitteeStage
-- RFC-011 / PLN-022 slice D2a (decisions D44, D47-D50): adds the STEERING_COMMITTEE, PROJECT_COORDINATION and
-- INITIALISATION labels to the "WorkRequestApprovalStage" enum, the steering_committee_reached_at,
-- steering_committee_approved_at, steering_committee_golden_buzzer (default false) and steering_committee_returned_at
-- columns on work_requests, the work_request_committee_approvals table (one row per member approval; a partial
-- unique index allows one active row per request and user) and a queue index on (approval_stage, request_status).
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261012072349_AddExternalBusinessUnitsAndCommitteeRoles;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261012072349_AddExternalBusinessUnitsAndCommitteeRoles (and any migration between).
-- Roll back with 20261012121756_AddSteeringCommitteeStage.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261012121756_AddSteeringCommitteeStage.up.sql
--
-- NO EXISTING VALUE CHANGES. Every request keeps its stage and status; the new columns start empty (golden buzzer
-- false) and the new table starts empty.
--
-- The three ALTER TYPE ... ADD VALUE statements run OUTSIDE the transaction below on purpose: PostgreSQL cannot use a
-- new enum value in the transaction that adds it. They are idempotent (IF NOT EXISTS), so a script stopped half way
-- can be run again. The history row is inside the transaction (moved up from where EF scripts it, after COMMIT, so the
-- schema change and its record commit together).
--
-- Deploy order: run this BEFORE starting the API build that maps the new columns and stages.

ALTER TYPE "WorkRequestApprovalStage" ADD VALUE IF NOT EXISTS 'STEERING_COMMITTEE' AFTER 'COMPLETED';

ALTER TYPE "WorkRequestApprovalStage" ADD VALUE IF NOT EXISTS 'PROJECT_COORDINATION' AFTER 'STEERING_COMMITTEE';

ALTER TYPE "WorkRequestApprovalStage" ADD VALUE IF NOT EXISTS 'INITIALISATION' AFTER 'PROJECT_COORDINATION';

START TRANSACTION;
ALTER TABLE work_requests ADD steering_committee_approved_at timestamp(6) with time zone;

ALTER TABLE work_requests ADD steering_committee_golden_buzzer boolean NOT NULL DEFAULT FALSE;

ALTER TABLE work_requests ADD steering_committee_reached_at timestamp(6) with time zone;

ALTER TABLE work_requests ADD steering_committee_returned_at timestamp(6) with time zone;

CREATE TABLE work_request_committee_approvals (
    id uuid NOT NULL DEFAULT (gen_random_uuid()),
    work_request_id uuid NOT NULL,
    user_id uuid NOT NULL,
    approved_at timestamp(6) with time zone NOT NULL,
    golden_buzzer boolean NOT NULL DEFAULT FALSE,
    remarks text,
    cleared_at timestamp(6) with time zone,
    CONSTRAINT work_request_committee_approvals_pkey PRIMARY KEY (id),
    CONSTRAINT work_request_committee_approvals_user_id_fkey FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT work_request_committee_approvals_work_request_id_fkey FOREIGN KEY (work_request_id) REFERENCES work_requests (id) ON DELETE CASCADE
);

CREATE INDEX work_requests_approval_stage_status_idx ON work_requests (approval_stage, request_status);

CREATE UNIQUE INDEX work_request_committee_approvals_active_key ON work_request_committee_approvals (work_request_id, user_id) WHERE cleared_at IS NULL;

CREATE INDEX work_request_committee_approvals_user_id_idx ON work_request_committee_approvals (user_id);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012121756_AddSteeringCommitteeStage', '10.0.8');

COMMIT;
