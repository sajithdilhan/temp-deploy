-- Migration: 20261011000000_AddUserRoleAssignments
-- RFC-011 / PLN-022 slice A: adds the "AccessRole" enum and the user_role_assignments table, and
-- backfills it from each ACTIVE user's legacy role (decisions D2, D41). Nothing reads the new table
-- for authorization yet; users.role and users.organisation_unit_id are untouched.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261010073248_AddLoginOtp;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261010073248_AddLoginOtp.
-- Roll back with 20261011000000_AddUserRoleAssignments.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261011000000_AddUserRoleAssignments.up.sql
--
-- BACKFILL (one assignment per row, reason 'Migrated from legacy role <ROLE>', assigned by the system):
--   USER -> Contributor at their unit       MANAGER -> Contributor + Approver at their unit
--   MODERATOR -> Pain Point Moderator at their unit
--   ADMIN -> System Administrator (no unit) SUPER_ADMIN -> Super Administrator (no unit)
--   EXTERNAL_USER and every deactivated user -> nothing.
-- Each assignment also writes a USER_ROLE_ASSIGNMENT_GRANTED audit_logs row (no actor).
--
-- IT REFUSES TO RUN when an active user with legacy role USER, MANAGER or MODERATOR has no
-- organisation unit or an inactive one: the DO block raises an error listing the user ids and the
-- whole transaction rolls back. Check first; this should return no rows:
--
--   SELECT u.id FROM users u LEFT JOIN organisation_units ou ON ou.id = u.organisation_unit_id
--   WHERE u.is_active AND u.role IN ('USER','MANAGER','MODERATOR')
--     AND (u.organisation_unit_id IS NULL OR ou.is_active IS NOT TRUE);
--
-- Deploy order: run this BEFORE starting the API build that reads user_role_assignments.

START TRANSACTION;
CREATE TYPE "AccessRole" AS ENUM ('CONTRIBUTOR', 'APPROVER', 'SELF_APPROVER', 'PORTFOLIO_DASHBOARD_VIEWER', 'MANAGEMENT_DASHBOARD_VIEWER', 'PAIN_POINT_MODERATOR', 'PROJECT_EXECUTER', 'USER_ADMINISTRATOR', 'ORGANISATION_MODERATOR', 'FINANCE_MODERATOR', 'SYSTEM_ADMINISTRATOR', 'SUPER_ADMINISTRATOR');

CREATE TABLE user_role_assignments (
    id uuid NOT NULL DEFAULT (gen_random_uuid()),
    user_id uuid NOT NULL,
    role "AccessRole" NOT NULL,
    organisation_unit_id uuid,
    reason text NOT NULL,
    assigned_by_user_id uuid,
    assigned_at timestamp(6) with time zone NOT NULL DEFAULT (CURRENT_TIMESTAMP),
    revoked_at timestamp(6) with time zone,
    revoked_by_user_id uuid,
    revoke_reason text,
    CONSTRAINT user_role_assignments_pkey PRIMARY KEY (id),
    CONSTRAINT user_role_assignments_reason_not_blank_check CHECK (btrim(reason) <> ''),
    CONSTRAINT user_role_assignments_revocation_complete_check CHECK ((revoked_at IS NULL AND revoked_by_user_id IS NULL AND revoke_reason IS NULL) OR (revoked_at IS NOT NULL AND revoke_reason IS NOT NULL)),
    CONSTRAINT user_role_assignments_unit_matches_role_check CHECK ((organisation_unit_id IS NULL) = (role IN ('FINANCE_MODERATOR'::"AccessRole", 'SYSTEM_ADMINISTRATOR'::"AccessRole", 'SUPER_ADMINISTRATOR'::"AccessRole"))),
    CONSTRAINT user_role_assignments_assigned_by_user_id_fkey FOREIGN KEY (assigned_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT user_role_assignments_organisation_unit_id_fkey FOREIGN KEY (organisation_unit_id) REFERENCES organisation_units (id) ON DELETE RESTRICT,
    CONSTRAINT user_role_assignments_revoked_by_user_id_fkey FOREIGN KEY (revoked_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT user_role_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
);

CREATE INDEX user_role_assignments_assigned_by_user_id_idx ON user_role_assignments (assigned_by_user_id);

CREATE INDEX user_role_assignments_organisation_unit_id_idx ON user_role_assignments (organisation_unit_id);

CREATE INDEX user_role_assignments_revoked_by_user_id_idx ON user_role_assignments (revoked_by_user_id);

CREATE INDEX user_role_assignments_user_id_revoked_at_idx ON user_role_assignments (user_id, revoked_at);

CREATE UNIQUE INDEX user_role_assignments_user_id_role_organisation_unit_id_key ON user_role_assignments (user_id, role, organisation_unit_id) WHERE revoked_at IS NULL AND organisation_unit_id IS NOT NULL;

CREATE UNIQUE INDEX user_role_assignments_user_id_role_unscoped_key ON user_role_assignments (user_id, role) WHERE revoked_at IS NULL AND organisation_unit_id IS NULL;


DO $$
DECLARE offenders text;
BEGIN
    SELECT string_agg(u.id::text, ', ' ORDER BY u.id)
    INTO offenders
    FROM users u
    LEFT JOIN organisation_units ou ON ou.id = u.organisation_unit_id
    WHERE u.is_active
      AND u.role IN ('USER', 'MANAGER', 'MODERATOR')
      AND (u.organisation_unit_id IS NULL OR ou.is_active IS NOT TRUE);
    IF offenders IS NOT NULL THEN
        RAISE EXCEPTION 'Active users with legacy role USER, MANAGER or MODERATOR need an active organisation unit before role assignments can be created. Fix these user ids: %', offenders;
    END IF;
END $$;


WITH mapping (legacy_role, new_role, scoped) AS (
    VALUES ('USER', 'CONTRIBUTOR', true),
           ('MANAGER', 'CONTRIBUTOR', true),
           ('MANAGER', 'APPROVER', true),
           ('MODERATOR', 'PAIN_POINT_MODERATOR', true),
           ('ADMIN', 'SYSTEM_ADMINISTRATOR', false),
           ('SUPER_ADMIN', 'SUPER_ADMINISTRATOR', false)
),
candidates AS (
    SELECT u.id AS user_id,
           m.new_role::"AccessRole" AS role,
           CASE WHEN m.scoped THEN u.organisation_unit_id END AS unit_id,
           u.role::text AS legacy_role
    FROM users u
    JOIN mapping m ON m.legacy_role = u.role::text
    WHERE u.is_active AND (NOT m.scoped OR u.organisation_unit_id IS NOT NULL)
),
inserted AS (
    INSERT INTO user_role_assignments (id, user_id, role, organisation_unit_id, reason, assigned_by_user_id, assigned_at)
    SELECT gen_random_uuid(), c.user_id, c.role, c.unit_id, 'Migrated from legacy role ' || c.legacy_role, NULL, now()
    FROM candidates c
    WHERE NOT EXISTS (
        SELECT 1 FROM user_role_assignments a
        WHERE a.user_id = c.user_id AND a.role = c.role AND a.revoked_at IS NULL
          AND a.organisation_unit_id IS NOT DISTINCT FROM c.unit_id)
    RETURNING id, user_id, role, organisation_unit_id, reason, assigned_at
)
INSERT INTO audit_logs (id, actor_user_id, entity_type, entity_id, action, old_value, new_value, created_at)
SELECT gen_random_uuid(), NULL, 'UserRoleAssignment', i.id, 'USER_ROLE_ASSIGNMENT_GRANTED', NULL,
       jsonb_build_object('userId', i.user_id, 'role', i.role::text, 'organisationUnitId', i.organisation_unit_id, 'reason', i.reason),
       i.assigned_at
FROM inserted i;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261011000000_AddUserRoleAssignments', '10.0.8');

COMMIT;

