-- Migration: 20261013041113_RenameCoordinationStageAddGmRouting
-- RFC-011 / PLN-022 slice D3a (decisions D51-D52, D60): renames the "WorkRequestApprovalStage" label PROJECT_COORDINATION
-- to GM_ROUTING (the same ordinal, so audit rows that store the stage as a number keep their meaning), adds the GM's
-- routing columns to work_requests (delivery_route as text with a check, external_organisation_unit_id, routed_at,
-- routed_by_user_id, with foreign keys and indexes, and a check that an external unit is set only for an EXTERNAL route),
-- and retires the Project Coordinator role: any assignment of it is deleted (expected: none) and the
-- user_role_assignments_unit_matches_role_check no longer lists it.
--
-- Generated from the EF Core migration of the same name. Applying this script is
-- equivalent to `dotnet ef database update` from 20261012121756_AddSteeringCommitteeStage;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261012121756_AddSteeringCommitteeStage (and any migration between).
-- Roll back with 20261013041113_RenameCoordinationStageAddGmRouting.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261013041113_RenameCoordinationStageAddGmRouting.up.sql
--
-- NO EXISTING REQUEST CHANGES VALUE. Every request keeps its stage (a request waiting at PROJECT_COORDINATION now reads
-- GM_ROUTING) and status; the new columns start empty.
--
-- NOT IDEMPOTENT: the label rename fails if run twice. The script runs in one transaction together with its history row, so
-- a failure leaves nothing applied; do not run it on a database whose history already lists this migration.
--
-- The "AccessRole" label PROJECT_COORDINATOR stays in the database, unused: PostgreSQL cannot drop an enum value, and the
-- C# enum no longer has the member, so nothing reads or writes it.
--
-- Deploy order: run this BEFORE starting the API build that maps the new columns and the GM_ROUTING stage.

START TRANSACTION;
ALTER TYPE "WorkRequestApprovalStage" RENAME VALUE 'PROJECT_COORDINATION' TO 'GM_ROUTING';

DELETE FROM user_role_assignments WHERE role = 'PROJECT_COORDINATOR'::"AccessRole";

ALTER TABLE user_role_assignments DROP CONSTRAINT user_role_assignments_unit_matches_role_check;

ALTER TABLE work_requests ADD delivery_route text;

ALTER TABLE work_requests ADD external_organisation_unit_id uuid;

ALTER TABLE work_requests ADD routed_at timestamp(6) with time zone;

ALTER TABLE work_requests ADD routed_by_user_id uuid;

CREATE INDEX work_requests_external_organisation_unit_id_idx ON work_requests (external_organisation_unit_id);

CREATE INDEX work_requests_routed_by_user_id_idx ON work_requests (routed_by_user_id);

ALTER TABLE work_requests ADD CONSTRAINT work_requests_delivery_route_check CHECK (delivery_route IS NULL OR delivery_route IN ('INTERNAL', 'EXTERNAL'));

ALTER TABLE work_requests ADD CONSTRAINT work_requests_external_unit_route_check CHECK (external_organisation_unit_id IS NULL OR delivery_route = 'EXTERNAL');

ALTER TABLE user_role_assignments ADD CONSTRAINT user_role_assignments_unit_matches_role_check CHECK ((organisation_unit_id IS NULL) = (role IN ('FINANCE_MODERATOR'::"AccessRole", 'SYSTEM_ADMINISTRATOR'::"AccessRole", 'SUPER_ADMINISTRATOR'::"AccessRole", 'STEERING_COMMITTEE_MEMBER'::"AccessRole")));

ALTER TABLE work_requests ADD CONSTRAINT work_requests_external_organisation_unit_id_fkey FOREIGN KEY (external_organisation_unit_id) REFERENCES organisation_units (id) ON DELETE RESTRICT;

ALTER TABLE work_requests ADD CONSTRAINT work_requests_routed_by_user_id_fkey FOREIGN KEY (routed_by_user_id) REFERENCES users (id) ON DELETE SET NULL;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261013041113_RenameCoordinationStageAddGmRouting', '10.0.8');

COMMIT;
