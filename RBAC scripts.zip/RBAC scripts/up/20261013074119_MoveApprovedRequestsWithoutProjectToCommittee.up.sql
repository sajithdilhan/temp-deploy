-- Migration: 20261013074119_MoveApprovedRequestsWithoutProjectToCommittee
-- RFC-011 / PLN-022 slice H1 (decision D58): DATA ONLY, no schema change. Every PROJECT_REQUEST that was approved before the
-- Steering Committee step existed and has no project yet returns to the committee: status UNDER_REVIEW, stage
-- STEERING_COMMITTEE, steering_committee_reached_at = now(). approved_at, the committee approval fields and the returned
-- marker are cleared, exactly as a GM approval leaves a request entering the committee; hod_approved_at and gm_approved_at
-- are kept as they are.
--
-- SELECTION: request_type PROJECT_REQUEST, request_status APPROVED, approval_stage NULL or COMPLETED (the legacy
-- "approved, awaiting pickup" rows: backlog and start-now without a team), no row in projects with source_request_id = the
-- request, and no project_initiation_decisions row with initialized_at set. UNTOUCHED: requests at HOD or GM, requests at
-- the new stages (including an approved request at GM_ROUTING or INITIALISATION), initialised projects and change requests.
-- This is pre-check query 14 (docs/rfcs/RFC-011-assets/uat-access-precheck.sql).
--
-- AUDIT: one audit_logs row per moved request, WORK_REQUEST_STATUS_CHANGED, actor_user_id NULL (the system actor, as the slice
-- A backfill does), new_value {system: true, reason: 'CUTOVER_COMMITTEE_STEP', remarks}. Stages and statuses are stored as
-- their enum numbers, like every other WORK_REQUEST_STATUS_CHANGED row; old_value also keeps the previous approved_at so the
-- down script can restore it.
--
-- Generated from the EF Core migration of the same name (hand-filled: the model is unchanged). Applying this script is
-- equivalent to `dotnet ef database update` from 20261013041113_RenameCoordinationStageAddGmRouting;
-- it records the migration in __EFMigrationsHistory so EF does not reapply it.
--
-- Applies on top of 20261013041113_RenameCoordinationStageAddGmRouting (and any migration between).
-- Roll back with 20261013074119_MoveApprovedRequestsWithoutProjectToCommittee.down.sql.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261013074119_MoveApprovedRequestsWithoutProjectToCommittee.up.sql
--
-- IDEMPOTENT: a moved request is no longer APPROVED, so a second run selects nothing and writes no audit rows.
-- Take the database backup first (the move cannot be undone exactly if requests are worked on afterwards). Brief the
-- requesters and HODs of the moved requests before release: they reopen as "Pending Steering Committee approval". Until
-- Super Admins grant Steering Committee Member, they wait at the committee step (D47).

START TRANSACTION;
WITH candidates AS (
    SELECT w.id, w.approval_stage, w.approved_at
    FROM work_requests w
    WHERE w.request_type = 'PROJECT_REQUEST'::"RequestType"
      AND w.request_status = 'APPROVED'::"RequestStatus"
      AND (w.approval_stage IS NULL OR w.approval_stage = 'COMPLETED'::"WorkRequestApprovalStage")
      AND NOT EXISTS (SELECT 1 FROM projects p WHERE p.source_request_id = w.id)
      AND NOT EXISTS (SELECT 1 FROM project_initiation_decisions d WHERE d.work_request_id = w.id AND d.initialized_at IS NOT NULL)
),
moved AS (
    UPDATE work_requests w
    SET request_status = 'UNDER_REVIEW'::"RequestStatus",
        approval_stage = 'STEERING_COMMITTEE'::"WorkRequestApprovalStage",
        steering_committee_reached_at = now(),
        steering_committee_approved_at = NULL,
        steering_committee_golden_buzzer = false,
        steering_committee_returned_at = NULL,
        approved_at = NULL,
        reviewed_at = now(),
        updated_at = now()
    FROM candidates c
    WHERE w.id = c.id
    RETURNING w.id, w.steering_committee_reached_at AS moved_at
)
INSERT INTO audit_logs (id, actor_user_id, entity_type, entity_id, action, old_value, new_value, created_at)
SELECT gen_random_uuid(), NULL, 'WorkRequest', m.id, 'WORK_REQUEST_STATUS_CHANGED',
       jsonb_build_object('requestStatus', 6, 'approvalStage', CASE WHEN c.approval_stage IS NULL THEN NULL ELSE 2 END,
                          'approvedAt', c.approved_at),
       jsonb_build_object('requestStatus', 2, 'approvalStage', 3, 'system', true, 'reason', 'CUTOVER_COMMITTEE_STEP',
                          'remarks', 'Approved before the Steering Committee step existed and no project was created, so the request returns to the committee (RFC-011 D58).'),
       m.moved_at
FROM moved m
JOIN candidates c ON c.id = m.id;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261013074119_MoveApprovedRequestsWithoutProjectToCommittee', '10.0.8');

COMMIT;
