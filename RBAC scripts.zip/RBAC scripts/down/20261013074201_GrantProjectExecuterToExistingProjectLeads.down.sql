-- Rollback: 20261013074201_GrantProjectExecuterToExistingProjectLeads
-- Reverts the database to 20261013074119_MoveApprovedRequestsWithoutProjectToCommittee.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261013074201_GrantProjectExecuterToExistingProjectLeads.down.sql
--
-- REVOKES (does not delete) every unrevoked PROJECT_EXECUTER assignment this migration created, found by its exact reason text
-- and assigned_by_user_id NULL, with revoke_reason 'Rolled back: GrantProjectExecuterToExistingProjectLeads' and a
-- USER_ROLE_ASSIGNMENT_REVOKED audit row (no actor). The original grant rows and audits stay. A Project Executer a Super Admin
-- granted by hand is never touched. Projects whose lead relied on the grant lose their manager again, as before the grant.

START TRANSACTION;
WITH revoked AS (
    UPDATE user_role_assignments a
    SET revoked_at = now(), revoke_reason = 'Rolled back: GrantProjectExecuterToExistingProjectLeads'
    WHERE a.role = 'PROJECT_EXECUTER'::"AccessRole" AND a.revoked_at IS NULL AND a.assigned_by_user_id IS NULL
      AND a.reason = 'Migrated: lead of an existing project delivered by this unit (RFC-011 cut-over)'
    RETURNING a.id, a.user_id, a.role, a.organisation_unit_id, a.reason, a.revoked_at, a.revoke_reason
)
INSERT INTO audit_logs (id, actor_user_id, entity_type, entity_id, action, old_value, new_value, created_at)
SELECT gen_random_uuid(), NULL, 'UserRoleAssignment', r.id, 'USER_ROLE_ASSIGNMENT_REVOKED',
       jsonb_build_object('userId', r.user_id, 'role', r.role::text, 'organisationUnitId', r.organisation_unit_id, 'reason', r.reason),
       jsonb_build_object('revokedAt', r.revoked_at, 'revokeReason', r.revoke_reason),
       r.revoked_at
FROM revoked r;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261013074201_GrantProjectExecuterToExistingProjectLeads';

COMMIT;
