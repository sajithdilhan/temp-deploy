-- Rollback: 20261013074119_MoveApprovedRequestsWithoutProjectToCommittee
-- Reverts the database to 20261013041113_RenameCoordinationStageAddGmRouting.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261013074119_MoveApprovedRequestsWithoutProjectToCommittee.down.sql
--
-- BEST EFFORT, NOT A TRUE UNDO. The move changed rows in place, so it can only be reversed for requests nobody has touched
-- since. A request is put back to APPROVED (stage COMPLETED, or NULL as it was) with its previous approved_at, and
-- steering_committee_reached_at is cleared, ONLY when ALL hold: its latest audit row is this migration's
-- (actor NULL, reason CUTOVER_COMMITTEE_STEP); it is still UNDER_REVIEW at STEERING_COMMITTEE; it was not returned; it has no
-- committee approval row; and nothing was audited for it since. Anything else (a committee member already approved it, it was
-- returned, closed or edited) is left exactly as it is and must be dealt with by hand. Each restored request gets a
-- system WORK_REQUEST_STATUS_CHANGED row (reason CUTOVER_COMMITTEE_STEP_ROLLED_BACK); the original audit rows stay.
--
-- reviewed_at and updated_at are not restored (the previous values were not kept).

START TRANSACTION;
WITH latest AS (
    SELECT DISTINCT ON (a.entity_id) a.entity_id, a.created_at, a.old_value
    FROM audit_logs a
    WHERE a.entity_type = 'WorkRequest' AND a.action = 'WORK_REQUEST_STATUS_CHANGED'
      AND a.actor_user_id IS NULL AND a.new_value ->> 'reason' = 'CUTOVER_COMMITTEE_STEP'
    ORDER BY a.entity_id, a.created_at DESC
),
restorable AS (
    SELECT l.entity_id, l.old_value
    FROM latest l
    JOIN work_requests w ON w.id = l.entity_id
    WHERE w.request_status = 'UNDER_REVIEW'::"RequestStatus"
      AND w.approval_stage = 'STEERING_COMMITTEE'::"WorkRequestApprovalStage"
      AND w.steering_committee_returned_at IS NULL
      AND NOT EXISTS (SELECT 1 FROM work_request_committee_approvals c WHERE c.work_request_id = w.id)
      AND NOT EXISTS (SELECT 1 FROM audit_logs later WHERE later.entity_type = 'WorkRequest' AND later.entity_id = w.id AND later.created_at > l.created_at)
),
restored AS (
    UPDATE work_requests w
    SET request_status = 'APPROVED'::"RequestStatus",
        approval_stage = CASE WHEN r.old_value ->> 'approvalStage' IS NULL THEN NULL ELSE 'COMPLETED'::"WorkRequestApprovalStage" END,
        approved_at = (r.old_value ->> 'approvedAt')::timestamptz,
        steering_committee_reached_at = NULL,
        updated_at = now()
    FROM restorable r
    WHERE w.id = r.entity_id
    RETURNING w.id
)
INSERT INTO audit_logs (id, actor_user_id, entity_type, entity_id, action, old_value, new_value, created_at)
SELECT gen_random_uuid(), NULL, 'WorkRequest', r.id, 'WORK_REQUEST_STATUS_CHANGED',
       jsonb_build_object('requestStatus', 2, 'approvalStage', 3),
       jsonb_build_object('requestStatus', 6, 'system', true, 'reason', 'CUTOVER_COMMITTEE_STEP_ROLLED_BACK'),
       now()
FROM restored r;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261013074119_MoveApprovedRequestsWithoutProjectToCommittee';

COMMIT;
