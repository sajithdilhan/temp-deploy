-- Rollback: 20261013041113_RenameCoordinationStageAddGmRouting
-- Reverts the database to 20261012121756_AddSteeringCommitteeStage.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261013041113_RenameCoordinationStageAddGmRouting.down.sql
--
-- Renames the "WorkRequestApprovalStage" label GM_ROUTING back to PROJECT_COORDINATION, drops the four routing columns
-- (with their foreign keys, indexes and checks) on work_requests, and lists PROJECT_COORDINATOR in the role check again.
--
-- DATA LOSS: every routing (route, external unit, routed_at, routed_by) is lost with the columns. A request already routed
-- (stage INITIALISATION) goes back to waiting for routing (the renamed stage), because its route cannot be kept. Their
-- audit_logs rows are kept. Deleted Project Coordinator assignments are NOT restored (the up script expected none).
--
-- Only roll back alongside the API build that does not map the new columns or the GM_ROUTING stage.

START TRANSACTION;
UPDATE work_requests SET approval_stage = 'GM_ROUTING'::"WorkRequestApprovalStage" WHERE approval_stage = 'INITIALISATION'::"WorkRequestApprovalStage";

ALTER TABLE work_requests DROP CONSTRAINT work_requests_external_organisation_unit_id_fkey;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_routed_by_user_id_fkey;

DROP INDEX work_requests_external_organisation_unit_id_idx;

DROP INDEX work_requests_routed_by_user_id_idx;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_delivery_route_check;

ALTER TABLE work_requests DROP CONSTRAINT work_requests_external_unit_route_check;

ALTER TABLE user_role_assignments DROP CONSTRAINT user_role_assignments_unit_matches_role_check;

ALTER TABLE work_requests DROP COLUMN delivery_route;

ALTER TABLE work_requests DROP COLUMN external_organisation_unit_id;

ALTER TABLE work_requests DROP COLUMN routed_at;

ALTER TABLE work_requests DROP COLUMN routed_by_user_id;

ALTER TABLE user_role_assignments ADD CONSTRAINT user_role_assignments_unit_matches_role_check CHECK ((organisation_unit_id IS NULL) = (role IN ('FINANCE_MODERATOR'::"AccessRole", 'SYSTEM_ADMINISTRATOR'::"AccessRole", 'SUPER_ADMINISTRATOR'::"AccessRole", 'STEERING_COMMITTEE_MEMBER'::"AccessRole", 'PROJECT_COORDINATOR'::"AccessRole")));

ALTER TYPE "WorkRequestApprovalStage" RENAME VALUE 'GM_ROUTING' TO 'PROJECT_COORDINATION';

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261013041113_RenameCoordinationStageAddGmRouting';

COMMIT;
