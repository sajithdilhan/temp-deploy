-- Rollback: 20261012072349_AddExternalBusinessUnitsAndCommitteeRoles
-- Reverts the database to 20261011000000_AddUserRoleAssignments.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261012072349_AddExternalBusinessUnitsAndCommitteeRoles.down.sql
--
-- Drops organisation_units.is_external and hod_user_id (and their checks, index and foreign key), and puts back the
-- previous three-role unscoped check on user_role_assignments.
--
-- DATA LOSS: every Steering Committee Member and Project Coordinator assignment is DELETED (a NOTICE reports how
-- many), because the previous constraint would reject them. Their audit_logs rows are kept. Every external
-- classification is lost with the columns. PostgreSQL cannot drop an enum value, so the two "AccessRole" labels stay;
-- they are unused and harmless, and the up script is idempotent about them.
--
-- Only roll back alongside the API build that does not map the new columns or roles.

START TRANSACTION;
ALTER TABLE organisation_units DROP CONSTRAINT organisation_units_hod_user_id_fkey;

ALTER TABLE user_role_assignments DROP CONSTRAINT user_role_assignments_unit_matches_role_check;

DROP INDEX organisation_units_hod_user_id_idx;

ALTER TABLE organisation_units DROP CONSTRAINT organisation_units_external_has_hod_check;

ALTER TABLE organisation_units DROP CONSTRAINT organisation_units_external_is_business_unit_check;

ALTER TABLE organisation_units DROP COLUMN hod_user_id;

ALTER TABLE organisation_units DROP COLUMN is_external;


DO $$
DECLARE removed integer;
BEGIN
    DELETE FROM user_role_assignments
    WHERE role IN ('STEERING_COMMITTEE_MEMBER'::"AccessRole", 'PROJECT_COORDINATOR'::"AccessRole");
    GET DIAGNOSTICS removed = ROW_COUNT;
    RAISE NOTICE 'Removed % Steering Committee Member / Project Coordinator role assignments', removed;
END $$;

ALTER TABLE user_role_assignments ADD CONSTRAINT user_role_assignments_unit_matches_role_check CHECK ((organisation_unit_id IS NULL) = (role IN ('FINANCE_MODERATOR'::"AccessRole", 'SYSTEM_ADMINISTRATOR'::"AccessRole", 'SUPER_ADMINISTRATOR'::"AccessRole")));

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261012072349_AddExternalBusinessUnitsAndCommitteeRoles';

COMMIT;

