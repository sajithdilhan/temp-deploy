-- Rollback: 20261012121756_AddSteeringCommitteeStage
-- Reverts the database to 20261012072349_AddExternalBusinessUnitsAndCommitteeRoles.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261012121756_AddSteeringCommitteeStage.down.sql
--
-- Drops the work_request_committee_approvals table, the queue index and the four steering_committee_* columns on
-- work_requests.
--
-- DATA LOSS: every committee approval row and the committee timestamps and Golden Buzzer marker are lost with the
-- table and columns. Requests are moved off the new stages first (a request waiting at STEERING_COMMITTEE (status UNDER_REVIEW) goes
-- back to GM; one rejected there also goes to GM, as a GM rejection was stored; one at PROJECT_COORDINATION or INITIALISATION goes to COMPLETED, the previous "approved, no project yet"
-- state). Their audit_logs rows are kept. PostgreSQL cannot drop an enum value, so the three
-- "WorkRequestApprovalStage" labels stay; they are unused and harmless, and the up script is idempotent about them.
--
-- Only roll back alongside the API build that does not map the new columns or stages.

START TRANSACTION;
UPDATE work_requests SET approval_stage = 'GM'::"WorkRequestApprovalStage" WHERE approval_stage = 'STEERING_COMMITTEE'::"WorkRequestApprovalStage" AND request_status = 'UNDER_REVIEW'::"RequestStatus";

UPDATE work_requests SET approval_stage = 'GM'::"WorkRequestApprovalStage" WHERE approval_stage = 'STEERING_COMMITTEE'::"WorkRequestApprovalStage";

UPDATE work_requests SET approval_stage = 'COMPLETED'::"WorkRequestApprovalStage"
WHERE approval_stage IN ('PROJECT_COORDINATION'::"WorkRequestApprovalStage", 'INITIALISATION'::"WorkRequestApprovalStage");

DROP TABLE work_request_committee_approvals;

DROP INDEX work_requests_approval_stage_status_idx;

ALTER TABLE work_requests DROP COLUMN steering_committee_approved_at;

ALTER TABLE work_requests DROP COLUMN steering_committee_golden_buzzer;

ALTER TABLE work_requests DROP COLUMN steering_committee_reached_at;

ALTER TABLE work_requests DROP COLUMN steering_committee_returned_at;

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261012121756_AddSteeringCommitteeStage';

COMMIT;
