-- Rollback: 20261011000000_AddUserRoleAssignments
-- Reverts the database to 20261010073248_AddLoginOtp.
--
--   psql -h <host> -U <user> -d <database> -v ON_ERROR_STOP=1 -f 20261011000000_AddUserRoleAssignments.down.sql
--
-- Drops user_role_assignments and the "AccessRole" enum. The legacy users.role and
-- users.organisation_unit_id columns were never changed, so nothing else is restored. The
-- backfill's USER_ROLE_ASSIGNMENT_GRANTED audit rows (system-made, "Migrated from legacy role ...") are
-- deleted with it (a NOTICE reports how many), since they describe assignments that no longer exist;
-- later grants keep their rows.
--
-- Only roll back alongside the API build that does not map user_role_assignments; the newer
-- build fails to look users up once the table is gone.

START TRANSACTION;

DO $$
DECLARE removed integer;
BEGIN
    DELETE FROM audit_logs
    WHERE entity_type = 'UserRoleAssignment'
      AND action = 'USER_ROLE_ASSIGNMENT_GRANTED'
      AND actor_user_id IS NULL
      AND new_value ->> 'reason' LIKE 'Migrated from legacy role %';
    GET DIAGNOSTICS removed = ROW_COUNT;
    RAISE NOTICE 'Removed % backfill audit rows for user role assignments', removed;
END $$;

DROP TABLE user_role_assignments;

DROP TYPE "AccessRole";

DELETE FROM "__EFMigrationsHistory"
WHERE "MigrationId" = '20261011000000_AddUserRoleAssignments';

COMMIT;

