-- RFC-011 — UAT access pre-check (READ-ONLY)
--
-- Run against a COPY of the UAT database before the role + scope migration is designed in
-- detail, and again before cut-over. Every statement is a SELECT inside a read-only
-- transaction; nothing is changed. Export each result set for the business review (RFC-011 §
-- "Migration and UAT cut-over").
--
--   psql -v ON_ERROR_STOP=1 "$CONNECTION" -f docs/rfcs/RFC-011-assets/uat-access-precheck.sql
--
-- The agreed mapping (RFC-011 § "Mapping table", applied as-is):
--   EXTERNAL_USER -> no assignment (pending list)     USER        -> Contributor at current unit
--   MANAGER       -> Contributor + Approver at unit   MODERATOR   -> Pain Point Moderator at unit
--   ADMIN         -> System Administrator (All)       SUPER_ADMIN -> Super Administrator (All)
--
-- Approval after cut-over (D1, revised 2026-10-07): HOD -> GM -> Steering Committee. HOD and GM
-- stay named per request, as today; the committee is one global list of members (D31).
--
-- HOD/GM eligibility today (ADR-016): active, MANAGER or above, in the requesting unit or one
-- of its ancestors. After mapping (D1, D27): active, legacy MANAGER (now Approver) in the
-- requesting unit or an ancestor, or a Super Admin. MODERATOR and ADMIN lose eligibility.
-- Committee members need no Approver (D46): a Super Admin can grant Steering Committee Member to any
-- active person. Queries 14, 16 and 17-19 cover the cut-over (D58, D56, C2).
--
-- Queries 17-19 read tables and columns added by the access migrations (organisation_units.is_external,
-- user_role_assignments). Run the whole file on a UAT COPY that already has the slice A-D3a migrations applied
-- but NOT the two H1 data migrations (MoveApprovedRequestsWithoutProjectToCommittee and
-- GrantProjectExecuterToExistingProjectLeads): queries 14, 18 and 19 then show exactly what those migrations do.

BEGIN TRANSACTION READ ONLY;

-- 1. Population: active users per legacy role and the type of unit they sit in.
SELECT u.role,
       coalesce(ou.type::text, '(no unit)') AS unit_type,
       count(*) FILTER (WHERE u.is_active)     AS active_users,
       count(*) FILTER (WHERE NOT u.is_active) AS inactive_users,
       count(*) FILTER (WHERE u.is_active AND u.team_id IS NOT NULL) AS active_with_team
FROM users u
LEFT JOIN organisation_units ou ON ou.id = u.organisation_unit_id
GROUP BY u.role, ou.type
ORDER BY u.role, unit_type;

-- 2. Users the automatic mapping cannot place: active USER, MANAGER or MODERATOR (the roles
--    that map to a scoped assignment) with no unit or an inactive unit. Each needs a decision
--    before the migration can run. ADMIN and SUPER_ADMIN map to "All" and need no unit.
SELECT u.id, u.email, u.role, u.organisation_unit_id, ou.is_active AS unit_active
FROM users u
LEFT JOIN organisation_units ou ON ou.id = u.organisation_unit_id
WHERE u.is_active
  AND u.role IN ('USER', 'MANAGER', 'MODERATOR')
  AND (u.organisation_unit_id IS NULL OR ou.is_active = false)
ORDER BY u.role, u.email;

-- 3. Pending accounts (D8): active EXTERNAL_USER accounts. They get no assignment, join the
--    pending list and can no longer sign in after cut-over.
SELECT u.id, u.email, u.created_at
FROM users u
WHERE u.is_active AND u.role = 'EXTERNAL_USER'
ORDER BY u.created_at;

-- 4. Moderators: each becomes a Pain Point Moderator only, losing user and organisation
--    administration, approvals, dashboards and delivery rights over their subtree. Shows what
--    they administer today and the open requests naming them as an approver (stranded unless
--    re-routed or they are granted Approver).
WITH RECURSIVE subtree AS (
    SELECT u.id AS moderator_id, ou.id AS unit_id
    FROM users u JOIN organisation_units ou ON ou.id = u.organisation_unit_id
    WHERE u.is_active AND u.role = 'MODERATOR'
    UNION ALL
    SELECT s.moderator_id, child.id
    FROM subtree s JOIN organisation_units child ON child.parent_id = s.unit_id
)
SELECT m.id, m.email, ou.type AS unit_type, ou.name AS unit_name,
       count(DISTINCT s.unit_id) AS units_in_subtree,
       (SELECT count(*) FROM users x WHERE x.is_active AND x.organisation_unit_id IN
            (SELECT unit_id FROM subtree s2 WHERE s2.moderator_id = m.id)) AS users_in_subtree,
       (SELECT count(*) FROM work_requests w
         WHERE w.request_status IN ('SUBMITTED', 'UNDER_REVIEW')
           AND w.requesting_organisation_unit_id IN
               (SELECT unit_id FROM subtree s3 WHERE s3.moderator_id = m.id)) AS open_requests_in_subtree,
       (SELECT count(*) FROM work_requests w
         WHERE w.request_status IN ('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'CHANGES_REQUESTED')
           AND m.id IN (w.hod_approver_user_id, w.gm_approver_user_id)) AS open_requests_naming_them
FROM users m
JOIN organisation_units ou ON ou.id = m.organisation_unit_id
JOIN subtree s ON s.moderator_id = m.id
GROUP BY m.id, m.email, ou.type, ou.name
ORDER BY m.email;

-- 5. In-flight approvals: every open request with its named HOD and GM, and whether each is
--    eligible TODAY and AFTER mapping. Any row with a false *_after column must be re-routed
--    before cut-over: that approver will not hold Approver (MODERATOR, ADMIN) or is inactive.
--    The GM matters even while the request is still at HOD: it will reach the GM after cut-over.
WITH RECURSIVE ancestors AS (
    SELECT w.id AS request_id, w.requesting_organisation_unit_id AS unit_id
    FROM work_requests w
    WHERE w.request_status IN ('SUBMITTED', 'UNDER_REVIEW') AND w.approval_stage IN ('HOD', 'GM')
    UNION ALL
    SELECT a.request_id, ou.parent_id
    FROM ancestors a JOIN organisation_units ou ON ou.id = a.unit_id
    WHERE ou.parent_id IS NOT NULL
),
named AS (
    SELECT w.id, w.request_no, w.project_name, w.request_status, w.approval_stage,
           w.requester_user_id, rou.type AS requesting_unit_type,
           step.name AS step, appr.id AS approver_id, appr.email AS approver,
           appr.role AS approver_role, appr.is_active AS approver_active,
           (rou.type = 'GROUP'
            OR appr.organisation_unit_id IN (SELECT a.unit_id FROM ancestors a WHERE a.request_id = w.id))
               AS approver_in_line
    FROM work_requests w
    LEFT JOIN organisation_units rou ON rou.id = w.requesting_organisation_unit_id
    CROSS JOIN LATERAL (VALUES ('HOD', w.hod_approver_user_id), ('GM', w.gm_approver_user_id)) AS step(name, user_id)
    LEFT JOIN users appr ON appr.id = step.user_id
    WHERE w.request_status IN ('SUBMITTED', 'UNDER_REVIEW') AND w.approval_stage IN ('HOD', 'GM')
      AND NOT (w.approval_stage = 'GM' AND step.name = 'HOD')  -- a decided HOD step needs no check
)
SELECT n.request_no, n.project_name, n.request_status, n.approval_stage, n.step,
       n.approver, n.approver_role, n.approver_active,
       coalesce(n.approver_active
                AND n.approver_role IN ('MANAGER', 'MODERATOR', 'ADMIN', 'SUPER_ADMIN')
                AND n.approver_in_line, false)                       AS eligible_today,
       coalesce(n.approver_active
                AND ((n.approver_role = 'MANAGER' AND n.approver_in_line)
                     OR n.approver_role = 'SUPER_ADMIN'), false)      AS eligible_after,
       (n.requester_user_id = n.approver_id)                          AS requester_is_approver
FROM named n
ORDER BY eligible_after, n.approval_stage, n.request_no, n.step;

-- 6. Self-approval exposure (D4): open requests where the requester is also a named approver.
--    Nobody is mapped to Self-Approver, so each row must be re-routed before cut-over.
--    requester_is_admin shows requests an ADMIN/SUPER_ADMIN raised and could approve today at
--    any stage; that override ends (D27) but needs no re-routing on its own.
SELECT w.request_no, w.project_name, w.request_status, w.approval_stage,
       req.email AS requester, req.role AS requester_role,
       (w.hod_approver_user_id = w.requester_user_id) AS requester_is_hod,
       (w.gm_approver_user_id  = w.requester_user_id) AS requester_is_gm,
       (req.role IN ('ADMIN', 'SUPER_ADMIN'))          AS requester_is_admin,
       -- true = a step still to be decided belongs to the requester: must be re-routed.
       -- Rows at GM with requester_is_hod only show a self-endorsement that already happened.
       ((w.approval_stage = 'HOD' AND w.requester_user_id IN (w.hod_approver_user_id, w.gm_approver_user_id))
        OR (w.approval_stage = 'GM' AND w.gm_approver_user_id = w.requester_user_id)
        OR (w.request_status IN ('DRAFT', 'CHANGES_REQUESTED')
            AND w.requester_user_id IN (w.hod_approver_user_id, w.gm_approver_user_id))) AS needs_rerouting
FROM work_requests w
JOIN users req ON req.id = w.requester_user_id
WHERE w.request_status IN ('DRAFT', 'SUBMITTED', 'UNDER_REVIEW', 'CHANGES_REQUESTED')
  AND (w.hod_approver_user_id = w.requester_user_id
       OR w.gm_approver_user_id = w.requester_user_id
       OR req.role IN ('ADMIN', 'SUPER_ADMIN'))
ORDER BY needs_rerouting DESC, w.request_status, w.request_no;

-- 7. Project visibility exposure (D3, D10, D17): per active user, how many projects they
--    reach through a direct relationship (requester, team lead, active member) versus only
--    through their organisation position. After mapping, USER and MANAGER keep read access to
--    position-only projects in their subtree (as Contributor) but lose edit rights; MODERATOR
--    and ADMIN keep neither (ADMIN keeps read as System Administrator).
WITH RECURSIVE user_subtree AS (
    SELECT u.id AS user_id, u.organisation_unit_id AS unit_id
    FROM users u WHERE u.is_active AND u.organisation_unit_id IS NOT NULL
    UNION ALL
    SELECT s.user_id, child.id
    FROM user_subtree s JOIN organisation_units child ON child.parent_id = s.unit_id
),
related AS (
    SELECT p.id AS project_id, u.id AS user_id
    FROM projects p JOIN users u ON u.id IN (p.requester_user_id, p.team_lead_id)
    UNION
    SELECT pm.project_id, pm.user_id FROM project_members pm WHERE pm.left_at IS NULL
),
positional AS (
    SELECT p.id AS project_id, s.user_id
    FROM projects p
    JOIN user_subtree s ON s.unit_id IN (p.owning_organisation_unit_id,
                                         p.delivery_organisation_unit_id,
                                         p.requesting_organisation_unit_id)
    WHERE p.status NOT IN ('COMPLETED', 'ARCHIVED')
)
SELECT u.role, u.email,
       (SELECT count(*) FROM related r WHERE r.user_id = u.id) AS related_projects,
       (SELECT count(*) FROM positional po WHERE po.user_id = u.id
          AND NOT EXISTS (SELECT 1 FROM related r WHERE r.user_id = u.id AND r.project_id = po.project_id))
           AS position_only_projects_in_subtree
FROM users u
WHERE u.is_active AND u.role <> 'EXTERNAL_USER'
ORDER BY u.role, position_only_projects_in_subtree DESC, u.email;

-- 8. Pain point tags by unit type and the role of whoever created them (D21: tags may now
--    also sit on Group and Business Area units).
SELECT ou.type AS unit_type, coalesce(cu.role::text, '(unknown)') AS creator_role,
       count(*) FILTER (WHERE t.is_active) AS active_tags, count(*) AS all_tags
FROM pain_point_tags t
JOIN organisation_units ou ON ou.id = t.organisation_unit_id
LEFT JOIN users cu ON cu.id = t.created_by_user_id
GROUP BY ou.type, cu.role
ORDER BY ou.type, creator_role;

-- 9. Open incidents by the role of the assignee (D18: incidents are administered by Project
--    Executers in scope, and nobody is mapped to Project Executer).
SELECT coalesce(a.role::text, '(unassigned)') AS assignee_role, i.status, count(*)
FROM incident_support_logs i
LEFT JOIN users a ON a.id = i.assigned_to_user_id
WHERE i.status::text NOT IN ('RESOLVED', 'CLOSED', 'CANCELLED')
GROUP BY a.role, i.status
ORDER BY assignee_role, i.status;

-- 10. Requests in RECOMMENDED or NOT_RECOMMENDED (D13): these statuses leave the workflow.
--     Change requests are returned to CHANGES_REQUESTED automatically at cut-over (D39; also
--     counted in query 15). A project request listed here must be decided or returned by hand.
SELECT w.request_no, w.request_type, w.project_name, w.request_status, w.updated_at,
       req.email AS requester
FROM work_requests w
LEFT JOIN users req ON req.id = w.requester_user_id
WHERE w.request_status IN ('RECOMMENDED', 'NOT_RECOMMENDED')
ORDER BY w.request_status, w.updated_at;

-- 11. Live projects and who can manage them after cut-over (D17): the Project Executer and the
--     requester. Nobody is mapped to Project Executer, so the team lead is listed as the
--     natural Executer to grant at the delivery unit. Rows with requester_can_manage = false
--     have nobody able to manage them until an Executer is granted.
SELECT p.project_code, p.project_name, p.status, du.name AS delivery_unit, du.type AS delivery_unit_type,
       lead.email AS team_lead, lead.role AS team_lead_role, lead.is_active AS team_lead_active,
       req.email AS requester, req.role AS requester_role,
       coalesce(req.is_active AND req.role IN ('USER', 'MANAGER', 'SUPER_ADMIN'), false) AS requester_can_manage
FROM projects p
LEFT JOIN organisation_units du ON du.id = p.delivery_organisation_unit_id
LEFT JOIN users lead ON lead.id = p.team_lead_id
LEFT JOIN users req  ON req.id  = p.requester_user_id
WHERE p.status NOT IN ('COMPLETED', 'ARCHIVED', 'CANCELLED')
ORDER BY requester_can_manage, du.name, p.project_name;

-- 12. Wide Contributors (D10): active USER and MANAGER accounts sitting at a Group or Business
--     Area unit. As Contributors they will read every non-draft request and project in that
--     whole subtree.
WITH RECURSIVE subtree AS (
    SELECT u.id AS user_id, ou.id AS unit_id
    FROM users u JOIN organisation_units ou ON ou.id = u.organisation_unit_id
    WHERE u.is_active AND u.role IN ('USER', 'MANAGER') AND ou.type IN ('GROUP', 'BUSINESS_AREA')
    UNION ALL
    SELECT s.user_id, child.id
    FROM subtree s JOIN organisation_units child ON child.parent_id = s.unit_id
)
SELECT u.email, u.role, ou.type AS unit_type, ou.name AS unit_name,
       count(DISTINCT s.unit_id) AS units_in_reach
FROM users u
JOIN organisation_units ou ON ou.id = u.organisation_unit_id
JOIN subtree s ON s.user_id = u.id
GROUP BY u.email, u.role, ou.type, ou.name
ORDER BY units_in_reach DESC, u.email;

-- 13. Super Admins: after cut-over only they can grant tier-1 roles and the first User
--     Administrators, and they cannot revoke each other.
SELECT u.email, u.is_active, u.created_at
FROM users u
WHERE u.role = 'SUPER_ADMIN'
ORDER BY u.is_active DESC, u.email;

-- 14. Approved project requests with no project yet (D58): the approved list (BACKLOG) and
--     awaiting assignment (START_NOW without a team). THIS IS EXACTLY THE SELECTION of the data migration
--     MoveApprovedRequestsWithoutProjectToCommittee: project request, APPROVED, stage NULL or COMPLETED (the
--     legacy path), no project created from it and not initialised. At cut-over each returns to
--     "Pending Steering Committee approval" with a system audit row; brief the requester and the HOD before it
--     reopens. Requests with no initiation decision row are included (disposition is then null).
SELECT w.request_no, w.project_name, w.approved_at, d.disposition,
       (d.team_id IS NOT NULL) AS team_chosen,
       req.email AS requester, hod.email AS hod, gm.email AS gm
FROM work_requests w
LEFT JOIN project_initiation_decisions d ON d.work_request_id = w.id
LEFT JOIN users req ON req.id = w.requester_user_id
LEFT JOIN users hod ON hod.id = w.hod_approver_user_id
LEFT JOIN users gm  ON gm.id  = w.gm_approver_user_id
WHERE w.request_type = 'PROJECT_REQUEST'
  AND w.request_status = 'APPROVED'
  AND (w.approval_stage IS NULL OR w.approval_stage = 'COMPLETED')
  AND d.initialized_at IS NULL
  AND NOT EXISTS (SELECT 1 FROM projects p WHERE p.source_request_id = w.id)
ORDER BY d.disposition, w.approved_at;

-- 15. In-flight requests with no approval stage (D14, D39). Change requests in these statuses
--     move to CHANGES_REQUESTED automatically at cut-over, so the requester can name an HOD and
--     GM and resubmit. Legacy project requests with no stage (the old direct-approval path)
--     are not moved: each must be decided or returned by hand (needs_manual_decision).
SELECT w.request_no, w.request_type, w.project_name, w.request_status, w.updated_at,
       req.email AS requester,
       (w.request_type <> 'CHANGE_REQUEST') AS needs_manual_decision
FROM work_requests w
LEFT JOIN users req ON req.id = w.requester_user_id
WHERE w.request_status IN ('SUBMITTED', 'UNDER_REVIEW', 'RECOMMENDED', 'NOT_RECOMMENDED')
  AND (w.request_type = 'CHANGE_REQUEST' OR w.approval_stage IS NULL)
ORDER BY needs_manual_decision DESC, w.request_type, w.request_status, w.updated_at;

-- 16. Steering Committee candidates (D31, D46; revised for H1). Approver is NOT a prerequisite: a Super Admin
--     grants Steering Committee Member to any active person, as an unscoped role. This list is only a
--     starting point for the business to pick from: active people who hold a senior legacy role at the Group or
--     Business Area level (MANAGER, MODERATOR or ADMIN sitting at a GROUP or BUSINESS_AREA unit), plus every
--     active Super Admin (who is not a member unless granted the role). Nothing here grants anything; until
--     the role is granted, requests wait at the committee step (D47).
SELECT u.email, u.full_name, u.role, coalesce(ou.type::text, '(no unit)') AS unit_type, ou.name AS unit_name,
       CASE WHEN u.role = 'SUPER_ADMIN' THEN 'Super Admin' ELSE 'Senior role at group / business-area level' END AS suggested_because
FROM users u
LEFT JOIN organisation_units ou ON ou.id = u.organisation_unit_id
WHERE u.is_active
  AND (u.role = 'SUPER_ADMIN'
       OR (u.role IN ('MANAGER', 'MODERATOR', 'ADMIN') AND ou.type IN ('GROUP', 'BUSINESS_AREA')))
ORDER BY (u.role = 'SUPER_ADMIN'), ou.type, ou.name, u.email;

-- 17. External business units without a valid HOD (D56, D60). Each external unit needs an active HOD who holds
--     an unrevoked role assignment at an active unit at or beneath it, or requests routed to it cannot be
--     initialised. Every row is a problem to fix before release (name another HOD, or switch the unit to
--     internal). An empty result is good.
WITH RECURSIVE beneath AS (
    SELECT ou.id AS external_id, ou.id AS unit_id FROM organisation_units ou WHERE ou.is_external
    UNION ALL
    SELECT b.external_id, c.id FROM beneath b JOIN organisation_units c ON c.parent_id = b.unit_id
)
SELECT ou.code, ou.name, ou.is_active, hod.email AS hod, hod.is_active AS hod_active,
       EXISTS (SELECT 1 FROM user_role_assignments a
               JOIN beneath b ON b.external_id = ou.id AND b.unit_id = a.organisation_unit_id
               JOIN organisation_units bu ON bu.id = b.unit_id AND bu.is_active
               WHERE a.user_id = ou.hod_user_id AND a.revoked_at IS NULL) AS hod_has_assignment_at_or_beneath,
       (SELECT count(*) FROM work_requests w
         WHERE w.external_organisation_unit_id = ou.id AND w.approval_stage = 'INITIALISATION') AS requests_routed_here
FROM organisation_units ou
LEFT JOIN users hod ON hod.id = ou.hod_user_id
WHERE ou.is_external
  AND (hod.id IS NULL
       OR NOT hod.is_active
       OR NOT EXISTS (SELECT 1 FROM user_role_assignments a
                      JOIN beneath b ON b.external_id = ou.id AND b.unit_id = a.organisation_unit_id
                      JOIN organisation_units bu ON bu.id = b.unit_id AND bu.is_active
                      WHERE a.user_id = ou.hod_user_id AND a.revoked_at IS NULL))
ORDER BY ou.name;

-- 18. Project leads who will gain Project Executer (data migration GrantProjectExecuterToExistingProjectLeads,
--     C2 decision). One row per lead and delivery unit that needs a grant: LIVE project (not COMPLETED, ARCHIVED
--     or CANCELLED), ACTIVE lead who is not a Super Admin, ACTIVE delivery unit, and no unrevoked Project Executer
--     already covering that unit (at it or an active ancestor). The business reviews this list; a lead missing
--     here but expected is explained by query 19.
WITH RECURSIVE leads AS (
    SELECT p.team_lead_id AS user_id, p.delivery_organisation_unit_id AS unit_id, count(*) AS live_projects
    FROM projects p
    JOIN users u ON u.id = p.team_lead_id AND u.is_active AND u.role <> 'SUPER_ADMIN'
    JOIN organisation_units du ON du.id = p.delivery_organisation_unit_id AND du.is_active
    WHERE p.status NOT IN ('COMPLETED', 'ARCHIVED', 'CANCELLED')
      AND NOT EXISTS (SELECT 1 FROM user_role_assignments s
                      WHERE s.user_id = u.id AND s.role = 'SUPER_ADMINISTRATOR' AND s.revoked_at IS NULL)
    GROUP BY p.team_lead_id, p.delivery_organisation_unit_id
),
line (user_id, unit_id, line_unit_id) AS (
    SELECT l.user_id, l.unit_id, l.unit_id FROM leads l
    UNION ALL
    SELECT li.user_id, li.unit_id, ou.parent_id
    FROM line li JOIN organisation_units ou ON ou.id = li.line_unit_id
    WHERE ou.parent_id IS NOT NULL
)
SELECT u.email, u.role AS legacy_role, du.type AS delivery_unit_type, du.name AS delivery_unit, l.live_projects
FROM leads l
JOIN users u ON u.id = l.user_id
JOIN organisation_units du ON du.id = l.unit_id
WHERE NOT EXISTS (
    SELECT 1 FROM line li
    JOIN organisation_units lu ON lu.id = li.line_unit_id AND lu.is_active
    JOIN user_role_assignments a ON a.organisation_unit_id = li.line_unit_id
    WHERE li.user_id = l.user_id AND li.unit_id = l.unit_id
      AND a.user_id = l.user_id AND a.role = 'PROJECT_EXECUTER' AND a.revoked_at IS NULL)
ORDER BY du.name, u.email;

-- 19. Live projects whose lead gets NO Project Executer grant from the migration, and so have no Executer after
--     cut-over (the requester can still manage the project). Reasons: no lead, inactive lead, Super Admin lead
--     (never a lead, D16), no delivery unit or an inactive one. Fix by naming a lead or reactivating the unit,
--     or grant by hand after release.
SELECT p.project_code, p.project_name, p.status, du.name AS delivery_unit, lead.email AS team_lead,
       CASE WHEN p.team_lead_id IS NULL THEN 'no lead'
            WHEN NOT lead.is_active THEN 'lead is inactive'
            WHEN lead.role = 'SUPER_ADMIN' OR EXISTS (SELECT 1 FROM user_role_assignments s WHERE s.user_id = lead.id AND s.role = 'SUPER_ADMINISTRATOR' AND s.revoked_at IS NULL) THEN 'lead is a Super Admin'
            WHEN p.delivery_organisation_unit_id IS NULL THEN 'no delivery unit'
            WHEN NOT du.is_active THEN 'delivery unit is inactive'
       END AS reason
FROM projects p
LEFT JOIN users lead ON lead.id = p.team_lead_id
LEFT JOIN organisation_units du ON du.id = p.delivery_organisation_unit_id
WHERE p.status NOT IN ('COMPLETED', 'ARCHIVED', 'CANCELLED')
  AND (p.team_lead_id IS NULL OR NOT lead.is_active OR lead.role = 'SUPER_ADMIN'
       OR EXISTS (SELECT 1 FROM user_role_assignments s WHERE s.user_id = lead.id AND s.role = 'SUPER_ADMINISTRATOR' AND s.revoked_at IS NULL)
       OR p.delivery_organisation_unit_id IS NULL OR NOT du.is_active)
ORDER BY reason, du.name, p.project_name;

ROLLBACK;
