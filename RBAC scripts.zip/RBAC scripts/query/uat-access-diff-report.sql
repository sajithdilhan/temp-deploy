-- RFC-011 — UAT access diff report (READ-ONLY)
--
-- "Diff report" of the migration plan (RFC-011 § "Migration and UAT cut-over", step 3; PLN-022 slice H): compares each
-- user's LEGACY access (users.role and users.organisation_unit_id) with their EFFECTIVE role assignments (unrevoked rows of
-- user_role_assignments, role + scope). The business reviews and signs it off before release, and again after the
-- post-release grants (re-run it, release step 5). It changes nothing: the only writes are three TEMPORARY tables (PostgreSQL does not allow
-- creating even those in a READ ONLY transaction), created and dropped inside one transaction that ends in ROLLBACK.
--
--   psql -v ON_ERROR_STOP=1 "$CONNECTION" -f docs/rfcs/RFC-011-assets/uat-access-diff-report.sql
--
-- WHAT IT COMPARES. For each user, the assignments the mapping table gives their legacy role (the "expected" set, derived
-- here from users.role and users.organisation_unit_id exactly as the slice A backfill does) against the assignments they
-- actually hold now. Differences are the verdicts:
--   SAME               the user holds exactly the mapped assignments.
--   LOST               a mapped assignment is missing (never backfilled, revoked since, or the unit changed).
--   GAINED             the user holds assignments beyond the mapping (Project Executer from the lead grant, Steering
--                      Committee Member, User Administrator, hand-granted roles, a unit the user was moved to).
--   LOST_AND_GAINED    both.
--   PENDING            an active EXTERNAL_USER: no assignment by design (D8), the account joins the pending list.
--   (inactive users are listed with INACTIVE, whatever they hold: the backfill never maps them.)
-- The legacy column what_the_legacy_role_loses states, per legacy role, the capability that has NO equivalent in the mapped
-- assignment even when the verdict is SAME (RFC-011 § "Mapping table": "What a user loses is shown in the diff report and
-- re-granted by hand after cut-over"). It is a fixed text per role, not derived from data.
--
-- LIMITS. This is as honest a comparison as the schema allows:
--   * "Legacy access" is only the role and the unit. The old per-person rules that depended on other data (a MANAGER's
--     subtree reach, MODERATOR subtree administration, HOD/GM eligibility by ancestry, project visibility by team) are not
--     recomputed here; queries 4, 5, 7, 11 and 12 of uat-access-precheck.sql report those exposures.
--   * It needs users.role and users.organisation_unit_id, which stay until the "drop the legacy columns" follow-up release
--     (PLN-022 "Follow-up release"). Once those columns are dropped this report cannot be run; archive its output first.
--   * Scope is compared by exact unit, not by coverage: Contributor at a unit and Contributor at its parent are different
--     rows here (the evaluator treats the parent as covering the unit; this report still flags them as different so a human
--     decides).
--
-- Result sets: (1) one row per user with a verdict, (2) the count per verdict, (3) the individual differing assignments.

BEGIN;

CREATE TEMP TABLE diff_expected ON COMMIT DROP AS
WITH mapping (legacy_role, new_role, scoped) AS (
    VALUES ('USER', 'CONTRIBUTOR', true),
           ('MANAGER', 'CONTRIBUTOR', true),
           ('MANAGER', 'APPROVER', true),
           ('MODERATOR', 'PAIN_POINT_MODERATOR', true),
           ('ADMIN', 'SYSTEM_ADMINISTRATOR', false),
           ('SUPER_ADMIN', 'SUPER_ADMINISTRATOR', false)
)
SELECT u.id AS user_id, m.new_role::"AccessRole" AS role,
       CASE WHEN m.scoped THEN u.organisation_unit_id END AS unit_id
FROM users u
JOIN mapping m ON m.legacy_role = u.role::text
WHERE u.is_active AND (NOT m.scoped OR u.organisation_unit_id IS NOT NULL);

CREATE TEMP TABLE diff_actual ON COMMIT DROP AS
SELECT a.user_id, a.role, a.organisation_unit_id AS unit_id
FROM user_role_assignments a
WHERE a.revoked_at IS NULL;

CREATE TEMP TABLE diff_rows ON COMMIT DROP AS
SELECT coalesce(e.user_id, a.user_id) AS user_id,
       coalesce(e.role, a.role) AS role,
       coalesce(e.unit_id, a.unit_id) AS unit_id,
       CASE WHEN a.user_id IS NULL THEN 'LOST' WHEN e.user_id IS NULL THEN 'GAINED' ELSE 'SAME' END AS difference
FROM diff_expected e
FULL JOIN diff_actual a
  ON a.user_id = e.user_id AND a.role = e.role AND a.unit_id IS NOT DISTINCT FROM e.unit_id;

-- 1. One row per user: legacy access, effective access and the verdict.
SELECT u.email, u.full_name, u.is_active,
       u.role AS legacy_role, coalesce(lu.name, '(no unit)') AS legacy_unit,
       coalesce((SELECT string_agg(e.role::text || coalesce(' @ ' || eu.name, ' (all)'), ', ' ORDER BY e.role::text)
                 FROM diff_expected e LEFT JOIN organisation_units eu ON eu.id = e.unit_id
                 WHERE e.user_id = u.id), '(none)') AS mapped_from_legacy,
       coalesce((SELECT string_agg(a.role::text || coalesce(' @ ' || au.name, ' (all)'), ', ' ORDER BY a.role::text)
                 FROM diff_actual a LEFT JOIN organisation_units au ON au.id = a.unit_id
                 WHERE a.user_id = u.id), '(none)') AS effective_assignments,
       CASE
           WHEN NOT u.is_active THEN 'INACTIVE'
           WHEN u.role = 'EXTERNAL_USER' AND NOT EXISTS (SELECT 1 FROM diff_actual a WHERE a.user_id = u.id) THEN 'PENDING'
           WHEN EXISTS (SELECT 1 FROM diff_rows r WHERE r.user_id = u.id AND r.difference = 'LOST')
            AND EXISTS (SELECT 1 FROM diff_rows r WHERE r.user_id = u.id AND r.difference = 'GAINED') THEN 'LOST_AND_GAINED'
           WHEN EXISTS (SELECT 1 FROM diff_rows r WHERE r.user_id = u.id AND r.difference = 'LOST') THEN 'LOST'
           WHEN EXISTS (SELECT 1 FROM diff_rows r WHERE r.user_id = u.id AND r.difference = 'GAINED') THEN 'GAINED'
           ELSE 'SAME'
       END AS verdict,
       CASE u.role
           WHEN 'EXTERNAL_USER' THEN 'Can no longer sign in to anything: the account is pending until a Super Admin grants a role.'
           WHEN 'USER' THEN 'Loses edit rights over projects they only reached by position; keeps read access as Contributor.'
           WHEN 'MANAGER' THEN 'Loses edit rights over position-only projects; the unit-wide Contributor read is kept; may become HOD/GM only through Approver.'
           WHEN 'MODERATOR' THEN 'Keeps Pain Point Moderator only: loses user and organisation administration, approvals, dashboards and delivery rights over the subtree; no longer eligible as HOD/GM.'
           WHEN 'ADMIN' THEN 'Keeps System Administrator only: loses the approval override, project write access and the HOD/GM eligibility.'
           WHEN 'SUPER_ADMIN' THEN 'Keeps Super Administrator; is not a Steering Committee member and not a project lead unless granted the role.'
       END AS what_the_legacy_role_loses
FROM users u
LEFT JOIN organisation_units lu ON lu.id = u.organisation_unit_id
ORDER BY CASE WHEN u.is_active THEN 0 ELSE 1 END, verdict, u.role, u.email;

-- 2. Summary: how many users per verdict and legacy role.
SELECT s.verdict, s.legacy_role, count(*) AS users
FROM (
    SELECT u.role AS legacy_role,
           CASE
               WHEN NOT u.is_active THEN 'INACTIVE'
               WHEN u.role = 'EXTERNAL_USER' AND NOT EXISTS (SELECT 1 FROM diff_actual a WHERE a.user_id = u.id) THEN 'PENDING'
               WHEN EXISTS (SELECT 1 FROM diff_rows r WHERE r.user_id = u.id AND r.difference = 'LOST')
                AND EXISTS (SELECT 1 FROM diff_rows r WHERE r.user_id = u.id AND r.difference = 'GAINED') THEN 'LOST_AND_GAINED'
               WHEN EXISTS (SELECT 1 FROM diff_rows r WHERE r.user_id = u.id AND r.difference = 'LOST') THEN 'LOST'
               WHEN EXISTS (SELECT 1 FROM diff_rows r WHERE r.user_id = u.id AND r.difference = 'GAINED') THEN 'GAINED'
               ELSE 'SAME'
           END AS verdict
    FROM users u
) s
GROUP BY s.verdict, s.legacy_role
ORDER BY s.verdict, s.legacy_role;

-- 3. Every individual difference: the assignment the user lost or gained, for the business to sign off or correct.
SELECT u.email, u.is_active, u.role AS legacy_role, r.difference, r.role AS assignment_role,
       coalesce(ou.name, '(all)') AS scope_unit, ou.type AS scope_unit_type
FROM diff_rows r
JOIN users u ON u.id = r.user_id
LEFT JOIN organisation_units ou ON ou.id = r.unit_id
WHERE r.difference <> 'SAME'
ORDER BY r.difference, u.email, r.role;

ROLLBACK;
